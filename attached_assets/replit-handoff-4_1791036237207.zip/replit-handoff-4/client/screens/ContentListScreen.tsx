import React, { useState, useMemo, useRef, useCallback, useEffect } from "react";
import SideMenuButton from "@/components/SideMenuButton";
import {
  View,
  StyleSheet,
  FlatList,
  Pressable,
  ActivityIndicator,
  Animated,
  ScrollView,
  TextInput,
  Modal,
  useWindowDimensions,
  Platform,
  Keyboard,
} from "react-native";
import SearchClearButton from "@/components/SearchClearButton";
import { FlashList } from "@shopify/flash-list";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useNavigation, useRoute, RouteProp, useFocusEffect } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { Feather, MaterialCommunityIcons } from "@expo/vector-icons";
import { Image } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { Colors, Spacing, BorderRadius } from "@/constants/theme";
import { RootStackParamList } from "@/navigation/RootStackNavigator";
import { xtreamApi, LiveStream, VodStream, Series } from "@/lib/xtream-api";
import { useData } from "@/contexts/DataContext";
import { useFavourites } from "@/contexts/FavouritesContext";
import { useWatchlist } from "@/contexts/WatchlistContext";
import { useGroups, GroupType } from "@/contexts/GroupsContext";
import { getGroupIconProps, getGroupIconDef } from "@/lib/group-icons";
import { useWatchHistory, getWatchState, type SeriesProgress } from "@/contexts/WatchHistoryContext";
import { useCategoryOrder } from "@/contexts/CategoryOrderContext";
import { useUISettings } from "@/contexts/UISettingsContext";
import { useProfile } from "@/contexts/ProfileContext";
import GuestPrompt from "@/components/GuestPrompt";
import { normaliseSearch, normalisedName } from "@/lib/search";
import { useTvLongPress, setLongPressAction, clearLongPressAction } from "@/lib/tv-long-press";
import { LiveChannelRow, LIVE_ROW_HEIGHT } from "@/components/LiveChannelRow";
import { computeSuggestions } from "@/lib/suggestions";
import type { RecentlyWatched } from "@/components/RecentlyWatchedCard";
import { CINEMA_CATEGORY_ID, cinemaHistoryId } from "@/lib/cinema";

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;
type ContentListRouteProp = RouteProp<RootStackParamList, "ContentList">;
type ContentItem = LiveStream | VodStream | Series;

const SEARCH_LIMIT = 150;
const SIDEBAR_W = 170;
const CONTENT_PAD = Spacing.md;

// Header "Clear All" button — explicit focus/hover/press tracking because
// Pressable's style render-prop only exposes `pressed` on RN native; using
// `({ focused, hovered })` would always be undefined and the active style
// would never apply on TV remotes or desktop hover.
function ManageBtn({ active, onPress, iconOnly }: { active: boolean; onPress: () => void; iconOnly?: boolean }) {
  const [focused, setFocused] = useState(false);
  const [hovered, setHovered] = useState(false);
  const [pressed, setPressed] = useState(false);
  const isActive = focused || hovered || pressed;
  if (iconOnly) {
    // Portrait phone — render as a circular icon-only button so the header
    // doesn't blow out horizontally with text labels.
    return (
      <Pressable
        style={[
          styles.backBtn,
          isActive && styles.backBtnActive,
          active && { backgroundColor: Colors.dark.accent, borderColor: Colors.dark.accent },
        ]}
        onPress={onPress}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        onHoverIn={() => setHovered(true)}
        onHoverOut={() => setHovered(false)}
        onPressIn={() => setPressed(true)}
        onPressOut={() => setPressed(false)}
        accessibilityLabel={active ? "Done" : "Manage"}
      >
        {isActive && !active ? (
          <LinearGradient
            colors={["rgba(255,102,0,0.18)", "rgba(255,102,0,0.06)"]}
            style={StyleSheet.absoluteFill}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
          />
        ) : null}
        <Feather
          name={active ? "check" : "edit-2"}
          size={18}
          color={active ? "#fff" : (isActive ? Colors.dark.accent : Colors.dark.text)}
        />
      </Pressable>
    );
  }
  return (
    <Pressable
      style={[
        styles.manageBtn,
        active && styles.manageBtnOn,
        isActive && (active ? styles.manageBtnOnActive : styles.manageBtnActive),
      ]}
      onPress={onPress}
      onFocus={() => setFocused(true)}
      onBlur={() => setFocused(false)}
      onHoverIn={() => setHovered(true)}
      onHoverOut={() => setHovered(false)}
      onPressIn={() => setPressed(true)}
      onPressOut={() => setPressed(false)}
    >
      <Feather
        name={active ? "check" : "edit-2"}
        size={13}
        color={active ? "#fff" : Colors.dark.accent}
      />
      <ThemedText style={[styles.manageBtnText, active && styles.manageBtnTextOn]}>
        {active ? "Done" : "Manage"}
      </ThemedText>
    </Pressable>
  );
}

function ClearAllButton({ onPress, iconOnly }: { onPress: () => void; iconOnly?: boolean }) {
  const [focused, setFocused] = useState(false);
  const [hovered, setHovered] = useState(false);
  const [pressed, setPressed] = useState(false);
  const isActive = focused || hovered || pressed;
  if (iconOnly) {
    // Portrait phone — render as circular icon-only button matching the
    // other header buttons (Back / Refresh / Manage).
    return (
      <Pressable
        style={[
          styles.backBtn,
          { borderColor: "rgba(255,59,59,0.45)" },
          isActive && { borderColor: Colors.dark.error, backgroundColor: "rgba(255,59,59,0.18)" },
        ]}
        onPress={onPress}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        onHoverIn={() => setHovered(true)}
        onHoverOut={() => setHovered(false)}
        onPressIn={() => setPressed(true)}
        onPressOut={() => setPressed(false)}
        accessibilityLabel="Clear All"
      >
        <Feather name="trash-2" size={18} color={Colors.dark.error} />
      </Pressable>
    );
  }
  return (
    <Pressable
      style={[styles.clearAllBtn, isActive && styles.clearAllBtnActive]}
      onPress={onPress}
      onFocus={() => setFocused(true)}
      onBlur={() => setFocused(false)}
      onHoverIn={() => setHovered(true)}
      onHoverOut={() => setHovered(false)}
      onPressIn={() => setPressed(true)}
      onPressOut={() => setPressed(false)}
    >
      <Feather name="trash-2" size={13} color={Colors.dark.error} />
      <ThemedText style={styles.clearAllText}>Clear All</ThemedText>
    </Pressable>
  );
}

// Confirm-modal Cancel / Clear All buttons — same focus/hover pattern as
// ClearAllButton so the active highlight actually shows on TV + desktop.
function ModalBtn({
  kind, onPress, disabled, children,
}: {
  kind: "cancel" | "confirm";
  onPress: () => void;
  disabled?: boolean;
  children: React.ReactNode;
}) {
  const [focused, setFocused] = useState(false);
  const [hovered, setHovered] = useState(false);
  const [pressed, setPressed] = useState(false);
  const isActive = focused || hovered || pressed;
  const baseStyle = kind === "cancel" ? styles.modalBtnCancel : styles.modalBtnConfirm;
  const activeStyle = kind === "cancel" ? styles.modalBtnCancelActive : styles.modalBtnConfirmActive;
  return (
    <Pressable
      style={[baseStyle, isActive && activeStyle]}
      onPress={onPress}
      disabled={disabled}
      onFocus={() => setFocused(true)}
      onBlur={() => setFocused(false)}
      onHoverIn={() => setHovered(true)}
      onHoverOut={() => setHovered(false)}
      onPressIn={() => setPressed(true)}
      onPressOut={() => setPressed(false)}
    >
      {children}
    </Pressable>
  );
}

function RequestsBtn({ onPress, iconOnly }: { onPress: () => void; iconOnly?: boolean }) {
  const [focused, setFocused] = useState(false);
  const [pressed, setPressed] = useState(false);
  const [hovered, setHovered] = useState(false);
  const isActive = focused || pressed || hovered;
  return (
    <Pressable
      style={[
        styles.backBtn,
        isActive && styles.backBtnActive,
        iconOnly ? null : { flexDirection: "row", paddingHorizontal: Spacing.sm, gap: 6, width: undefined },
      ]}
      onPress={onPress}
      onFocus={() => setFocused(true)}
      onBlur={() => setFocused(false)}
      onPressIn={() => setPressed(true)}
      onPressOut={() => setPressed(false)}
      onHoverIn={() => setHovered(true)}
      onHoverOut={() => setHovered(false)}
      accessibilityLabel="My Requests"
    >
      {isActive ? (
        <LinearGradient
          colors={["rgba(255,102,0,0.18)", "rgba(255,102,0,0.06)"]}
          style={StyleSheet.absoluteFill}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
        />
      ) : null}
      <Feather name="inbox" size={iconOnly ? 18 : 16} color={isActive ? Colors.dark.accent : Colors.dark.text} />
      {iconOnly ? null : (
        <ThemedText style={{ color: isActive ? Colors.dark.accent : Colors.dark.text, fontWeight: "700", fontSize: 12 }}>
          My Requests
        </ThemedText>
      )}
    </Pressable>
  );
}

function MyWatchlistBtn({ onPress, selected, iconOnly }: { onPress: () => void; selected?: boolean; iconOnly?: boolean }) {
  const [focused, setFocused] = useState(false);
  const [pressed, setPressed] = useState(false);
  const [hovered, setHovered] = useState(false);
  const isActive = focused || pressed || hovered || !!selected;
  const showOverlay = focused || pressed || hovered;
  return (
    <Pressable
      style={[
        styles.backBtn,
        isActive && styles.backBtnActive,
        iconOnly ? null : { flexDirection: "row", paddingHorizontal: Spacing.sm, gap: 6, width: undefined },
        selected && { backgroundColor: "rgba(255,102,0,0.16)" },
      ]}
      onPress={onPress}
      onFocus={() => setFocused(true)}
      onBlur={() => setFocused(false)}
      onPressIn={() => setPressed(true)}
      onPressOut={() => setPressed(false)}
      onHoverIn={() => setHovered(true)}
      onHoverOut={() => setHovered(false)}
      accessibilityLabel="My Watchlist"
    >
      {showOverlay ? (
        <LinearGradient
          colors={["rgba(255,102,0,0.18)", "rgba(255,102,0,0.06)"]}
          style={StyleSheet.absoluteFill}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
        />
      ) : null}
      <Feather name="bookmark" size={iconOnly ? 18 : 16} color={isActive ? Colors.dark.accent : Colors.dark.text} />
      {iconOnly ? null : (
        <ThemedText style={{ color: isActive ? Colors.dark.accent : Colors.dark.text, fontWeight: "700", fontSize: 12 }}>
          My Watchlist
        </ThemedText>
      )}
    </Pressable>
  );
}

function RefreshBtn({ onPress, refreshing }: { onPress: () => void; refreshing: boolean }) {
  const [focused, setFocused] = useState(false);
  const [pressed, setPressed] = useState(false);
  const isActive = focused || pressed;
  return (
    <Pressable
      style={[styles.backBtn, (isActive || refreshing) && styles.backBtnActive]}
      onPress={onPress}
      onFocus={() => setFocused(true)}
      onBlur={() => setFocused(false)}
      onPressIn={() => setPressed(true)}
      onPressOut={() => setPressed(false)}
      disabled={refreshing}
    >
      {(isActive || refreshing) ? (
        <LinearGradient
          colors={["rgba(255,102,0,0.18)", "rgba(255,102,0,0.06)"]}
          style={StyleSheet.absoluteFill}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
        />
      ) : null}
      <Feather name="refresh-cw" size={18} color={(isActive || refreshing) ? Colors.dark.accent : Colors.dark.text} />
    </Pressable>
  );
}

function MyGroupsBtn({ onPress, iconOnly }: { onPress: () => void; iconOnly?: boolean }) {
  const [focused, setFocused] = useState(false);
  const [pressed, setPressed] = useState(false);
  const [hovered, setHovered] = useState(false);
  const isActive = focused || pressed || hovered;
  return (
    <Pressable
      style={[
        styles.backBtn,
        isActive && styles.backBtnActive,
        iconOnly ? null : { flexDirection: "row", paddingHorizontal: Spacing.sm, gap: 6, width: undefined },
      ]}
      onPress={onPress}
      onFocus={() => setFocused(true)}
      onBlur={() => setFocused(false)}
      onPressIn={() => setPressed(true)}
      onPressOut={() => setPressed(false)}
      onHoverIn={() => setHovered(true)}
      onHoverOut={() => setHovered(false)}
      accessibilityLabel="My Groups"
    >
      {isActive ? (
        <LinearGradient
          colors={["rgba(255,102,0,0.18)", "rgba(255,102,0,0.06)"]}
          style={StyleSheet.absoluteFill}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
        />
      ) : null}
      <Feather name="folder" size={iconOnly ? 18 : 16} color={isActive ? Colors.dark.accent : Colors.dark.text} />
      {iconOnly ? null : (
        <ThemedText style={{ color: isActive ? Colors.dark.accent : Colors.dark.text, fontWeight: "700", fontSize: 12 }}>
          My Groups
        </ThemedText>
      )}
    </Pressable>
  );
}

function TvGuideBtn({ onPress, iconOnly }: { onPress: () => void; iconOnly?: boolean }) {
  const [focused, setFocused] = useState(false);
  const [pressed, setPressed] = useState(false);
  const [hovered, setHovered] = useState(false);
  const isActive = focused || pressed || hovered;
  return (
    <Pressable
      style={[
        styles.backBtn,
        isActive && styles.backBtnActive,
        iconOnly ? null : { flexDirection: "row", paddingHorizontal: Spacing.sm, gap: 6, width: undefined },
      ]}
      onPress={onPress}
      onFocus={() => setFocused(true)}
      onBlur={() => setFocused(false)}
      onPressIn={() => setPressed(true)}
      onPressOut={() => setPressed(false)}
      onHoverIn={() => setHovered(true)}
      onHoverOut={() => setHovered(false)}
      accessibilityLabel="TV Guide"
    >
      {isActive ? (
        <LinearGradient
          colors={["rgba(255,102,0,0.18)", "rgba(255,102,0,0.06)"]}
          style={StyleSheet.absoluteFill}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
        />
      ) : null}
      <Feather name="calendar" size={iconOnly ? 18 : 16} color={isActive ? Colors.dark.accent : Colors.dark.text} />
      {iconOnly ? null : (
        <ThemedText style={{ color: isActive ? Colors.dark.accent : Colors.dark.text, fontWeight: "700", fontSize: 12 }}>
          TV Guide
        </ThemedText>
      )}
    </Pressable>
  );
}

function MultiScreenBtn({ onPress, iconOnly }: { onPress: () => void; iconOnly?: boolean }) {
  const [focused, setFocused] = useState(false);
  const [pressed, setPressed] = useState(false);
  const [hovered, setHovered] = useState(false);
  const isActive = focused || pressed || hovered;
  return (
    <Pressable
      style={[
        styles.backBtn,
        isActive && styles.backBtnActive,
        iconOnly ? null : { flexDirection: "row", paddingHorizontal: Spacing.sm, gap: 6, width: undefined },
      ]}
      onPress={onPress}
      onFocus={() => setFocused(true)}
      onBlur={() => setFocused(false)}
      onPressIn={() => setPressed(true)}
      onPressOut={() => setPressed(false)}
      onHoverIn={() => setHovered(true)}
      onHoverOut={() => setHovered(false)}
      accessibilityLabel="Multi Screen"
    >
      {isActive ? (
        <LinearGradient
          colors={["rgba(255,102,0,0.18)", "rgba(255,102,0,0.06)"]}
          style={StyleSheet.absoluteFill}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
        />
      ) : null}
      <Feather name="grid" size={iconOnly ? 18 : 16} color={isActive ? Colors.dark.accent : Colors.dark.text} />
      {iconOnly ? null : (
        <ThemedText style={{ color: isActive ? Colors.dark.accent : Colors.dark.text, fontWeight: "700", fontSize: 12 }}>
          Multi Screen
        </ThemedText>
      )}
    </Pressable>
  );
}

function BackBtn({ onPress }: { onPress: () => void }) {
  const [focused, setFocused] = useState(false);
  const [pressed, setPressed] = useState(false);
  const isActive = focused || pressed;
  return (
    <Pressable
      style={[styles.backBtn, isActive && styles.backBtnActive]}
      onPress={onPress}
      onFocus={() => setFocused(true)}
      onBlur={() => setFocused(false)}
      onPressIn={() => setPressed(true)}
      onPressOut={() => setPressed(false)}
    >
      {isActive ? (
        <LinearGradient
          colors={["rgba(255,102,0,0.18)", "rgba(255,102,0,0.06)"]}
          style={StyleSheet.absoluteFill}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
        />
      ) : null}
      <Feather name="arrow-left" size={20} color={isActive ? Colors.dark.accent : Colors.dark.text} />
    </Pressable>
  );
}

function getImageRatio(type: string): number {
  if (type === "movies" || type === "series") return 1.5;
  return 0.75;
}

function getImageFit(type: string): "cover" | "contain" {
  if (type === "live") return "contain";
  return "cover";
}

function getStreamId(item: ContentItem, type: string): number {
  if (type === "series" && "series_id" in item) return (item as Series).series_id;
  if ("stream_id" in item) return (item as LiveStream | VodStream).stream_id;
  return 0;
}

function getIconUrl(item: ContentItem): string | null {
  if ("stream_icon" in item && item.stream_icon) return item.stream_icon;
  if ("cover" in item && item.cover) return item.cover;
  return null;
}

// In-card action picker button used by Manage mode. Each button is its own
// Pressable so it has independent TV focus + hover state, and pressing it
// runs the action and closes the picker.
function PickerActionButton({
  action,
  autoFocus,
  onClose,
}: {
  action: PickerAction;
  autoFocus?: boolean;
  onClose?: () => void;
}) {
  const [focused, setFocused] = useState(false);
  const [hovered, setHovered] = useState(false);
  const [pressed, setPressed] = useState(false);
  const isActive = focused || hovered || pressed;
  return (
    <Pressable
      style={[
        styles.pickerBtn,
        action.active && styles.pickerBtnRemove,
        isActive && (action.active ? styles.pickerBtnRemoveActive : styles.pickerBtnActive),
        action.tint && !action.active ? { backgroundColor: action.tint, borderColor: action.tint } : null,
        action.tint && !action.active && isActive ? { borderColor: readableOn(action.tint), shadowColor: action.tint, shadowOffset: { width: 0, height: 0 }, shadowOpacity: 1, shadowRadius: 8, elevation: 8 } : null,
      ]}
      onPress={() => {
        action.onPress();
        onClose?.();
      }}
      onFocus={() => setFocused(true)}
      onBlur={() => setFocused(false)}
      onHoverIn={() => setHovered(true)}
      onHoverOut={() => setHovered(false)}
      onPressIn={() => setPressed(true)}
      onPressOut={() => setPressed(false)}
      hasTVPreferredFocus={autoFocus}
      accessibilityLabel={`${action.active ? "Remove from" : "Add to"} ${action.label}`}
    >
      {(() => {
        const fg = action.active ? "#fff" : (action.tint ? readableOn(action.tint) : "#fff");
        return action.active ? (
          <Feather name="check" size={12} color={fg} />
        ) : action.iconComponent ? (
          <action.iconComponent name={action.iconName as any} size={12} color={fg} />
        ) : (
          <Feather name={action.icon} size={12} color={fg} />
        );
      })()}
      <ThemedText
        style={[
          styles.pickerBtnText,
          !action.active && action.tint ? { color: readableOn(action.tint) } : null,
        ]}
        numberOfLines={1}
      >
        {action.active ? `Remove from ${action.label}` : `Add to ${action.label}`}
      </ThemedText>
    </Pressable>
  );
}

function StarBadge({ visible }: { visible: boolean }) {
  const scaleAnim = useRef(new Animated.Value(visible ? 1 : 0)).current;

  React.useEffect(() => {
    Animated.spring(scaleAnim, {
      toValue: visible ? 1 : 0,
      useNativeDriver: true,
      tension: 200,
      friction: 10,
    }).start();
  }, [visible]);

  return (
    <Animated.View
      style={[styles.starBadge, { transform: [{ scale: scaleAnim }] }]}
      pointerEvents="none"
    >
      <Feather name="star" size={11} color="#fff" />
    </Animated.View>
  );
}

export interface PickerAction {
  key: string;
  label: string;
  icon: React.ComponentProps<typeof Feather>["name"];
  active: boolean; // already in list — show "Remove" semantics
  onPress: () => void;
  // Optional custom tint colour (used for user-group buttons so each group
  // shows its own colour). When omitted the default orange/grey applies.
  tint?: string;
  // Optional custom icon component (e.g. MaterialCommunityIcons for group
  // icons that aren't in Feather). When provided, the picker renders
  // `iconComponent` with `iconName` instead of Feather + `icon`.
  iconComponent?: React.ComponentType<{ name: any; size: number; color: string }>;
  iconName?: string;
}

const ContentCard = React.memo(function ContentCard({
  item,
  type,
  onPress,
  onLongPress,
  isFavourited,
  cardWidth,
  cardHeight,
  watchEntry,
  seriesProgress,
  editMode,
  editAction,
  pickerOpen,
  pickerActions,
  onPickerClose,
}: {
  item: ContentItem;
  type: string;
  // Item-aware so parents can pass stable refs (no new closures per render).
  onPress: (item: ContentItem) => void;
  onLongPress: (item: ContentItem) => void;
  isFavourited: boolean;
  cardWidth: number;
  cardHeight: number;
  watchEntry?: RecentlyWatched;
  seriesProgress?: SeriesProgress;
  editMode?: boolean;
  editAction?: "delete" | "favourite";
  // When true, this card shows a small popover with picker actions (e.g.
  // "Add to Favourites" / "Add to Watchlist") layered over its thumbnail.
  pickerOpen?: boolean;
  pickerActions?: PickerAction[];
  onPickerClose?: () => void;
}) {
  const [focused, setFocused] = useState(false);
  const [pressed, setPressed] = useState(false);
  const isActive = focused || pressed;
  const longFiredRef = useRef(false);
  // Stable identity for the focused-item registry: blur must clear exactly what
  // focus registered, never a newer item's action.
  const longPressActionRef = useRef(() => {});
  longPressActionRef.current = () => {
    if (editMode) return;
    onLongPress(item);
  };
  const pressInTimeRef = useRef(0);
  const { scaleFont } = useUISettings();

  // FlashList recycles cell views — when a cell is reused to show a different
  // item (during fast scroll), local visual state like `focused`/`pressed`
  // would otherwise leak across items, leaving stale orange borders on the
  // wrong card. Reset on item change. Native focus events will repaint
  // immediately if the TV remote actually has focus on this position.
  useEffect(() => {
    setFocused(false);
    setPressed(false);
    longFiredRef.current = false;
  }, [item]);

  const imageUrl = getIconUrl(item);
  const iconName = type === "live" ? "tv" : type === "movies" ? "film" : "grid";
  const imgH = cardHeight - 52;
  const imgFit = getImageFit(type);

  return (
    <Pressable
      style={[
        styles.card,
        { width: cardWidth, height: cardHeight },
        isActive && !isFavourited && styles.cardActive,
        isFavourited && styles.cardFavourited,
        isActive && isFavourited && styles.cardFavouritedActive,
        editMode && editAction === "delete" && styles.cardEditDelete,
        editMode && editAction === "delete" && isActive && styles.cardEditDeleteActive,
        editMode && editAction === "favourite" && isActive && styles.cardEditFavActive,
      ]}
      onPress={() => {
        if (longFiredRef.current) { longFiredRef.current = false; return; }
        onPress(item);
      }}
      onLongPress={() => {
        if (editMode) return;
        longFiredRef.current = true;
        onLongPress(item);
      }}
      delayLongPress={Platform.isTV ? 700 : 500}
      onPressIn={() => {
        setPressed(true);
        longFiredRef.current = false;
        pressInTimeRef.current = Date.now();
      }}
      onPressOut={() => {
        setPressed(false);
        if (
          !editMode &&
          Platform.isTV &&
          !longFiredRef.current &&
          (Date.now() - pressInTimeRef.current) >= 600
        ) {
          longFiredRef.current = true;
          onLongPress(item);
        }
      }}
      onFocus={() => {
        setFocused(true);
        // A remote cannot produce a long PRESS, so the native bridge reports a
        // held OK instead and whichever item is focused handles it.
        setLongPressAction(longPressActionRef.current);
      }}
      onBlur={() => {
        setFocused(false);
        clearLongPressAction(longPressActionRef.current);
      }}
    >
      <View style={[styles.cardThumb, { width: cardWidth, height: imgH }]}>
        {imageUrl ? (
          <Image
            source={{ uri: imageUrl }}
            style={styles.cardImage}
            contentFit={imgFit}
            transition={200}
          />
        ) : (
          <View style={styles.cardPlaceholder}>
            <Feather name={iconName} size={24} color={Colors.dark.border} />
          </View>
        )}
        {isActive ? <View style={styles.cardOverlay} /> : null}
        {editMode && editAction === "delete" ? (
          <View style={styles.deleteBadge} pointerEvents="none">
            <Feather name="x" size={13} color="#fff" />
          </View>
        ) : null}
        {editMode && editAction === "favourite" && !pickerOpen ? (
          <View style={styles.editFavBadge} pointerEvents="none">
            <Feather
              name={isFavourited ? "star" : "plus"}
              size={11}
              color="#fff"
            />
          </View>
        ) : null}
        {pickerOpen && pickerActions && pickerActions.length > 0 ? (
          <View style={styles.pickerOverlay}>
            <View style={styles.pickerScrim} pointerEvents="none" />
            {/* Scroll so a long groups list never expands beyond the thumb */}
            <ScrollView
              style={[styles.pickerScroll, { maxHeight: imgH - 12 }]}
              contentContainerStyle={styles.pickerRow}
              showsVerticalScrollIndicator={false}
              nestedScrollEnabled
            >
              {pickerActions.map((act, idx) => (
                <PickerActionButton
                  key={act.key}
                  action={act}
                  autoFocus={idx === 0}
                  onClose={onPickerClose}
                />
              ))}
            </ScrollView>
          </View>
        ) : null}
        <StarBadge visible={isFavourited && !editMode} />
        {"rating" in item && item.rating ? (
          <View style={styles.ratingBadge}>
            <Feather name="star" size={9} color={Colors.dark.accent} />
            <ThemedText style={styles.ratingText}>{item.rating}</ThemedText>
          </View>
        ) : null}
        {(() => {
          if (type === "live") return null;
          // Series rows use the aggregate progress (watched-eps vs total
          // snapshot + last_modified diff) rather than the latest episode's
          // is_completed flag — so shows don't get "WATCHED" until every
          // available episode is finished, and they flip back to
          // "NEW EPISODES" the moment the provider uploads more.
          if (type === "series" && seriesProgress) {
            const { hasNewEpisodes, isFullyWatched, latestProgress, latest } = seriesProgress;
            if (!latest) return null;
            if (hasNewEpisodes) {
              return (
                <View style={styles.newBadge}>
                  <Feather name="zap" size={9} color="#fff" />
                  <ThemedText style={styles.newBadgeText}>NEW EPISODES</ThemedText>
                </View>
              );
            }
            if (isFullyWatched) {
              return (
                <View style={styles.watchedBadge}>
                  <Feather name="check" size={9} color="#fff" />
                  <ThemedText style={styles.watchedBadgeText}>WATCHED</ThemedText>
                </View>
              );
            }
            return (
              <>
                <View style={styles.continueBadge}>
                  <Feather name="play" size={9} color={Colors.dark.accent} />
                  <ThemedText style={styles.continueBadgeText}>CONTINUE</ThemedText>
                </View>
                {latestProgress > 0 && latestProgress < 1 ? (
                  <View style={styles.cardProgressTrack}>
                    <View style={[styles.cardProgressFill, { width: `${latestProgress * 100}%` }]} />
                  </View>
                ) : null}
              </>
            );
          }
          // Movies (and any other non-series, non-live) keep the legacy
          // single-entry behaviour.
          const ws = getWatchState(watchEntry);
          if (!ws.hasProgress) return null;
          return (
            <>
              {ws.isCompleted ? (
                <View style={styles.watchedBadge}>
                  <Feather name="check" size={9} color="#fff" />
                  <ThemedText style={styles.watchedBadgeText}>WATCHED</ThemedText>
                </View>
              ) : (
                <View style={styles.continueBadge}>
                  <Feather name="play" size={9} color={Colors.dark.accent} />
                  <ThemedText style={styles.continueBadgeText}>CONTINUE</ThemedText>
                </View>
              )}
              {!ws.isCompleted ? (
                <View style={styles.cardProgressTrack}>
                  <View style={[styles.cardProgressFill, { width: `${ws.progress * 100}%` }]} />
                </View>
              ) : null}
            </>
          );
        })()}
      </View>

      <View style={styles.cardInfo}>
        <ThemedText
          style={[
            styles.cardName,
            { fontSize: scaleFont(11), lineHeight: scaleFont(15) },
            isActive && styles.cardNameActive,
          ]}
          numberOfLines={2}
        >
          {item.name}
        </ThemedText>
      </View>

      {isActive ? <View style={styles.activeBar} /> : null}
    </Pressable>
  );
});

interface SidebarCat {
  category_id: string;
  category_name: string;
  // Optional accent colour for user-pinned group rows. When set, the
  // selected/hover overlay + active bar + text colour use this instead of
  // the default orange so the user's chosen group colour shines through.
  accent?: string;
  // Optional inline icon for pinned-group rows.
  iconLib?: "feather" | "mci";
  iconName?: string;
  iconColor?: string;
}

const CategorySidebarItem = React.memo(function CategorySidebarItem({
  item,
  isSelected,
  onPress,
  isFav,
  isRecent,
  isSuggested,
  isPinned,
  hasTVPreferredFocus,
}: {
  item: SidebarCat;
  isSelected: boolean;
  // Item-aware so parents can pass a single stable callback ref.
  onPress: (item: SidebarCat) => void;
  isFav?: boolean;
  isRecent?: boolean;
  isSuggested?: boolean;
  // Pinned rows (Recently/Continue Watching, Favourites, Suggested for You,
  // Recently Added) get a subtle background so users understand they are
  // fixed system sections that can't be reordered or hidden.
  isPinned?: boolean;
  hasTVPreferredFocus?: boolean;
}) {
  const [focused, setFocused] = useState(false);
  const [pressed, setPressed] = useState(false);
  const isActive = focused || pressed;
  const highlight = isSelected || isActive;
  const { scaleFont } = useUISettings();
  const accent = item.accent ?? Colors.dark.accent;
  const accentRgba = (alpha: number) => hexToRgba(accent, alpha);

  return (
    <Pressable
      style={[
        styles.sidebarItem,
        isPinned && styles.sidebarItemPinned,
        isSelected && (item.accent
          ? { borderColor: accentRgba(0.55) }
          : styles.sidebarItemSelected),
        isActive && !isSelected && (item.accent
          ? { borderColor: accentRgba(0.25) }
          : styles.sidebarItemHover),
      ]}
      onPress={() => onPress(item)}
      onFocus={() => setFocused(true)}
      onBlur={() => setFocused(false)}
      onPressIn={() => setPressed(true)}
      onPressOut={() => setPressed(false)}
      hasTVPreferredFocus={hasTVPreferredFocus}
    >
      {isSelected ? (
        <LinearGradient
          colors={[accentRgba(0.20), accentRgba(0.04)]}
          style={StyleSheet.absoluteFill}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0 }}
        />
      ) : isActive ? (
        <LinearGradient
          colors={[accentRgba(0.08), accentRgba(0.02)]}
          style={StyleSheet.absoluteFill}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0 }}
        />
      ) : null}
      {item.iconLib === "mci" && item.iconName ? (
        <MaterialCommunityIcons
          name={item.iconName as any}
          size={item.iconColor ? 14 : 12}
          color={item.iconColor ?? (highlight ? accent : (item.accent ?? Colors.dark.text))}
        />
      ) : item.iconLib === "feather" && item.iconName ? (
        <Feather
          name={item.iconName as any}
          size={11}
          color={highlight ? accent : (item.accent ?? Colors.dark.text)}
        />
      ) : isFav ? (
        <Feather
          name="star"
          size={10}
          color={highlight ? accent : Colors.dark.text}
        />
      ) : isRecent ? (
        <Feather
          name="clock"
          size={10}
          color={highlight ? accent : Colors.dark.text}
        />
      ) : isSuggested ? (
        <MaterialCommunityIcons
          name="auto-fix"
          size={12}
          color={highlight ? accent : Colors.dark.text}
        />
      ) : null}
      <ThemedText
        style={[
          styles.sidebarItemText,
          { fontSize: scaleFont(11), lineHeight: scaleFont(15) },
          highlight && (item.accent ? { color: accent, fontWeight: "700" } : styles.sidebarItemTextActive),
        ]}
        numberOfLines={3}
      >
        {item.category_name}
      </ThemedText>
      {isSelected ? (
        <View style={[styles.sidebarActiveBar, item.accent ? { backgroundColor: accent } : null]} />
      ) : null}
    </Pressable>
  );
});

// Convert "#RRGGBB" to "rgba(r,g,b,a)". Tolerates short "#RGB" too.
// Falls back to the orange accent if parsing fails.
function hexToRgba(hex: string, alpha: number): string {
  let h = hex.replace("#", "").trim();
  if (h.length === 3) h = h.split("").map((c) => c + c).join("");
  if (h.length !== 6) return `rgba(255,102,0,${alpha})`;
  const r = parseInt(h.slice(0, 2), 16);
  const g = parseInt(h.slice(2, 4), 16);
  const b = parseInt(h.slice(4, 6), 16);
  if ([r, g, b].some((v) => Number.isNaN(v))) return `rgba(255,102,0,${alpha})`;
  return `rgba(${r},${g},${b},${alpha})`;
}

// Pick a readable foreground (white or black) for a given hex background
// using a simple luminance threshold.
function readableOn(hex: string): string {
  let h = hex.replace("#", "").trim();
  if (h.length === 3) h = h.split("").map((c) => c + c).join("");
  if (h.length !== 6) return "#fff";
  const r = parseInt(h.slice(0, 2), 16) / 255;
  const g = parseInt(h.slice(2, 4), 16) / 255;
  const b = parseInt(h.slice(4, 6), 16) / 255;
  const lum = 0.2126 * r + 0.7152 * g + 0.0722 * b;
  return lum > 0.6 ? "#000" : "#fff";
}

export default function ContentListScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation<NavigationProp>();
  const route = useRoute<ContentListRouteProp>();
  const { isGuest } = useProfile();
  const { type, categoryId, categoryName } = route.params;
  const { width, height } = useWindowDimensions();
  // Portrait phones: collapse text-label header buttons (Watchlist /
  // Requests / Multi Screen / Manage) into circular icon-only buttons so
  // the header doesn't blow out horizontally.
  const isLandscapeHeader = width > height;
  const { liveStreams, vodStreams, cinemaMovies, cinemaAvailable, seriesList, liveCategories, vodCategories, seriesCategories, recentMovies, recentSeries, isSyncing, refresh, streamRatings } = useData();
  const { activeProfile } = useProfile();
  const handleRefresh = useCallback(() => {
    if (isSyncing) return;
    refresh();
  }, [refresh, isSyncing]);
  const { isFavourite, toggleFavourite, getFavouritesByType, clearAllFavourites } = useFavourites();
  const { items: watchlistItems, toggleByStream: toggleWatchlist, findByStreamId: findWatchlistByStreamId, remove: removeWatchlistRow } = useWatchlist();
  const { getGroupsByType, getItemsByGroup, isInGroup, toggleItem: toggleGroupItem } = useGroups();
  const { applyOrder } = useCategoryOrder();
  const { entries: watchEntries, getByStreamId, getBySeriesId, getSeriesProgress, refetch: refetchHistory, clearHistory, removeOne: removeWatchEntry } = useWatchHistory();
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [clearing, setClearing] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [query, setQuery] = useState("");
  const [submittedQuery, setSubmittedQuery] = useState("");
  const searchInputRef = useRef<TextInput>(null);
  const [selectedCategoryId, setSelectedCategoryId] = useState(categoryId);
  const [selectedCategoryName, setSelectedCategoryName] = useState(categoryName);
  const [categorySwitching, setCategorySwitching] = useState(false);

  // Parental PIN unlock for search results — resets on every new search term
  const [parentalSearchUnlocked, setParentalSearchUnlocked] = useState(false);
  useEffect(() => { setParentalSearchUnlocked(false); }, [submittedQuery]);
  const [noticeFocused, setNoticeFocused] = useState(false);
  const [showParentalPinModal, setShowParentalPinModal] = useState(false);
  const [pinEntry, setPinEntry] = useState("");
  const [pinError, setPinError] = useState(false);
  const pinShakeAnim = useRef(new Animated.Value(0)).current;

  // Clear the loading overlay shortly AFTER the new selectedCategoryId has
  // been applied (the list re-renders synchronously with the change). We
  // wait until selectedCategoryId actually changes — not when the spinner
  // first appears — so the overlay covers the entire heavy re-render.
  useEffect(() => {
    if (!categorySwitching) return;
    const t = setTimeout(() => setCategorySwitching(false), 120);
    return () => clearTimeout(t);
  }, [selectedCategoryId]); // eslint-disable-line react-hooks/exhaustive-deps

  // Track whether we've already redirected away from a hidden category on
  // initial mount, so the user can still tap "Favourites" / etc. without
  // us bouncing them somewhere else.
  const redirectedFromHiddenRef = useRef(false);
  const [contentWidth, setContentWidth] = useState(Math.max(200, width - SIDEBAR_W - 2));
  const flatListRef = useRef<FlashList<ContentItem>>(null);

  const padH = Math.max(insets.left + Spacing.xs, Spacing.md);
  const padT = Math.max(insets.top + Spacing.xs, Spacing.md);
  const padB = Math.max(insets.bottom + Spacing.xs, Spacing.sm);
  const gap = Spacing.sm;

  const isFavouritesView = selectedCategoryId === "favourites";
  const isRecentlyView = selectedCategoryId === "recently";
  const isRecentlyAddedView = selectedCategoryId === "recent" && (type === "movies" || type === "series");
  const isSuggestedView = selectedCategoryId === "suggested" && (type === "movies" || type === "series");
  const isWatchlistView = selectedCategoryId === "watchlist" && (type === "movies" || type === "series");
  const isSpecialView = isFavouritesView || isRecentlyView || isRecentlyAddedView || isSuggestedView || isWatchlistView;
  const trimmedQuery = normaliseSearch(submittedQuery);
  const isSearching = trimmedQuery.length > 0;

  // Live channels browse as rows (logo + name + what's on), which want far
  // fewer, much wider columns than the poster grids used for movies and series.
  //
  // Manage mode is the exception: it keeps the old cards, because they carry the
  // add-to-favourites / add-to-group picker. Those cards need the GRID geometry —
  // handing them row dimensions squashed them to 78px tall and lost the buttons.
  const liveAsRows = type === "live" && !(editMode && !isSearching);
  const numColumns = liveAsRows
    ? Math.max(1, Math.min(2, Math.floor(contentWidth / 360)))
    : type === "live"
      ? Math.max(2, Math.floor(contentWidth / 150))
      : Math.max(2, Math.floor(contentWidth / 140));
  const cardWidth = Math.floor((contentWidth - CONTENT_PAD * 2 - gap * (numColumns - 1)) / numColumns);
  const cardImgH = Math.round(cardWidth * getImageRatio(type));
  const cardTotalH = liveAsRows ? LIVE_ROW_HEIGHT : cardImgH + 52;

  // Categories for the sidebar
  const categories: SidebarCat[] = useMemo(() => {
    switch (type) {
      case "live": return applyOrder("live", liveCategories).map((c) => ({ category_id: c.category_id, category_name: c.category_name }));
      case "movies": return applyOrder("movies", vodCategories).map((c) => ({ category_id: c.category_id, category_name: c.category_name }));
      case "series": return applyOrder("series", seriesCategories).map((c) => ({ category_id: c.category_id, category_name: c.category_name }));
      default: return [];
    }
  }, [type, liveCategories, vodCategories, seriesCategories, applyOrder]);

  // Parental controls filter — null when the feature is disabled or the
  // profile has no parental_controls config. When non-null, provides:
  //   filterStream(id, name) → bool — should this stream be visible?
  //   filterCategory(name)   → bool — should this category appear in sidebar?
  const parentalFilter = useMemo(() => {
    const pc = activeProfile?.parental_controls;
    if (!pc?.enabled) return null;
    const showUnclassified = pc.show_unclassified ?? false;
    // Use max_age when set (new style). Fall back to deriving from legacy allowed_ratings.
    let maxAge: number;
    if (pc.max_age != null) {
      maxAge = pc.max_age;
    } else {
      const CERT_AGE: Record<string, number> = {
        U: 0, G: 0, PG: 8, "12A": 12, "12": 12, "15": 15, "18": 18, R18: 18,
        "PG-13": 13, R: 17, "NC-17": 18, "TV-MA": 18, "TV-14": 14, "TV-G": 0, "TV-PG": 8,
        "16": 16, "17": 17,
      };
      const allowed = pc.allowed_ratings ?? [];
      maxAge = allowed.length === 0 ? -1 : Math.max(...allowed.map((r) => CERT_AGE[r] ?? 0));
    }
    const allow18Plus = maxAge >= 18;
    return {
      // contentType: "live" | "movies" | "series"
      // Live TV is never filtered by rating — only XXX category/name is blocked.
      filterStream: (id: number, name: string, contentType?: string): boolean => {
        if (!allow18Plus && /xxx/i.test(name)) return false;
        if (contentType === "live") return true;
        const r = streamRatings.get(id);
        if (!r) return showUnclassified;
        return r.age_int <= maxAge;
      },
      filterCategory: (catName: string): boolean => {
        if (!allow18Plus && /xxx/i.test(catName)) return false;
        return true;
      },
    };
  }, [activeProfile?.parental_controls, streamRatings]);

  // Human-readable label for the age restriction badge, e.g. "12+" or "PG (8+)"
  const parentalAgeLabel = useMemo(() => {
    const pc = activeProfile?.parental_controls;
    if (!pc?.enabled) return "";
    const maxAge = pc.max_age ?? -1;
    if (maxAge <= 0) return "Universal";
    if (maxAge <= 8) return "PG (8+)";
    if (maxAge <= 12) return "12+";
    if (maxAge <= 13) return "13+";
    if (maxAge <= 15) return "15+";
    if (maxAge <= 17) return "17+";
    return "18+";
  }, [activeProfile?.parental_controls]);

  // category_id → category_name for live streams (used in search parental filter)
  const liveCatMap = useMemo(() => {
    const m = new Map<string, string>();
    liveCategories.forEach((c) => m.set(c.category_id, c.category_name));
    return m;
  }, [liveCategories]);

  // Parental-filtered category list — hides XXX sidebar entries when <18 allowed
  const filteredCategories: SidebarCat[] = useMemo(() => {
    if (!parentalFilter) return categories;
    return categories.filter((c) => parentalFilter.filterCategory(c.category_name));
  }, [categories, parentalFilter]);

  // If the user landed here on a category that THEY have hidden in their
  // organised list, jump them to the first visible real category instead.
  // Otherwise the page would silently show content from a category the
  // sidebar refuses to display, which is confusing. Special pinned ids
  // (favourites / recently / suggested / recent / watchlist) are never
  // redirected. Runs only once per mount.
  useEffect(() => {
    if (redirectedFromHiddenRef.current) return;
    if (filteredCategories.length === 0) return; // wait until prefs/data load
    const pinnedIds = new Set([
      "favourites", "recently", "suggested", "recent", "watchlist", CINEMA_CATEGORY_ID,
    ]);
    if (pinnedIds.has(selectedCategoryId)) return;
    // User-pinned groups use a "group:<id>" id — never redirect off them.
    if (String(selectedCategoryId).startsWith("group:")) return;
    const visible = filteredCategories.find((c) => String(c.category_id) === String(selectedCategoryId));
    if (visible) return;
    // Current category is hidden — switch to the first visible one.
    redirectedFromHiddenRef.current = true;
    const first = filteredCategories[0];
    setSelectedCategoryId(first.category_id);
    setSelectedCategoryName(first.category_name);
    setInitialFocusId(first.category_id);
  }, [filteredCategories, selectedCategoryId]);

  // User-pinned custom groups for this type. Pinned groups appear in the
  // sidebar (between the system pinned rows and the real categories) using
  // each group's own colour + icon.
  const pinnedGroups = useMemo(
    () => getGroupsByType(type as GroupType).filter((g) => g.pinned),
    [getGroupsByType, type],
  );

  const sidebarData: SidebarCat[] = useMemo(() => {
    const pinned: SidebarCat[] = [];
    pinned.push({
      category_id: "recently",
      category_name: type === "live" ? "Recently Watched" : "Continue Watching",
    });
    pinned.push({ category_id: "favourites", category_name: "Favourites" });
    if (type === "movies" || type === "series") {
      pinned.push({ category_id: "suggested", category_name: "Suggested for You" });
      if (type === "movies" && cinemaAvailable) {
        pinned.push({
          category_id: CINEMA_CATEGORY_ID,
          category_name: "Cinema Releases",
          iconLib: "mci",
          iconName: "star",
          iconColor: "#FFD700",
        });
      }
      pinned.push({ category_id: "recent", category_name: "Recently Added" });
    }
    const userPinned: SidebarCat[] = pinnedGroups.map((g) => {
      const def = getGroupIconDef(g.icon_key);
      return {
        category_id: `group:${g.id}`,
        category_name: g.name,
        accent: g.color,
        iconLib: def.lib === "feather" ? "feather" : "mci",
        iconName: def.name,
      };
    });
    return [...pinned, ...userPinned, ...filteredCategories];
  }, [type, filteredCategories, pinnedGroups, cinemaAvailable]);

  // All streams for this section type (used for section-wide search)
  const allSectionStreams: ContentItem[] = useMemo(() => {
    switch (type) {
      case "live": return liveStreams;
      case "movies": return [...vodStreams, ...cinemaMovies];
      case "series": return seriesList;
      default: return [];
    }
  }, [type, liveStreams, vodStreams, cinemaMovies, seriesList]);

  // Pre-build a category_id → items[] index once per stream list change.
  // Category switches become an O(1) Map lookup instead of an O(n) filter.
  const categoryIndex = useMemo(() => {
    const map = new Map<string, ContentItem[]>();
    for (const s of allSectionStreams) {
      const cid = (s as any).category_id as string;
      if (!cid) continue;
      let bucket = map.get(cid);
      if (!bucket) { bucket = []; map.set(cid, bucket); }
      bucket.push(s);
    }
    return map;
  }, [allSectionStreams]);

  // Normal category content — O(1) lookup, no dependency on watchEntries.
  // This memo only re-runs when streams or selected category actually changes.
  const normalContent: ContentItem[] = useMemo(() => {
    if (isSpecialView) return [];
    // Pinned user group — resolve group items against the section streams
    // so the existing card grid (favourites, watch badges, etc.) works
    // unchanged. Preserves the order the user added items in.
    if (String(selectedCategoryId).startsWith("group:")) {
      const groupId = selectedCategoryId.slice("group:".length);
      const groupItems = getItemsByGroup(groupId);
      if (groupItems.length === 0) return [];
      const lookup = new Map<string, ContentItem>();
      for (const s of allSectionStreams) {
        const sid = type === "series"
          ? (s as Series).series_id
          : (s as LiveStream | VodStream).stream_id;
        lookup.set(String(sid), s);
      }
      const out: ContentItem[] = [];
      const seen = new Set<string>();
      for (const it of groupItems) {
        const k = String(it.stream_id);
        if (seen.has(k)) continue;
        const hit = lookup.get(k);
        if (hit) { out.push(hit); seen.add(k); }
      }
      return out;
    }
    return categoryIndex.get(selectedCategoryId) ?? [];
  }, [isSpecialView, selectedCategoryId, categoryIndex, getItemsByGroup, allSectionStreams, type]);

  // Special views (Favourites / Recently Watched / Recently Added / Suggested).
  const specialContent: ContentItem[] = useMemo(() => {
    if (!isSpecialView) return [];
    // Recently Added — pre-computed once during sync (DataContext) so this
    // screen mounts instantly even with 50k+ movies/series in the catalogue.
    if (isRecentlyAddedView) {
      return type === "movies" ? recentMovies : recentSeries;
    }
    // Suggested for You — genre-tally based on watch history. See
    // client/lib/suggestions.ts for the exact algorithm. Returns []
    // when the user has no watch history; the UI surfaces a prompt.
    if (isSuggestedView) {
      const r = computeSuggestions({
        type: type as "movies" | "series",
        items: type === "movies" ? vodStreams : (seriesList as any),
        categories: type === "movies" ? vodCategories : seriesCategories,
        watched: watchEntries,
        favourites: getFavouritesByType(type as "movies" | "series"),
      });
      return r.items as any;
    }
    if (isWatchlistView) {
      // Resolve watchlist rows to actual cached stream/series objects so the
      // existing card grid (with onPress→MovieInfo/SeriesDetail navigation,
      // favourite toggle, watch badges, etc.) works unchanged.
      //
      // Matching strategy (in order):
      //   1. By embedded stream_id / series_id in content_data (fast, exact).
      //   2. By normalised name (case/punctuation-insensitive). This
      //      catches rows added from the external TMDB page that don't
      //      carry an xtream id but whose title matches a real stream.
      const wantType: "movie" | "series" = type === "series" ? "series" : "movie";
      const matches: ContentItem[] = [];
      const seen = new Set<number>();
      const pushUnique = (item: ContentItem | undefined) => {
        if (!item) return;
        const id = type === "series"
          ? (item as Series).series_id
          : (item as VodStream).stream_id;
        if (seen.has(id)) return;
        seen.add(id);
        matches.push(item);
      };

      // Build lookup indices once.
      const idIdx = new Map<string, ContentItem>();
      const nameIdx = new Map<string, ContentItem>();
      const source: ContentItem[] = type === "series" ? seriesList : allSectionStreams;
      for (const it of source) {
        const idKey = type === "series"
          ? String((it as Series).series_id)
          : String((it as VodStream).stream_id);
        idIdx.set(idKey, it);
        const nKey = normaliseSearch((it as any).name);
        if (nKey && !nameIdx.has(nKey)) nameIdx.set(nKey, it);
      }

      for (const w of watchlistItems) {
        if (w.content_type !== wantType) continue;
        const d: any = w.content_data ?? {};
        const sid = wantType === "series" ? (d.series_id ?? d.stream_id) : d.stream_id;
        let hit: ContentItem | undefined;
        if (sid != null) hit = idIdx.get(String(sid));
        if (!hit && d.name) hit = nameIdx.get(normaliseSearch(d.name));
        pushUnique(hit);
      }
      return matches;
    }
    if (isFavouritesView) {
      const favIds = new Set(
        getFavouritesByType(type as "live" | "movies" | "series").map((f) => f.stream_id)
      );
      switch (type) {
        case "live": return liveStreams.filter((s) => favIds.has(s.stream_id));
        case "movies": return allSectionStreams.filter((s) => favIds.has((s as VodStream).stream_id));
        case "series": return seriesList.filter((s) => favIds.has(s.series_id));
        default: return [];
      }
    }
    // Recently Watched — walk watchEntries (newest-first), dedup, hydrate
    if (type === "live") {
      const out: LiveStream[] = [];
      const seen = new Set<string>();
      const idx = new Map<string, LiveStream>();
      for (const s of liveStreams) idx.set(String(s.stream_id), s);
      for (const e of watchEntries) {
        if (e.content_type !== "live" || !e.stream_id) continue;
        const k = String(e.stream_id);
        if (seen.has(k)) continue;
        const s = idx.get(k);
        if (s) { out.push(s); seen.add(k); }
      }
      return out;
    }
    // Movies/series — "Continue Watching": only in-progress entries
    // (saved playback time and not yet completed).
    const inProgress = (e: typeof watchEntries[number]) =>
      !e.is_completed && (e.current_time ?? 0) > 0;
    if (type === "movies") {
      const out: VodStream[] = [];
      const seen = new Set<string>();
      const idx = new Map<string, VodStream>();
      for (const v of vodStreams) idx.set(String(v.stream_id), v);
      for (const v of cinemaMovies) idx.set(cinemaHistoryId(v.cinemaId), v);
      for (const e of watchEntries) {
        if (e.content_type !== "movie" || !e.stream_id) continue;
        if (!inProgress(e)) continue;
        const k = String(e.stream_id);
        if (seen.has(k)) continue;
        const v = idx.get(k);
        if (v) { out.push(v); seen.add(k); }
      }
      return out;
    }
    if (type === "series") {
      // Series stay in Recently Watched even when fully completed — this
      // list is the user's "shows I'm watching" shelf. Badging on each
      // card distinguishes WATCHED / NEW EPISODES / CONTINUE.
      const out: Series[] = [];
      const seen = new Set<string>();
      const idx = new Map<string, Series>();
      for (const s of seriesList) idx.set(String(s.series_id), s);
      for (const e of watchEntries) {
        if (e.content_type !== "series" || !e.series_id) continue;
        const k = String(e.series_id);
        if (seen.has(k)) continue;
        const s = idx.get(k);
        if (s) { out.push(s); seen.add(k); }
      }
      return out;
    }
    return [];
  }, [isSpecialView, isFavouritesView, isRecentlyView, isRecentlyAddedView, isSuggestedView, isWatchlistView, type, liveStreams, vodStreams, cinemaMovies, allSectionStreams, seriesList, recentMovies, recentSeries, vodCategories, seriesCategories, getFavouritesByType, watchEntries, watchlistItems]);

  const categoryContent: ContentItem[] = isSpecialView ? specialContent : normalContent;

  // Parental-filter the current category/special-view content list
  const filteredCategoryContent: ContentItem[] = useMemo(() => {
    if (!parentalFilter) return categoryContent;
    return categoryContent.filter((item) => {
      const id = type === "series"
        ? (item as Series).series_id
        : (item as LiveStream | VodStream).stream_id;
      return parentalFilter.filterStream(id, (item as any).name ?? "", type);
    });
  }, [categoryContent, parentalFilter, type]);

  // Progressive render: on slower devices, mounting a FlatList with hundreds
  // of cards (images + focus handlers + watch-state lookups) blocks the JS
  // thread on first paint. Instead we expose a tiny first batch immediately,
  // then grow the visible window off-screen in larger chunks until the full
  // list is materialised. The user sees results almost instantly and the
  // remainder fills in before they can scroll past it.
  const PROGRESSIVE_STEPS = [16, 60, 200, 600, 2000];
  const [renderLimit, setRenderLimit] = useState(PROGRESSIVE_STEPS[0]);

  // One subscription for the whole screen; the focused card supplies the action.
  useTvLongPress();

  // Scroll to top whenever the selected category changes (without remounting FlatList)
  useEffect(() => {
    flatListRef.current?.scrollToOffset({ offset: 0, animated: false });
  }, [selectedCategoryId]);

  // Search results — searches entire section, not just current category.
  // Punctuation/accents/case are ignored so e.g. "ru pauls drag race"
  // matches "RuPaul's Drag Race".
  const searchResults: ContentItem[] = useMemo(() => {
    if (!trimmedQuery) return [];
    const out: ContentItem[] = [];
    for (const s of allSectionStreams) {
      if (normalisedName(s).includes(trimmedQuery)) {
        out.push(s);
        if (out.length >= SEARCH_LIMIT) break;
      }
    }
    return out;
  }, [trimmedQuery, allSectionStreams]);

  // Parental-filter search results the same way as category content.
  // For live TV we additionally block any channel whose category is restricted
  // (e.g. "XXX ADULT ONLY XXX"), even when the channel's own name passes the
  // name check.  When the user has unlocked via PIN, skip the filter entirely.
  const filteredSearchResults: ContentItem[] = useMemo(() => {
    if (!parentalFilter || parentalSearchUnlocked) return searchResults;
    return searchResults.filter((item) => {
      const id = type === "series"
        ? (item as Series).series_id
        : (item as LiveStream | VodStream).stream_id;
      if (!parentalFilter.filterStream(id, (item as any).name ?? "", type)) return false;
      if (type === "live") {
        const catId = (item as LiveStream).category_id;
        const catName = catId ? (liveCatMap.get(catId) ?? "") : "";
        if (catName && !parentalFilter.filterCategory(catName)) return false;
      }
      return true;
    });
  }, [searchResults, parentalFilter, parentalSearchUnlocked, type, liveCatMap]);

  const fullDisplayContent = isSearching ? filteredSearchResults : filteredCategoryContent;

  // Reset progressive limit whenever the underlying list identity changes
  // (category switch, search, type change, special view toggle). Then ramp
  // it up on requestAnimationFrame + setTimeout so the bumps land AFTER
  // the first paint and don't compete with it for the JS thread.
  useEffect(() => {
    setRenderLimit(PROGRESSIVE_STEPS[0]);
    if (fullDisplayContent.length <= PROGRESSIVE_STEPS[0]) return;
    let cancelled = false;
    const timers: ReturnType<typeof setTimeout>[] = [];
    let raf: number | null = null;
    const schedule = (i: number, delay: number) => {
      timers.push(setTimeout(() => {
        if (cancelled) return;
        setRenderLimit(PROGRESSIVE_STEPS[i]);
      }, delay));
    };
    raf = requestAnimationFrame(() => {
      if (cancelled) return;
      schedule(1, 32);   // ~1 frame after paint
      schedule(2, 120);
      schedule(3, 280);
      schedule(4, 600);
    });
    return () => {
      cancelled = true;
      if (raf !== null) cancelAnimationFrame(raf);
      timers.forEach(clearTimeout);
    };
  }, [selectedCategoryId, isSearching, type, isFavouritesView, isRecentlyView, fullDisplayContent.length]);

  const displayContent = useMemo(
    () => fullDisplayContent.slice(0, renderLimit),
    [fullDisplayContent, renderLimit],
  );

  const handleItemPress = useCallback((item: ContentItem) => {
    if (type === "live") {
      const s = item as LiveStream;
      navigation.navigate("LivePreview", {
        streamId: s.stream_id,
        name: s.name,
        streamUrl: xtreamApi.getLiveStreamUrl(s.stream_id),
        thumbnail: s.stream_icon ?? undefined,
        streamIcon: s.stream_icon ?? undefined,
        categoryId: selectedCategoryId ?? undefined,
      });
    } else if (type === "movies") {
      const s = item as VodStream;
      navigation.navigate("MovieInfo", {
        streamId: s.stream_id,
        name: s.name,
        streamIcon: s.stream_icon ?? undefined,
        containerExtension: s.container_extension,
        categoryId: s.category_id,
        cinemaId: "cinemaId" in s ? String(s.cinemaId) : undefined,
      });
    } else {
      const s = item as Series;
      const watch = getBySeriesId(s.series_id);
      const initialSeason =
        watch && watch.season_num != null ? Number(watch.season_num) : undefined;
      navigation.navigate("SeriesDetail", {
        seriesId: s.series_id,
        seriesName: s.name,
        cover: s.cover,
        initialSeason,
      });
    }
  }, [type, selectedCategoryId, navigation, getBySeriesId]);

  // Refresh watch history when this screen comes into focus
  useFocusEffect(
    useCallback(() => {
      refetchHistory();
    }, [refetchHistory])
  );

  const handleClearAll = useCallback(async () => {
    setClearing(true);
    try {
      if (isFavouritesView) {
        await clearAllFavourites(type as "live" | "movies" | "series");
      } else if (isRecentlyView) {
        const ct = type === "live" ? "live" : type === "movies" ? "movie" : "series";
        await clearHistory(ct as "live" | "movie" | "series");
      }
    } finally {
      setClearing(false);
      setShowClearConfirm(false);
    }
  }, [isFavouritesView, isRecentlyView, type, clearAllFavourites, clearHistory]);

  const handleLongPress = useCallback((item: ContentItem) => {
    if (isSearching) return;
    const streamId = getStreamId(item, type);
    toggleFavourite({
      streamId,
      streamType: type as "live" | "movies" | "series",
      streamName: item.name,
      streamIcon: getIconUrl(item),
      categoryId: "category_id" in item ? (item as any).category_id : null,
    });
  }, [isSearching, type, toggleFavourite]);

  // Which card currently has the in-card action picker open (Manage mode on
  // a normal category). Only one card can show its picker at a time.
  const [pickerOpenId, setPickerOpenId] = useState<string | null>(null);

  // Edit-mode action: delete from fav/recent lists, or open per-card picker
  // (Add to Favourites / Add to Watchlist) on normal categories. Single tap
  // on a focused card — fully D-pad-friendly.
  const handleEditPress = useCallback(
    (item: ContentItem) => {
      const streamId = getStreamId(item, type);
      if (isFavouritesView) {
        toggleFavourite({
          streamId,
          streamType: type as "live" | "movies" | "series",
          streamName: item.name,
          streamIcon: getIconUrl(item),
          categoryId: "category_id" in item ? (item as any).category_id : null,
        });
        return;
      }
      if (isRecentlyView) {
        const entry =
          type === "series"
            ? getBySeriesId((item as Series).series_id)
            : getByStreamId("cinemaId" in item ? cinemaHistoryId(String(item.cinemaId)) : streamId);
        if (entry) removeWatchEntry(entry.id);
        return;
      }
      if (isWatchlistView) {
        const wantType: "movie" | "series" = type === "series" ? "series" : "movie";
        const row = findWatchlistByStreamId(streamId, wantType);
        if (row) removeWatchlistRow(row.id);
        return;
      }
      // Normal category: tap opens (or closes) a small action picker
      // overlay on the card with Favourite + Watchlist toggles.
      const id = "stream_id" in item
        ? String((item as LiveStream | VodStream).stream_id)
        : "series_id" in item
          ? String((item as Series).series_id)
          : String(item.num);
      setPickerOpenId((cur) => (cur === id ? null : id));
    },
    [type, isFavouritesView, isRecentlyView, isWatchlistView, toggleFavourite, getByStreamId, getBySeriesId, removeWatchEntry, findWatchlistByStreamId, removeWatchlistRow],
  );

  // Auto-exit edit mode whenever the category changes — semantics differ
  // between Favourites/Recently Watched (delete) and a normal category
  // (favourite toggle), so the user explicitly opts in per category.
  useEffect(() => {
    setEditMode(false);
    setPickerOpenId(null);
  }, [selectedCategoryId, type]);

  // Also exit if the current view becomes invalid for edit mode
  useEffect(() => {
    if (!editMode) return;
    if (isSearching || categoryContent.length === 0) {
      setEditMode(false);
    }
  }, [editMode, isSearching, categoryContent.length]);

  // Close any open picker whenever Manage mode itself is toggled off.
  useEffect(() => {
    if (!editMode) setPickerOpenId(null);
  }, [editMode]);

  const editAction: "delete" | "favourite" =
    isFavouritesView || isRecentlyView || isWatchlistView ? "delete" : "favourite";

  // O(1) favourite lookup per card. Built once per favourites change instead
  // of running an O(n) `favourites.some()` inside every visible card on every
  // re-render — a major win when scrolling through a long list with many
  // favourites stored.
  const favIdSet = useMemo(() => {
    const set = new Set<number>();
    for (const f of getFavouritesByType(type as "live" | "movies" | "series")) {
      set.add(f.stream_id);
    }
    return set;
  }, [getFavouritesByType, type]);

  // O(1) watchlist lookup per card. Watchlist only supports movies/series
  // (the table type is `"movie" | "series"`), so this is empty for live TV.
  const watchlistIdSet = useMemo(() => {
    const set = new Set<string>();
    if (type === "live") return set;
    const wantType: "movie" | "series" = type === "series" ? "series" : "movie";
    for (const w of watchlistItems) {
      if (w.content_type !== wantType) continue;
      const cd = w.content_data;
      const sid = cd?.series_id ?? cd?.stream_id ?? w.content_id;
      if (sid != null) set.add(String(sid));
    }
    return set;
  }, [watchlistItems, type]);

  // Build the per-card picker actions list. Live TV only shows Favourites
  // (Watchlist doesn't support live). Movies + Series show both.
  const buildPickerActions = useCallback(
    (item: ContentItem): PickerAction[] => {
      const streamId = getStreamId(item, type);
      const actions: PickerAction[] = [];
      actions.push({
        key: "fav",
        label: "Favourites",
        icon: "star",
        active: favIdSet.has(streamId),
        onPress: () => {
          toggleFavourite({
            streamId,
            streamType: type as "live" | "movies" | "series",
            streamName: item.name,
            streamIcon: getIconUrl(item),
            categoryId: "category_id" in item ? (item as any).category_id : null,
          });
        },
      });
      if (type !== "live") {
        const wantType: "movie" | "series" = type === "series" ? "series" : "movie";
        actions.push({
          key: "watchlist",
          label: "Watchlist",
          icon: "bookmark",
          active: watchlistIdSet.has(String(streamId)),
          onPress: () => {
            toggleWatchlist({
              contentId: streamId,
              contentType: wantType,
              contentData: {
                ...(wantType === "series"
                  ? { series_id: streamId }
                  : { stream_id: streamId }),
                name: item.name,
                poster: getIconUrl(item),
                source: "app",
              },
            });
          },
        });
      }
      // User-defined groups (per profile, per type). One button per group.
      const groupsForType = getGroupsByType(type as "live" | "movies" | "series");
      for (const g of groupsForType) {
        const iconProps = getGroupIconProps(g.icon_key);
        actions.push({
          key: `group-${g.id}`,
          label: g.name,
          icon: "folder",
          iconComponent: iconProps.Component as any,
          iconName: iconProps.name as string,
          tint: g.color,
          active: isInGroup(g.id, streamId),
          onPress: () => {
            toggleGroupItem({
              groupId: g.id,
              streamId,
              streamName: item.name,
              streamIcon: getIconUrl(item),
              categoryId: "category_id" in item ? (item as any).category_id : null,
            });
          },
        });
      }
      return actions;
    },
    [type, favIdSet, watchlistIdSet, toggleFavourite, toggleWatchlist, getGroupsByType, isInGroup, toggleGroupItem],
  );

  const closePicker = useCallback(() => setPickerOpenId(null), []);

  const getItemId = useCallback((item: ContentItem) => {
    if ("stream_id" in item) return String((item as LiveStream | VodStream).stream_id);
    if ("series_id" in item) return String((item as Series).series_id);
    return String(item.num);
  }, []);

  // Stable per-card handlers so React.memo on ContentCard actually skips
  // re-renders. Without these, every parent state change (focus on any other
  // card, search keystroke, etc.) would create new arrow functions and
  // re-render every visible card — the root cause of the "selector lags
  // behind scrolling" feeling on TV remotes.
  const onCardPress = useCallback(
    (item: ContentItem) => (editMode ? handleEditPress(item) : handleItemPress(item)),
    [editMode, handleEditPress, handleItemPress],
  );

  // Row height — feeds FlashList's `estimatedItemSize` so it can pre-allocate
  // recyclable cell pools and locate any row by index in O(1).
  const rowHeight = cardTotalH + gap;

  const renderContentItem = useCallback(
    ({ item }: { item: ContentItem }) => {
      const sid = getStreamId(item, type);
      const watchEntry =
        type === "series"
          ? getBySeriesId((item as Series).series_id)
          : type !== "live"
            ? getByStreamId("cinemaId" in item ? cinemaHistoryId(String(item.cinemaId)) : sid)
            : undefined;
      // Series-wide aggregate uses the current Series.last_modified to
      // detect "new episodes since I last watched" (snapshot stored on
      // the most recent recently_watched row).
      const seriesProgress = type === "series"
        ? getSeriesProgress((item as Series).series_id, (item as Series).last_modified)
        : undefined;
      const itemId = "stream_id" in item
        ? String((item as LiveStream | VodStream).stream_id)
        : "series_id" in item
          ? String((item as Series).series_id)
          : String(item.num);
      const showPicker =
        editMode && !isSearching && editAction === "favourite" && pickerOpenId === itemId;
      // Edit mode keeps the card, which owns the Manage picker UI — rows do not
      // reimplement it. Uses the same `liveAsRows` decision as the geometry
      // above, so the item and the box it is given always agree.
      if (liveAsRows) {
        return (
          <LiveChannelRow
            item={item as LiveStream}
            width={cardWidth}
            isFavourited={!isSearching && favIdSet.has(sid)}
            onPress={onCardPress as (i: LiveStream) => void}
            onLongPress={handleLongPress as (i: LiveStream) => void}
          />
        );
      }

      return (
        <ContentCard
          item={item}
          type={type}
          onPress={onCardPress}
          onLongPress={handleLongPress}
          isFavourited={!isSearching && favIdSet.has(sid)}
          cardWidth={cardWidth}
          cardHeight={cardTotalH}
          watchEntry={watchEntry}
          seriesProgress={seriesProgress}
          editMode={editMode && !isSearching}
          editAction={editAction}
          pickerOpen={showPicker}
          pickerActions={showPicker ? buildPickerActions(item) : undefined}
          onPickerClose={closePicker}
        />
      );
    },
    [
      type, onCardPress, handleLongPress, isSearching, favIdSet,
      liveAsRows,
      cardWidth, cardTotalH, editMode, editAction, getByStreamId, getBySeriesId, getSeriesProgress,
      pickerOpenId, buildPickerActions, closePicker,
    ],
  );

  // Stable sidebar press handler — referenced by every sidebar item so
  // CategorySidebarItem (memo'd) doesn't re-render when an unrelated
  // sibling gains focus.
  const handleSidebarPress = useCallback(
    (item: SidebarCat) => {
      if (item.category_id === selectedCategoryId) return;
      setCategorySwitching(true);
      const nextId = item.category_id;
      const nextName = item.category_name;
      requestAnimationFrame(() => {
        setSelectedCategoryId(nextId);
        setSelectedCategoryName(nextName);
      });
    },
    [selectedCategoryId],
  );

  // Capture the category we entered with so the matching sidebar row gets
  // initial TV focus on first mount (instead of focus defaulting to the
  // header back button). We clear it ~400ms after mount so subsequent
  // D-pad navigation isn't pulled back to the original row on every
  // re-render (which is what was making the entry row look "stuck" with a
  // hover overlay while the user scrolled past it).
  const [initialFocusId, setInitialFocusId] = useState<string>(categoryId);
  useEffect(() => {
    const t = setTimeout(() => setInitialFocusId(""), 400);
    return () => clearTimeout(t);
  }, []);
  const renderSidebarItem = useCallback(
    ({ item }: { item: SidebarCat }) => {
      const id = item.category_id;
      const isPinned =
        id === "recently" || id === "favourites" || id === "suggested" || id === "recent" || id === CINEMA_CATEGORY_ID;
      return (
        <CategorySidebarItem
          item={item}
          isSelected={id === selectedCategoryId}
          isFav={id === "favourites"}
          isRecent={id === "recently"}
          isSuggested={id === "suggested"}
          isPinned={isPinned}
          onPress={handleSidebarPress}
          hasTVPreferredFocus={initialFocusId !== "" && id === initialFocusId}
        />
      );
    },
    [selectedCategoryId, handleSidebarPress, initialFocusId],
  );

  const sectionPlaceholder =
    type === "live" ? "Search all live channels..." :
    type === "movies" ? "Search all movies..." :
    "Search all series...";

  // For the watchlist view, count = total watchlist rows for this type (even
  // if some don't map to a cached stream and aren't rendered). Keeps the
  // header badge truthful when TMDB-only entries are filtered out.
  const watchlistTotal = useMemo(() => {
    if (!isWatchlistView) return 0;
    const wantType: "movie" | "series" = type === "series" ? "series" : "movie";
    return watchlistItems.filter((w) => w.content_type === wantType).length;
  }, [isWatchlistView, watchlistItems, type]);
  const countDisplay = isSearching
    ? searchResults.length
    : isWatchlistView
      ? watchlistTotal
      : fullDisplayContent.length;

  const showParentalBadge = !!parentalFilter && (type === "movies" || type === "series");
  const blockedCount = showParentalBadge && isSearching && !parentalSearchUnlocked
    ? searchResults.length - filteredSearchResults.length
    : 0;
  const showFilteredNotice = blockedCount > 0;

  const searchBarHeader = (
    <View style={styles.searchBarWrap}>
      {/* Search input row — splits 50/50 with age restriction badge on parental profiles */}
      <View style={styles.searchBarRow}>
        <View style={[
          styles.searchBar,
          isSearching && styles.searchBarActive,
          showParentalBadge && styles.searchBarHalf,
        ]}>
          <Feather
            name="search"
            size={15}
            color={isSearching ? Colors.dark.accent : Colors.dark.textSecondary}
          />
          <TextInput
            ref={searchInputRef}
            style={styles.searchInput}
            placeholder={sectionPlaceholder}
            placeholderTextColor={Colors.dark.textSecondary}
            value={query}
            onChangeText={setQuery}
            autoCapitalize="none"
            autoCorrect={false}
            returnKeyType="search"
            clearButtonMode="while-editing"
            submitBehavior="blurAndSubmit"
            onSubmitEditing={() => {
              setSubmittedQuery(query);
              searchInputRef.current?.blur();
              Keyboard.dismiss();
            }}
            focusable={!Platform.isTV}
          />
          {query.length > 0 ? (
            <SearchClearButton
              size="sm"
              onPress={() => {
                setQuery("");
                setSubmittedQuery("");
                searchInputRef.current?.blur();
                Keyboard.dismiss();
              }}
            />
          ) : null}
        </View>
        {showParentalBadge ? (
          <View style={styles.parentalBadge}>
            <Feather name="shield" size={13} color={Colors.dark.accent} />
            <View style={styles.parentalBadgeText}>
              <ThemedText style={styles.parentalBadgeLabel}>Age Restriction</ThemedText>
              <ThemedText style={styles.parentalBadgeAge}>{parentalAgeLabel}</ThemedText>
            </View>
          </View>
        ) : null}
      </View>
      {isSearching ? (
        <View style={styles.searchMeta}>
          <ThemedText style={styles.searchMetaText}>
            {searchResults.length === 0
              ? `No results for "${submittedQuery}"`
              : `${searchResults.length} results across all ${
                  type === "live" ? "channels" : type === "movies" ? "movies" : "series"
                }`}
          </ThemedText>
          {searchResults.length === SEARCH_LIMIT ? (
            <ThemedText style={styles.searchMetaLimit}>
              (first {SEARCH_LIMIT} shown)
            </ThemedText>
          ) : null}
        </View>
      ) : null}
      {/* Filtered-content notice — shown when parental controls hid some search results */}
      {showFilteredNotice ? (
        <Pressable
          style={[styles.parentalNotice, noticeFocused && styles.parentalNoticeFocused]}
          onPress={() => {
            setPinEntry("");
            setPinError(false);
            setShowParentalPinModal(true);
          }}
          onFocus={() => setNoticeFocused(true)}
          onBlur={() => setNoticeFocused(false)}
          focusable
        >
          {noticeFocused ? (
            <View style={styles.parentalNoticeFocusOverlay} pointerEvents="none" />
          ) : null}
          <Feather name="eye-off" size={13} color={noticeFocused ? "#fff" : Colors.dark.accent} style={{ marginRight: 6 }} />
          <ThemedText style={[styles.parentalNoticeText, noticeFocused && styles.parentalNoticeTextFocused]}>
            {`${blockedCount} item${blockedCount === 1 ? "" : "s"} hidden due to age restrictions. `}
            <ThemedText style={[styles.parentalNoticeLink, noticeFocused && styles.parentalNoticeLinkFocused]}>Enter PIN to view all content.</ThemedText>
          </ThemedText>
        </Pressable>
      ) : null}
    </View>
  );

  if (isSyncing && categoryContent.length === 0 && !isSpecialView) {
    return (
      <ThemedView style={styles.container}>
        <View style={styles.centered}>
          <ActivityIndicator size="large" color={Colors.dark.accent} />
          <ThemedText style={styles.loadingText}>Loading content...</ThemedText>
        </View>
      </ThemedView>
    );
  }

  const pinSm = Math.min(width, height) < 420;
  const pinCardW = Math.min(260, width * 0.82);
  const pinKeySize = pinSm ? 38 : 46;
  const pinKeyGap = pinSm ? 5 : 6;
  const pinPadW = 3 * pinKeySize + 2 * pinKeyGap;
  const pinVPad = pinSm ? Spacing.md : Spacing.xl;
  const pinHPad = pinSm ? Spacing.lg : Spacing["2xl"];

  return (
    <ThemedView style={styles.container}>
      {/* Parental PIN unlock modal for search results */}
      <Modal
        visible={showParentalPinModal}
        transparent
        animationType="fade"
        onRequestClose={() => setShowParentalPinModal(false)}
      >
        <Pressable style={styles.pinModalBackdrop} onPress={() => setShowParentalPinModal(false)}>
          <Pressable
            style={[styles.pinModalCard, { width: pinCardW, paddingVertical: pinVPad, paddingHorizontal: pinHPad, gap: pinSm ? 6 : Spacing.sm }]}
            onPress={(e) => e.stopPropagation()}
          >
            <Pressable style={styles.pinModalClose} onPress={() => setShowParentalPinModal(false)}>
              <Feather name="x" size={14} color={Colors.dark.textSecondary} />
            </Pressable>
            <Feather name="shield" size={pinSm ? 18 : 22} color={Colors.dark.accent} />
            <ThemedText style={[styles.pinModalTitle, pinSm && { fontSize: 13 }]}>Enter Parental PIN</ThemedText>
            <ThemedText style={[styles.pinModalSub, pinSm && { fontSize: 11 }]}>Enter your PIN to view all search results</ThemedText>
            <Animated.View style={[styles.pinDots, { transform: [{ translateX: pinShakeAnim }] }]}>
              {[0, 1, 2, 3].map((i) => (
                <View
                  key={i}
                  style={[
                    styles.pinDot,
                    {
                      borderColor: pinError ? Colors.dark.error : pinEntry.length > i ? Colors.dark.accent : Colors.dark.border,
                      backgroundColor: pinError ? Colors.dark.error : pinEntry.length > i ? Colors.dark.accent : "transparent",
                    },
                  ]}
                />
              ))}
            </Animated.View>
            {pinError ? (
              <ThemedText style={styles.pinErrorText}>Incorrect PIN</ThemedText>
            ) : (
              <View style={{ height: 14 }} />
            )}
            <View style={[styles.pinPad, { gap: pinKeyGap, width: pinPadW }]}>
              {["1","2","3","4","5","6","7","8","9","","0","⌫"].map((key, idx) => {
                if (!key) return <View key={idx} style={{ width: pinKeySize, height: pinKeySize }} />;
                const isDelete = key === "⌫";
                return (
                  <Pressable
                    key={idx}
                    style={({ pressed }) => [
                      styles.pinKey,
                      { width: pinKeySize, height: pinKeySize },
                      isDelete && styles.pinKeyDelete,
                      pressed && styles.pinKeyActive,
                    ]}
                    onPress={() => {
                      if (isDelete) {
                        setPinEntry((p) => p.slice(0, -1));
                        setPinError(false);
                        return;
                      }
                      if (pinEntry.length >= 4) return;
                      const next = pinEntry + key;
                      setPinEntry(next);
                      if (next.length === 4) {
                        const correctPin = activeProfile?.parental_pin;
                        if (next === correctPin) {
                          setParentalSearchUnlocked(true);
                          setShowParentalPinModal(false);
                          setPinEntry("");
                        } else {
                          setPinError(true);
                          Animated.sequence([
                            Animated.timing(pinShakeAnim, { toValue: 10, duration: 60, useNativeDriver: true }),
                            Animated.timing(pinShakeAnim, { toValue: -10, duration: 60, useNativeDriver: true }),
                            Animated.timing(pinShakeAnim, { toValue: 8, duration: 60, useNativeDriver: true }),
                            Animated.timing(pinShakeAnim, { toValue: -8, duration: 60, useNativeDriver: true }),
                            Animated.timing(pinShakeAnim, { toValue: 0, duration: 60, useNativeDriver: true }),
                          ]).start(() => { setPinEntry(""); setPinError(false); });
                        }
                      }
                    }}
                  >
                    {isDelete
                      ? <Feather name="delete" size={14} color={Colors.dark.textSecondary} />
                      : <ThemedText style={styles.pinKeyText}>{key}</ThemedText>
                    }
                  </Pressable>
                );
              })}
            </View>
          </Pressable>
        </Pressable>
      </Modal>

      {/* Confirm Clear All modal */}
      <Modal
        visible={showClearConfirm}
        transparent
        animationType="fade"
        onRequestClose={() => setShowClearConfirm(false)}
      >
        <View style={styles.modalBackdrop}>
          <View style={styles.modalCard}>
            <Feather
              name={isFavouritesView ? "star" : "clock"}
              size={28}
              color={Colors.dark.accent}
            />
            <ThemedText style={styles.modalTitle}>Clear All?</ThemedText>
            <ThemedText style={styles.modalBody}>
              {isFavouritesView
                ? `Remove all ${type} favourites for this profile?`
                : `Remove all ${type === "movies" ? "movie" : "series"} watch history for this profile?`}
            </ThemedText>
            <View style={styles.modalBtnRow}>
              <ModalBtn
                kind="cancel"
                onPress={() => setShowClearConfirm(false)}
                disabled={clearing}
              >
                <ThemedText style={styles.modalBtnCancelText}>Cancel</ThemedText>
              </ModalBtn>
              <ModalBtn
                kind="confirm"
                onPress={handleClearAll}
                disabled={clearing}
              >
                {clearing
                  ? <ActivityIndicator size="small" color="#fff" />
                  : <ThemedText style={styles.modalBtnConfirmText}>Clear All</ThemedText>}
              </ModalBtn>
            </View>
          </View>
        </View>
      </Modal>

      {/* Header */}
      <View style={[styles.header, { paddingTop: padT, paddingHorizontal: padH }]}>
        <SideMenuButton />
        <BackBtn onPress={() => navigation.goBack()} />
        <View style={styles.headerTitleRow}>
          {isFavouritesView ? (
            <Feather name="star" size={16} color={Colors.dark.accent} />
          ) : isRecentlyView ? (
            <Feather name="clock" size={16} color={Colors.dark.accent} />
          ) : null}
          <ThemedText style={styles.headerTitle} numberOfLines={1}>
            {isSearching ? "Search Results" : selectedCategoryName}
          </ThemedText>
        </View>
        <View style={[
          styles.countBadge,
          isSearching && styles.countBadgeSearch,
        ]}>
          <ThemedText style={[styles.countText, isSearching && styles.countTextSearch]}>
            {countDisplay}
          </ThemedText>
        </View>
        {(type === "movies" || type === "series") ? (
          <>
            <MyWatchlistBtn
              iconOnly={!isLandscapeHeader}
              selected={isWatchlistView}
              onPress={() => {
                setCategorySwitching(true);
                setSelectedCategoryId("watchlist");
                setSelectedCategoryName("My Watchlist");
              }}
            />
            <RequestsBtn iconOnly={!isLandscapeHeader} onPress={() => navigation.navigate("ContentRequests")} />
          </>
        ) : null}
        {type === "live" ? (
          <MultiScreenBtn iconOnly={!isLandscapeHeader} onPress={() => navigation.navigate("MultiScreenLayout")} />
        ) : null}
        {type === "live" && String(selectedCategoryId).startsWith("group:") ? (
          <TvGuideBtn
            iconOnly={!isLandscapeHeader}
            onPress={() => {
              const groupId = selectedCategoryId.slice("group:".length);
              navigation.navigate("TvGuide", { initialGroupId: groupId });
            }}
          />
        ) : null}
        <MyGroupsBtn
          iconOnly={!isLandscapeHeader}
          onPress={() => navigation.navigate("MyGroups", { type })}
        />
        <RefreshBtn onPress={handleRefresh} refreshing={isSyncing} />
        {!isSearching && categoryContent.length > 0 ? (
          <ManageBtn
            iconOnly={!isLandscapeHeader}
            active={editMode}
            onPress={() => setEditMode((v) => !v)}
          />
        ) : null}
        {(isFavouritesView || isRecentlyView) && !isSearching ? (
          <ClearAllButton iconOnly={!isLandscapeHeader} onPress={() => setShowClearConfirm(true)} />
        ) : null}
      </View>

      <View style={[styles.divider, { marginHorizontal: padH }]} />

      {/* Body: sidebar + main content */}
      <View style={styles.body}>
        {/* Category Sidebar */}
        <View style={[styles.sidebar, { paddingLeft: Math.max(insets.left, Spacing.xs), paddingBottom: padB }]}>
          <FlatList
            data={sidebarData}
            keyExtractor={(item) => item.category_id}
            showsVerticalScrollIndicator={false}
            renderItem={renderSidebarItem}
            initialNumToRender={20}
            maxToRenderPerBatch={20}
            // Same reasoning as the content list below — keep the next
            // sidebar row mounted so D-pad focus moves on the first press
            // and never leaves a black gap during fast scrolling.
            windowSize={21}
            removeClippedSubviews={false}
          />
        </View>

        <View style={styles.sidebarDivider} />

        {/* Main content */}
        <View
          style={styles.mainContent}
          onLayout={(e) => setContentWidth(e.nativeEvent.layout.width)}
        >
          {/* Search bar — always rendered here so it never remounts when results switch in */}
          <View style={{ paddingHorizontal: CONTENT_PAD }}>
            {searchBarHeader}
          </View>

          {categorySwitching ? (
            // Blank content area while switching — old list is unmounted so
            // it visually clears immediately, then the new content fades in.
            <View style={styles.centered}>
              <ActivityIndicator size="large" color={Colors.dark.accent} />
            </View>
          ) : isFavouritesView && !isSearching && categoryContent.length === 0 ? (
            isGuest ? (
              <GuestPrompt
                icon="star"
                title="Save Your Favourites"
                message="Create a profile to save favourites and access them on any device."
                onCreateProfile={() => navigation.navigate("ProfilePicker", { fromHome: true })}
              />
            ) : (
              <View style={styles.centered}>
                <Feather name="star" size={44} color={Colors.dark.border} />
                <ThemedText style={styles.emptyTitle}>No Favourites Yet</ThemedText>
                <ThemedText style={styles.emptyText}>
                  Hold any item to add it to your favourites
                </ThemedText>
              </View>
            )
          ) : isRecentlyView && !isSearching && categoryContent.length === 0 ? (
            isGuest ? (
              <GuestPrompt
                icon="clock"
                title="Keep Your Watch History"
                message="Create a profile to save your watch history and continue watching."
                onCreateProfile={() => navigation.navigate("ProfilePicker", { fromHome: true })}
              />
            ) : (
              <View style={styles.centered}>
                <Feather name="clock" size={44} color={Colors.dark.border} />
                <ThemedText style={styles.emptyTitle}>Nothing Watched Yet</ThemedText>
                <ThemedText style={styles.emptyText}>
                  {type === "movies"
                    ? "Movies you watch will show up here"
                    : "Series you watch will show up here"}
                </ThemedText>
              </View>
            )
          ) : isWatchlistView && !isSearching && categoryContent.length === 0 ? (
            <View style={styles.centered}>
              <Feather name="bookmark" size={44} color={Colors.dark.border} />
              <ThemedText style={styles.emptyTitle}>
                {watchlistTotal > 0 ? "Nothing to Show Here" : "Your Watchlist is Empty"}
              </ThemedText>
              <ThemedText style={styles.emptyText}>
                {watchlistTotal > 0
                  ? `You have ${watchlistTotal} ${type === "series" ? "series" : "movie"}${watchlistTotal === 1 ? "" : "s"} saved but we couldn't match any to this server.`
                  : `Tap the bookmark on any ${type === "series" ? "series" : "movie"} to save it for later.`}
              </ThemedText>
            </View>
          ) : isSuggestedView && !isSearching && categoryContent.length === 0 ? (
            <View style={styles.centered}>
              <Feather name="thumbs-up" size={44} color={Colors.dark.border} />
              <ThemedText style={styles.emptyTitle}>No Suggestions Yet</ThemedText>
              <ThemedText style={styles.emptyText}>
                {watchEntries.some((e) =>
                  type === "movies" ? e.content_type === "movie" : e.content_type === "series",
                )
                  ? "We couldn't detect a genre from your watch history yet — try a few more titles to unlock suggestions."
                  : "Start watching your favourites to get personalised suggestions"}
              </ThemedText>
            </View>
          ) : (
            <FlashList
              ref={flatListRef}
              data={displayContent}
              keyExtractor={getItemId}
              numColumns={numColumns}
              // Force a fresh recycler when type or column count changes so
              // we don't recycle a movie cell into a series cell shape.
              key={`content-${type}-${numColumns}`}
              contentContainerStyle={{
                paddingHorizontal: CONTENT_PAD,
                paddingTop: Spacing.xs,
                paddingBottom: padB,
              }}
              showsVerticalScrollIndicator={false}
              keyboardShouldPersistTaps="handled"
              keyboardDismissMode="on-drag"
              // FlashList v2 recycles cell views (RecyclerView-style) and
              // auto-measures item size — memory and mount cost stay constant
              // whether the list has 30 items or 30,000. That's the whole
              // reason we switched away from FlatList for huge IPTV catalogues.
              //
              // drawDistance keeps a generous overscan rendered so the next
              // row down is already mounted + focusable when the user presses
              // D-pad down at the bottom of the visible window. Replaces
              // FlatList's old `windowSize=21` for TV remote feel.
              drawDistance={Math.max(800, rowHeight * 3)}
              renderItem={renderContentItem}
              ListEmptyComponent={
                isSearching ? (
                  <View style={styles.centeredInline}>
                    <Feather name="search" size={36} color={Colors.dark.border} />
                    <ThemedText style={styles.emptyText}>No matches found</ThemedText>
                  </View>
                ) : (
                  <View style={styles.centeredInline}>
                    <Feather name="inbox" size={36} color={Colors.dark.border} />
                    <ThemedText style={styles.emptyText}>No content in this category</ThemedText>
                  </View>
                )
              }
            />
          )}

        </View>
      </View>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.dark.backgroundRoot },
  switchOverlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(8,8,8,0.45)",
  },
  header: {
    flexDirection: "row", alignItems: "center",
    paddingBottom: Spacing.md, gap: Spacing.md,
  },
  backBtn: {
    width: 40, height: 40, borderRadius: BorderRadius.full,
    backgroundColor: Colors.dark.backgroundDefault,
    borderWidth: 1, borderColor: Colors.dark.border,
    justifyContent: "center", alignItems: "center",
    overflow: "hidden",
  },
  backBtnActive: { borderColor: Colors.dark.accent },
  headerTitleRow: { flex: 1, flexDirection: "row", alignItems: "center", gap: Spacing.xs },
  headerTitle: { fontSize: 18, fontWeight: "700", color: Colors.dark.text, flex: 1 },
  countBadge: {
    backgroundColor: Colors.dark.backgroundDefault,
    borderWidth: 1, borderColor: Colors.dark.border,
    borderRadius: BorderRadius.full,
    paddingHorizontal: Spacing.sm, paddingVertical: 3,
    minWidth: 38, alignItems: "center",
  },
  countBadgeSearch: { borderColor: Colors.dark.accent, backgroundColor: Colors.dark.accentDim },
  countText: { fontSize: 12, color: Colors.dark.textSecondary, textAlign: "center" },
  countTextSearch: { color: Colors.dark.accent, fontWeight: "700" },
  clearAllBtn: {
    flexDirection: "row", alignItems: "center", gap: 5,
    paddingHorizontal: Spacing.sm, paddingVertical: 6,
    borderRadius: BorderRadius.sm,
    borderWidth: 1, borderColor: "rgba(255,59,59,0.35)",
    backgroundColor: "rgba(255,59,59,0.08)",
  },
  clearAllBtnActive: {
    borderColor: Colors.dark.error,
    backgroundColor: "rgba(255,59,59,0.18)",
  },
  clearAllText: { fontSize: 12, fontWeight: "700", color: Colors.dark.error },
  manageBtn: {
    flexDirection: "row", alignItems: "center", gap: 5,
    paddingHorizontal: Spacing.sm, paddingVertical: 6,
    borderRadius: BorderRadius.sm,
    borderWidth: 1, borderColor: "rgba(255,102,0,0.35)",
    backgroundColor: "rgba(255,102,0,0.08)",
  },
  manageBtnActive: {
    borderColor: Colors.dark.accent,
    backgroundColor: "rgba(255,102,0,0.18)",
  },
  manageBtnOn: {
    backgroundColor: Colors.dark.accent,
    borderColor: Colors.dark.accent,
  },
  manageBtnOnActive: {
    opacity: 0.9,
  },
  manageBtnText: { fontSize: 12, fontWeight: "700", color: Colors.dark.accent },
  manageBtnTextOn: { color: "#fff" },
  // Confirm modal
  modalBackdrop: {
    flex: 1, backgroundColor: "rgba(0,0,0,0.72)",
    justifyContent: "center", alignItems: "center",
  },
  modalCard: {
    width: 340, maxWidth: "90%",
    backgroundColor: Colors.dark.backgroundDefault,
    borderRadius: BorderRadius.md,
    borderWidth: 1, borderColor: Colors.dark.border,
    padding: Spacing.xl,
    alignItems: "center", gap: Spacing.md,
  },
  modalTitle: { fontSize: 18, fontWeight: "700", color: Colors.dark.text },
  modalBody: { fontSize: 13, color: Colors.dark.textSecondary, textAlign: "center", lineHeight: 19 },
  modalBtnRow: { flexDirection: "row", gap: Spacing.sm, marginTop: Spacing.xs, width: "100%" },
  modalBtnCancel: {
    flex: 1, paddingVertical: Spacing.sm, borderRadius: BorderRadius.sm,
    borderWidth: 1, borderColor: Colors.dark.border,
    alignItems: "center", justifyContent: "center",
  },
  modalBtnCancelActive: { borderColor: Colors.dark.accent, backgroundColor: Colors.dark.accentDim },
  modalBtnCancelText: { color: Colors.dark.text, fontWeight: "600", fontSize: 14 },
  modalBtnConfirm: {
    flex: 1, paddingVertical: Spacing.sm, borderRadius: BorderRadius.sm,
    backgroundColor: Colors.dark.error, alignItems: "center", justifyContent: "center",
    minHeight: 40,
  },
  modalBtnConfirmActive: { opacity: 0.8 },
  modalBtnConfirmText: { color: "#fff", fontWeight: "700", fontSize: 14 },
  divider: { height: 1, backgroundColor: Colors.dark.border, marginBottom: Spacing.xs },

  // Body layout
  body: { flex: 1, flexDirection: "row" },

  // Sidebar
  sidebar: {
    width: SIDEBAR_W,
    paddingRight: Spacing.xs,
    paddingTop: Spacing.xs,
  },
  sidebarDivider: {
    width: 1,
    backgroundColor: Colors.dark.border,
    marginVertical: Spacing.xs,
  },
  sidebarItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.xs,
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.sm,
    borderRadius: BorderRadius.sm,
    marginBottom: 2,
    overflow: "hidden",
    borderWidth: 1,
    borderColor: "transparent",
  },
  // Fixed system sections (Recently/Continue Watching, Favourites,
  // Suggested for You, Recently Added). Subtle background tint
  // distinguishes them from reorderable categories without looking like
  // a hover state.
  sidebarItemPinned: {
    backgroundColor: "rgba(255,255,255,0.04)",
  },
  sidebarItemSelected: {
    borderColor: "rgba(255,102,0,0.35)",
  },
  sidebarItemHover: {
    borderColor: "rgba(255,102,0,0.15)",
  },
  sidebarItemText: {
    flex: 1,
    fontSize: 11,
    fontWeight: "500",
    color: Colors.dark.text,
    lineHeight: 15,
  },
  sidebarItemTextActive: {
    color: Colors.dark.accent,
    fontWeight: "700",
  },
  sidebarActiveBar: {
    position: "absolute",
    left: 0,
    top: 6,
    bottom: 6,
    width: 2.5,
    backgroundColor: Colors.dark.accent,
    borderRadius: 2,
  },

  // Main content
  mainContent: { flex: 1 },

  // Search bar
  searchBarWrap: { marginBottom: Spacing.sm, gap: Spacing.xs },
  searchBar: {
    flex: 1,
    flexDirection: "row", alignItems: "center", gap: Spacing.sm,
    backgroundColor: Colors.dark.backgroundDefault,
    borderWidth: 1.5, borderColor: Colors.dark.border,
    borderRadius: BorderRadius.sm,
    paddingHorizontal: Spacing.md, height: 42,
  },
  searchBarActive: {
    borderColor: Colors.dark.accent,
    shadowColor: "#FF6600", shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.4, shadowRadius: 8, elevation: 4,
  },
  searchInput: {
    flex: 1, color: Colors.dark.text, fontSize: 13,
    height: 42, padding: 0,
  },
  searchMeta: { flexDirection: "row", alignItems: "center", gap: Spacing.xs, paddingHorizontal: Spacing.xs },
  searchMetaText: { flex: 1, color: Colors.dark.accent, fontSize: 12, fontWeight: "600" },
  searchMetaLimit: { color: Colors.dark.textSecondary, fontSize: 11 },

  // Cards
  card: {
    backgroundColor: Colors.dark.backgroundDefault,
    borderRadius: BorderRadius.sm, overflow: "hidden",
    borderWidth: 1, borderColor: Colors.dark.border,
  },
  cardActive: {
    borderColor: Colors.dark.accent,
    shadowColor: "#FF6600", shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8, shadowRadius: 14, elevation: 10,
  },
  cardFavourited: { borderColor: "rgba(255,102,0,0.45)" },
  cardFavouritedActive: {
    borderColor: "#FFD700",
    shadowColor: "#FFD700", shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.9, shadowRadius: 14, elevation: 10,
  },
  cardEditDelete: {
    borderColor: "rgba(255,59,59,0.55)",
  },
  cardEditDeleteActive: {
    borderColor: Colors.dark.error,
    shadowColor: Colors.dark.error, shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.85, shadowRadius: 14, elevation: 10,
  },
  cardEditFavActive: {
    borderColor: "#FFD700",
    shadowColor: "#FFD700", shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.85, shadowRadius: 14, elevation: 10,
  },
  deleteBadge: {
    position: "absolute", top: 6, right: 6,
    width: 24, height: 24, borderRadius: 12,
    backgroundColor: Colors.dark.error,
    justifyContent: "center", alignItems: "center",
    shadowColor: "#000", shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.6, shadowRadius: 3, elevation: 6,
    zIndex: 5,
  },
  editFavBadge: {
    position: "absolute", top: 6, right: 6,
    width: 22, height: 22, borderRadius: 11,
    backgroundColor: Colors.dark.accent,
    justifyContent: "center", alignItems: "center",
    shadowColor: "#FF6600", shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 1, shadowRadius: 6, elevation: 6,
    zIndex: 5,
  },
  pickerOverlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: "center",
    alignItems: "center",
    padding: 6,
    zIndex: 9,
  },
  pickerScrim: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: "rgba(0,0,0,0.62)",
  },
  pickerScroll: {
    width: "100%",
  },
  pickerRow: {
    flexDirection: "column",
    gap: 6,
    width: "100%",
    paddingVertical: 2,
  },
  pickerBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    paddingVertical: 7,
    paddingHorizontal: 8,
    borderRadius: 8,
    backgroundColor: "rgba(255,102,0,0.85)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.18)",
  },
  pickerBtnActive: {
    backgroundColor: Colors.dark.accent,
    borderColor: "#fff",
    shadowColor: "#FF6600", shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 1, shadowRadius: 8, elevation: 8,
  },
  pickerBtnRemove: {
    backgroundColor: "rgba(60,60,60,0.85)",
    borderColor: "rgba(255,255,255,0.18)",
  },
  pickerBtnRemoveActive: {
    backgroundColor: "#3a3a3a",
    borderColor: "#fff",
    shadowColor: "#fff", shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.6, shadowRadius: 6, elevation: 6,
  },
  pickerBtnText: {
    color: "#fff",
    fontSize: 10,
    fontWeight: "700",
    letterSpacing: 0.2,
    flexShrink: 1,
  },
  cardThumb: { overflow: "hidden", backgroundColor: Colors.dark.backgroundSecondary },
  cardImage: { width: "100%", height: "100%" },
  cardPlaceholder: {
    width: "100%", height: "100%",
    backgroundColor: Colors.dark.backgroundSecondary,
    justifyContent: "center", alignItems: "center",
  },
  cardOverlay: { ...StyleSheet.absoluteFillObject, backgroundColor: "rgba(255,102,0,0.08)" },
  starBadge: {
    position: "absolute", top: 6, right: 6,
    width: 22, height: 22, borderRadius: 11,
    backgroundColor: Colors.dark.accent,
    justifyContent: "center", alignItems: "center",
    shadowColor: "#FF6600", shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 1, shadowRadius: 6, elevation: 6,
  },
  cardInfo: { padding: Spacing.sm, gap: 2, flex: 1, justifyContent: "center" },
  cardName: { color: Colors.dark.text, fontSize: 11, fontWeight: "500", lineHeight: 15 },
  cardNameActive: { color: Colors.dark.text },
  ratingBadge: {
    position: "absolute",
    top: 4,
    right: 4,
    flexDirection: "row",
    alignItems: "center",
    gap: 3,
    backgroundColor: "rgba(0,0,0,0.78)",
    borderRadius: BorderRadius.xs,
    paddingHorizontal: 5,
    paddingVertical: 2,
    borderWidth: 1,
    borderColor: "rgba(255,102,0,0.35)",
  },
  ratingText: { color: Colors.dark.text, fontSize: 10, fontWeight: "700" },
  watchedBadge: {
    position: "absolute", top: 4, left: 4,
    flexDirection: "row", alignItems: "center", gap: 3,
    backgroundColor: "rgba(0,0,0,0.82)",
    borderRadius: BorderRadius.xs,
    paddingHorizontal: 5, paddingVertical: 2,
    borderWidth: 1, borderColor: "rgba(120,255,120,0.5)",
  },
  watchedBadgeText: { color: "#7CFF7C", fontSize: 9, fontWeight: "800", letterSpacing: 0.5 },
  newBadge: {
    position: "absolute", top: 4, left: 4,
    flexDirection: "row", alignItems: "center", gap: 3,
    backgroundColor: Colors.dark.accent,
    borderRadius: BorderRadius.xs,
    paddingHorizontal: 5, paddingVertical: 2,
    borderWidth: 1, borderColor: "rgba(255,255,255,0.35)",
  },
  newBadgeText: { color: "#fff", fontSize: 9, fontWeight: "800", letterSpacing: 0.5 },
  continueBadge: {
    position: "absolute", top: 4, left: 4,
    flexDirection: "row", alignItems: "center", gap: 3,
    backgroundColor: "rgba(0,0,0,0.82)",
    borderRadius: BorderRadius.xs,
    paddingHorizontal: 5, paddingVertical: 2,
    borderWidth: 1, borderColor: "rgba(255,102,0,0.55)",
  },
  continueBadgeText: { color: Colors.dark.accent, fontSize: 9, fontWeight: "800", letterSpacing: 0.5 },
  cardProgressTrack: {
    position: "absolute", left: 0, right: 0, bottom: 0,
    height: 3, backgroundColor: "rgba(0,0,0,0.55)",
  },
  cardProgressFill: {
    height: "100%",
    backgroundColor: Colors.dark.accent,
    shadowColor: "#FF6600", shadowOffset: { width: 0, height: 0 }, shadowOpacity: 1, shadowRadius: 4,
  },
  activeBar: {
    height: 2, backgroundColor: Colors.dark.accent,
    shadowColor: "#FF6600", shadowOffset: { width: 0, height: 0 }, shadowOpacity: 1, shadowRadius: 4,
  },

  centered: {
    flex: 1, justifyContent: "center", alignItems: "center",
    gap: Spacing.md, paddingTop: Spacing["4xl"],
  },
  centeredInline: {
    paddingTop: Spacing["4xl"],
    justifyContent: "center", alignItems: "center", gap: Spacing.md,
  },
  emptyTitle: { color: Colors.dark.text, fontSize: 16, fontWeight: "700" },
  emptyText: { color: Colors.dark.textSecondary, fontSize: 14, textAlign: "center", paddingHorizontal: Spacing.xl },
  loadingText: { color: Colors.dark.textSecondary, fontSize: 14 },

  // Search bar row — flex row so parental badge sits beside the input
  searchBarRow: { flexDirection: "row", alignItems: "stretch", gap: Spacing.sm },
  searchBarHalf: { flex: 1 },

  // Age restriction badge (right half of search bar row)
  parentalBadge: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
    backgroundColor: Colors.dark.backgroundDefault,
    borderWidth: 1.5,
    borderColor: "rgba(255,102,0,0.35)",
    borderRadius: BorderRadius.sm,
    paddingHorizontal: Spacing.md,
    height: 42,
  },
  parentalBadgeText: { flex: 1 },
  parentalBadgeLabel: { fontSize: 10, color: Colors.dark.textSecondary, fontWeight: "600", textTransform: "uppercase", letterSpacing: 0.5 },
  parentalBadgeAge: { fontSize: 14, color: Colors.dark.accent, fontWeight: "700" },

  // Filtered-content notice banner
  parentalNotice: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "rgba(255,102,0,0.08)",
    borderWidth: 1,
    borderColor: "rgba(255,102,0,0.25)",
    borderRadius: BorderRadius.sm,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    marginTop: 2,
  },
  parentalNoticeText: { flex: 1, fontSize: 12, color: Colors.dark.textSecondary, lineHeight: 17 },
  parentalNoticeTextFocused: { color: "rgba(255,255,255,0.9)" },
  parentalNoticeLink: { fontSize: 12, color: Colors.dark.accent, fontWeight: "600" },
  parentalNoticeLinkFocused: { color: "#fff" },
  parentalNoticeFocused: {
    borderColor: Colors.dark.accent,
    backgroundColor: Colors.dark.accent,
    shadowColor: Colors.dark.accent,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.55,
    shadowRadius: 10,
    elevation: 8,
  },
  parentalNoticeFocusOverlay: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: BorderRadius.sm,
    backgroundColor: "rgba(255,255,255,0.06)",
    pointerEvents: "none",
  },

  // Parental PIN unlock modal
  pinModalBackdrop: {
    flex: 1, backgroundColor: "rgba(0,0,0,0.78)",
    justifyContent: "center", alignItems: "center",
  },
  pinModalCard: {
    width: 280,
    backgroundColor: Colors.dark.backgroundDefault,
    borderRadius: BorderRadius.lg,
    borderWidth: 1, borderColor: Colors.dark.border,
    paddingVertical: Spacing.xl, paddingHorizontal: Spacing["2xl"],
    alignItems: "center", gap: Spacing.sm,
    shadowColor: "#000", shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.6, shadowRadius: 24, elevation: 20,
    position: "relative",
  },
  pinModalClose: {
    position: "absolute", top: Spacing.sm, right: Spacing.sm,
    width: 26, height: 26, borderRadius: BorderRadius.full,
    backgroundColor: Colors.dark.backgroundRoot,
    borderWidth: 1, borderColor: Colors.dark.border,
    justifyContent: "center", alignItems: "center",
    zIndex: 10,
  },
  pinModalTitle: { fontSize: 15, fontWeight: "700", color: Colors.dark.text, textAlign: "center" },
  pinModalSub: { fontSize: 12, color: Colors.dark.textSecondary, textAlign: "center" },
  pinDots: { flexDirection: "row", gap: Spacing.md, marginTop: Spacing.xs },
  pinDot: { width: 14, height: 14, borderRadius: 7, borderWidth: 2 },
  pinErrorText: { color: Colors.dark.error, fontSize: 12, fontWeight: "500", height: 16 },
  pinPad: { flexDirection: "row", flexWrap: "wrap", gap: 6, width: 3 * 46 + 2 * 6, justifyContent: "center", marginTop: Spacing.xs },
  pinKey: {
    width: 46, height: 46, borderRadius: BorderRadius.md,
    backgroundColor: Colors.dark.backgroundRoot,
    borderWidth: 1, borderColor: Colors.dark.border,
    justifyContent: "center", alignItems: "center",
  },
  pinKeyEmpty: { width: 46, height: 46 },
  pinKeyDelete: { backgroundColor: "transparent", borderColor: "transparent" },
  pinKeyActive: { borderColor: Colors.dark.accent, backgroundColor: Colors.dark.accentDim },
  pinKeyText: { color: Colors.dark.text, fontSize: 16, fontWeight: "600" },
});
