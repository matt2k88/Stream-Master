import { TVEventHandler } from "@/lib/tv-event-handler";
import { ControlButton } from "@/components/player/ControlButton";
import { EpgPanel } from "@/components/player/EpgPanel";
import { PlayerUI } from "@/components/player/playerTheme";
import { PlayerLabels } from "@/components/player/playerLabels";
import { parseChannelName } from "@/lib/channel-name";
import { requestEpg, getNowPlaying, getProgress, useEpgCacheVersion } from "@/lib/epg-cache";
import { useTvLongPress, setLongPressAction, clearLongPressAction } from "@/lib/tv-long-press";
import React, { useState, useEffect, useRef, useCallback, useMemo } from "react";
import {
  View,
  StyleSheet,
  Pressable,
  ScrollView,
  FlatList,
  ActivityIndicator,
  Animated,
  BackHandler,
  Platform,
  Modal,
  TextInput,
  StatusBar,
  useWindowDimensions,
} from "react-native";
import { useNavigation, useRoute, RouteProp, useFocusEffect } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { Feather, MaterialCommunityIcons } from "@expo/vector-icons";
import { useVideoPlayer, VideoView, makeVideoSource } from "@/lib/video-player";
import { Image } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { Colors, Spacing, BorderRadius } from "@/constants/theme";
import { RootStackParamList } from "@/navigation/RootStackNavigator";
import { xtreamApi, EpgListing } from "@/lib/xtream-api";
import { useFavourites } from "@/contexts/FavouritesContext";
import { useProfile } from "@/contexts/ProfileContext";
import { useData } from "@/contexts/DataContext";
import { useGroups } from "@/contexts/GroupsContext";
import { useWatchHistory } from "@/contexts/WatchHistoryContext";
import { useFootball } from "@/contexts/FootballContext";
import { FootballScoreTracker } from "@/components/FootballScoreTracker";
import SideMenuButton from "@/components/SideMenuButton";
import { saveRecentlyWatched } from "@/components/RecentlyWatchedCard";
import type { LiveStream } from "@/lib/xtream-api";

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;
type LivePreviewRouteProp = RouteProp<RootStackParamList, "LivePreview">;

const SIDEBAR_W = 210;
// Fixed channel row height — must match the rendered ChannelRow's
// total vertical footprint (paddingVertical 7 * 2 + icon 32 + marginBottom 2).
const CHANNEL_ROW_H = 48;

function decodeEpgString(s: string): string {
  if (!s) return "";
  try { return atob(s); } catch { return s; }
}

function formatEpgTime(timestamp: number): string {
  if (!timestamp) return "";
  const d = new Date(timestamp * 1000);
  return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: false });
}

function EpgRow({ listing, isNow, isNext }: { listing: EpgListing; isNow: boolean; isNext?: boolean }) {
  const title = decodeEpgString(listing.title);
  const desc = decodeEpgString(listing.description);
  const startTime = formatEpgTime(listing.start_timestamp);
  const endTime = formatEpgTime(listing.stop_timestamp);

  return (
    <View style={[styles.epgRow, isNow && styles.epgRowNow]}>
      {isNow ? (
        <LinearGradient
          colors={["rgba(255,102,0,0.12)", "rgba(255,102,0,0.04)"]}
          style={StyleSheet.absoluteFill}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0 }}
        />
      ) : null}
      <View style={styles.epgDotCol}>
        {isNow ? (
          <View style={styles.epgDotLive}>
            <View style={styles.epgDotLiveInner} />
          </View>
        ) : (
          <View style={styles.epgDotNext} />
        )}
        {isNow ? <View style={styles.epgConnector} /> : null}
      </View>
      <View style={styles.epgInfo}>
        <View style={styles.epgMeta}>
          {isNow ? (
            <View style={styles.nowBadge}>
              <ThemedText style={styles.nowBadgeText}>NOW</ThemedText>
            </View>
          ) : isNext ? (
            <ThemedText style={styles.upNextLabel}>UP NEXT</ThemedText>
          ) : null}
          {startTime && endTime ? (
            <ThemedText style={styles.epgTime}>{startTime} — {endTime}</ThemedText>
          ) : null}
        </View>
        <ThemedText style={[styles.epgTitle, isNow && styles.epgTitleNow]} numberOfLines={2}>
          {title || "Unknown programme"}
        </ThemedText>
        {desc && isNow ? (
          <ThemedText style={styles.epgDesc} numberOfLines={2}>{desc}</ThemedText>
        ) : null}
      </View>
    </View>
  );
}

function ChannelRow({
  item,
  isSelected,
  onPress,
  onFocusItem,
  onLongPress,
  hasTVPreferredFocus,
}: {
  item: LiveStream;
  isSelected: boolean;
  onPress: () => void;
  onFocusItem?: (item: LiveStream) => void;
  onLongPress?: (item: LiveStream) => void;
  hasTVPreferredFocus?: boolean;
}) {
  // Stable identity so blur clears exactly what focus registered.
  const longPressRef = useRef(() => {});
  longPressRef.current = () => onLongPress?.(item);
  const [focused, setFocused] = useState(false);
  const isActive = focused || isSelected;

  return (
    <Pressable
      style={[styles.channelRow, isActive && styles.channelRowActive]}
      onPress={onPress}
      onFocus={() => {
        setFocused(true);
        onFocusItem?.(item);
        setLongPressAction(longPressRef.current);
      }}
      onBlur={() => {
        setFocused(false);
        clearLongPressAction(longPressRef.current);
      }}
      onHoverIn={() => onFocusItem?.(item)}
      hasTVPreferredFocus={hasTVPreferredFocus}
    >
      {isSelected ? (
        <View style={styles.channelRowBar} />
      ) : null}
      {item.stream_icon ? (
        <Image
          source={{ uri: item.stream_icon }}
          style={styles.channelRowIcon}
          contentFit="contain"
        />
      ) : (
        <View style={[styles.channelRowIcon, styles.channelRowIconPlaceholder]}>
          <Feather name="tv" size={14} color={Colors.dark.border} />
        </View>
      )}
      <ThemedText
        style={[styles.channelRowName, isSelected && styles.channelRowNameActive]}
        numberOfLines={2}
      >
        {item.name}
      </ThemedText>
    </Pressable>
  );
}

export default function LivePreviewScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation<NavigationProp>();
  const route = useRoute<LivePreviewRouteProp>();
  const { streamId, name, streamUrl, thumbnail, streamIcon, categoryId, initialFullscreen } = route.params;

  // Fullscreen state — same player instance reused, no second connection
  const [isFullscreen, setIsFullscreen] = useState(!!initialFullscreen);
  const [showFsOverlay, setShowFsOverlay] = useState(true);
  const fsHideTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const cameInFullscreenRef = useRef(!!initialFullscreen);

  const { liveStreams } = useData();
  const { getFavouritesByType } = useFavourites();
  const { entries: watchEntries } = useWatchHistory();
  const { groups: userGroups, getItemsByGroup } = useGroups();

  // Resolve a "group:<id>" categoryId to the matching custom group so the
  // sidebar can show the group's name + its channel list.
  const groupForCategory = React.useMemo(() => {
    if (!categoryId || !String(categoryId).startsWith("group:")) return null;
    const gid = String(categoryId).slice("group:".length);
    return userGroups.find((g) => g.id === gid && g.type === "live") ?? null;
  }, [categoryId, userGroups]);

  // Sidebar channel list. Modes:
  //  • "favourites"   → all live channels the active profile has favourited.
  //  • "recently"     → unique live channels the user recently played, newest-first.
  //  • "group:<id>"   → channels in the user's custom Live group, in the
  //                     order they were added.
  //  • real id        → all channels in that Xtream category.
  const sidebarTitle =
    categoryId === "favourites" ? "Favourites"
    : categoryId === "recently" ? "Recently Watched"
    : groupForCategory ? groupForCategory.name
    : null;
  const categoryChannels = React.useMemo<LiveStream[]>(() => {
    if (!categoryId) return [];
    if (categoryId === "favourites") {
      const favIds = new Set(getFavouritesByType("live").map((f) => f.stream_id));
      return liveStreams.filter((s) => favIds.has(s.stream_id));
    }
    if (categoryId === "recently") {
      const out: LiveStream[] = [];
      const seen = new Set<string>();
      const idx = new Map<string, LiveStream>();
      for (const s of liveStreams) idx.set(String(s.stream_id), s);
      for (const e of watchEntries) {
        if (e.content_type !== "live" || !e.stream_id) continue;
        const k = String(e.stream_id);
        if (seen.has(k)) continue;
        const s = idx.get(k);
        if (s) { out.push(s); seen.add(k); }
      }
      return out;
    }
    if (groupForCategory) {
      const items = getItemsByGroup(groupForCategory.id);
      if (items.length === 0) return [];
      const idx = new Map<string, LiveStream>();
      for (const s of liveStreams) idx.set(String(s.stream_id), s);
      const out: LiveStream[] = [];
      const seen = new Set<string>();
      for (const it of items) {
        const k = String(it.stream_id);
        if (seen.has(k)) continue;
        const hit = idx.get(k);
        if (hit) { out.push(hit); seen.add(k); }
      }
      return out;
    }
    return liveStreams.filter((s) => String(s.category_id) === String(categoryId));
  }, [categoryId, liveStreams, getFavouritesByType, watchEntries, groupForCategory, getItemsByGroup]);

  // Active channel state
  const [selectedId, setSelectedId] = useState(streamId);
  const [selectedName, setSelectedName] = useState(name);
  const [selectedIcon, setSelectedIcon] = useState<string | undefined>(streamIcon);

  const [epgListings, setEpgListings] = useState<EpgListing[]>([]);
  const [epgLoading, setEpgLoading] = useState(true);

  // Channel currently *previewed* in the EPG panel. Defaults to whatever's
  // playing, but updates as the user hovers (focuses) channels in the
  // sidebar via the TV remote — without switching the live player.
  const [previewedId, setPreviewedId] = useState(streamId);
  const [previewedName, setPreviewedName] = useState(name);

  const { isFavourite, toggleFavourite } = useFavourites();
  const { activeProfile } = useProfile();
  const { upsertLocal } = useWatchHistory();
  const isFavourited = isFavourite(selectedId, "live");

  // Track which channel id we've already logged so we re-log on channel change
  const savedChannelRef = useRef<number | null>(null);

  // ── Report content ────────────────────────────────────────────────────────
  const [showReport, setShowReport] = useState(false);
  const [reportReason, setReportReason] = useState<string | null>(null);
  const [reportOther, setReportOther] = useState("");
  const [reportSubmitting, setReportSubmitting] = useState(false);
  const [reportDone, setReportDone] = useState(false);
  const REPORT_REASONS = [
    "Constant buffering",
    "Does not load",
    "Wrong language",
    "Jittery / stuttering",
    "Wrong content",
    "Other",
  ] as const;
  const handleSubmitReport = useCallback(async () => {
    if (!reportReason || !activeProfile) return;
    if (reportReason === "Other" && !reportOther.trim()) return;
    setReportSubmitting(true);
    try {
      const { getApiUrl } = await import("@/lib/query-client");
      const url = new URL("/api/content-reports", getApiUrl());
      await fetch(url.toString(), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          profile_id: activeProfile.id,
          stream_id: selectedId,
          stream_name: selectedName,
          stream_type: "live",
          reason: reportReason === "Other" ? "Other" : reportReason,
          other_text: reportReason === "Other" ? reportOther.trim() : null,
        }),
      });
      setReportDone(true);
      setTimeout(() => {
        setShowReport(false);
        setReportDone(false);
        setReportReason(null);
        setReportOther("");
      }, 1800);
    } catch {
      setShowReport(false);
    } finally {
      setReportSubmitting(false);
    }
  }, [reportReason, reportOther, activeProfile, selectedId, selectedName]);

  const toastAnim = useRef(new Animated.Value(0)).current;
  const [toastMsg, setToastMsg] = useState("");
  const [toastVisible, setToastVisible] = useState(false);

  const [backFocused, setBackFocused] = useState(false);
  const [backPressed, setBackPressed] = useState(false);
  const backActive = backFocused || backPressed;

  const [reportFocused, setReportFocused] = useState(false);
  const [reportPressed, setReportPressed] = useState(false);
  const reportActive = reportFocused || reportPressed;

  // ── Football scores tracker ────────────────────────────────────────────────
  const { prefs: footballPrefs, globalEnabled: footballGlobalEnabled } = useFootball();
  const footballEnabled = footballPrefs.enabled && footballGlobalEnabled;
  const [showFootball, setShowFootball] = useState(false);
  const [showGuide, setShowGuide] = useState(false);
  // Separate from playStatus: that tracks the stream (loading / playing /
  // reconnecting) and stays "playing" when the user pauses, so the button icon
  // never flipped.
  const [paused, setPaused] = useState(false);
  const [footballFocused, setFootballFocused] = useState(false);
  const [footballPressed, setFootballPressed] = useState(false);
  const footballActive = footballFocused || footballPressed;

  const listRef = useRef<FlatList>(null);

  // Engine pinned at mount from active profile's `player_live` pref.
  const playerEngineRef = useRef<"vlc" | "expo">(
    activeProfile?.player_live === "expo" ? "expo" : "vlc",
  );
  // Setup callback MUST be stable — an inline arrow gives expo-video a
  // new identity each render, which makes useVideoPlayer (Expo path)
  // recreate the player and reopen the HLS stream. LivePreview re-renders
  // a lot (EPG ticks, focus changes), so we pin via useRef.
  const playerSetupRef = useRef((p: any) => {
    p.muted = false;
    p.play();
  });
  // VLC hardware-decoding mode, captured at mount (same lifecycle as the
  // engine choice above). Ignored by the Expo engine. Defaults to "auto".
  const hwDecodeRef = useRef<"auto" | "on" | "off">(
    activeProfile?.player_hw_decode === "on" || activeProfile?.player_hw_decode === "off"
      ? activeProfile.player_hw_decode
      : "auto",
  );
  // Network pre-buffer in ms, captured at mount. Default 3000 ms.
  const bufferMsRef = useRef<number>(
    typeof activeProfile?.player_buffer_ms === "number" &&
    activeProfile.player_buffer_ms >= 1000
      ? activeProfile.player_buffer_ms
      : 3000,
  );
  const player = useVideoPlayer(streamUrl, playerSetupRef.current, {
    engine: playerEngineRef.current,
    hwDecode: hwDecodeRef.current,
    bufferMs: bufferMsRef.current,
  });

  // Track current stream URL so we can reload it on focus return
  const currentStreamUrlRef = useRef(streamUrl);
  const hasMountedRef = useRef(false);

  // ── Auto-reconnect state ──────────────────────────────────────────────────
  // Declared up-front (above useFocusEffect) so the effect's dep array can
  // reference the helper callbacks without hitting a TDZ error at render time.
  type PlayStatus = "loading" | "playing" | "reconnecting";
  const [playStatus, setPlayStatus] = useState<PlayStatus>("loading");
  const [retryAttempt, setRetryAttempt] = useState(0);
  const loadingTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const retryTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const retryCountRef = useRef(0);
  const stallTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const lastTimeRef = useRef<number>(0);
  const lastTimeAtRef = useRef<number>(Date.now());

  const clearLoadingTimeout = useCallback(() => {
    if (loadingTimeoutRef.current) {
      clearTimeout(loadingTimeoutRef.current);
      loadingTimeoutRef.current = null;
    }
  }, []);
  const clearRetryTimer = useCallback(() => {
    if (retryTimerRef.current) {
      clearTimeout(retryTimerRef.current);
      retryTimerRef.current = null;
    }
  }, []);
  const clearStallTimer = useCallback(() => {
    if (stallTimerRef.current) {
      clearInterval(stallTimerRef.current);
      stallTimerRef.current = null;
    }
  }, []);

  const reloadStream = useCallback(() => {
    try {
      player.replace(makeVideoSource(currentStreamUrlRef.current));
      player.play();
    } catch {}
  }, [player]);

  // Schedule the next auto-retry. Backs off (1s, 2s, 4s, 8s, capped) and never
  // gives up — live channels can come back at any time. Each retry re-arms a
  // 12s load-timeout watchdog so we keep trying even if the player only emits
  // "loading" events without a hard error.
  const scheduleAutoRetry = useCallback(() => {
    clearRetryTimer();
    clearLoadingTimeout();
    const attempt = retryCountRef.current + 1;
    retryCountRef.current = attempt;
    setRetryAttempt(attempt);
    setPlayStatus("reconnecting");
    const delays = [1000, 2000, 4000, 8000];
    const delay = delays[Math.min(attempt - 1, delays.length - 1)];
    retryTimerRef.current = setTimeout(() => {
      retryTimerRef.current = null;
      reloadStream();
      // Watchdog: still not playing after 12s → try again.
      clearLoadingTimeout();
      loadingTimeoutRef.current = setTimeout(() => {
        loadingTimeoutRef.current = null;
        scheduleAutoRetry();
      }, 12000);
    }, delay);
  }, [reloadStream, clearRetryTimer, clearLoadingTimeout]);

  const armLoadingTimeout = useCallback(() => {
    clearLoadingTimeout();
    loadingTimeoutRef.current = setTimeout(() => {
      loadingTimeoutRef.current = null;
      setPlayStatus((s) => {
        if (s === "playing") return s;
        scheduleAutoRetry();
        return "reconnecting";
      });
    }, 12000);
  }, [scheduleAutoRetry, clearLoadingTimeout]);

  const resetRetryState = useCallback(() => {
    clearRetryTimer();
    retryCountRef.current = 0;
    setRetryAttempt(0);
  }, [clearRetryTimer]);

  // Release player fully on unmount — kills the network connection immediately
  useEffect(() => {
    return () => {
      try { player.pause(); } catch {}
      try { player.release(); } catch {}
    };
  }, [player]);

  // When returning from PlayerScreen, force a fresh stream connection at live edge.
  // The blur cleanup (return value) pauses the mini-player the instant we leave this
  // screen, so it never streams in the background behind PlayerScreen.
  useFocusEffect(
    useCallback(() => {
      if (hasMountedRef.current) {
        // Returning from full-screen — reload stream from live edge and
        // reset reconnect state so we get a fresh "loading" pass.
        clearRetryTimer();
        retryCountRef.current = 0;
        setRetryAttempt(0);
        setPlayStatus("loading");
        armLoadingTimeout();
        try {
          player.replace(makeVideoSource(currentStreamUrlRef.current));
          player.play();
        } catch {}
      }
      hasMountedRef.current = true;
      return () => {
        // Screen lost focus (navigating away) — stop streaming immediately
        // and cancel any pending auto-retries so they don't fire in the bg.
        clearRetryTimer();
        clearLoadingTimeout();
        clearStallTimer();
        try { player.pause(); } catch {}
      };
    }, [player, clearRetryTimer, clearLoadingTimeout, clearStallTimer, armLoadingTimeout])
  );

  // Reload EPG whenever the *previewed* channel changes (i.e. as the user
  // moves focus through the sidebar with the TV remote). The previewed
  // channel is independent of the live player — switching only happens on
  // OK / press, handled by switchToChannel.
  useEffect(() => {
    let cancelled = false;
    setEpgLoading(true);
    setEpgListings([]);
    // 8 rather than 4: the Guide panel wants a real "coming up" list, and the
    // bottom info bar still only reads the first two.
    xtreamApi.getShortEpg(previewedId, 8).then((listings) => {
      if (!cancelled) { setEpgListings(listings); setEpgLoading(false); }
    }).catch(() => {
      if (!cancelled) setEpgLoading(false);
    });
    return () => { cancelled = true; };
  }, [previewedId]);

  // Keep the previewed channel in sync whenever the user actually switches
  // (e.g. presses OK). This stops the EPG from staying stuck on the last
  // hovered channel after a channel change.
  useEffect(() => {
    setPreviewedId(selectedId);
    setPreviewedName(selectedName);
  }, [selectedId, selectedName]);

  // Stable focus handler for ChannelRow — updates the EPG preview channel
  // without triggering a full live-player switch.
  const handleChannelFocus = useCallback((s: LiveStream) => {
    setPreviewedId(s.stream_id);
    setPreviewedName(s.name);
  }, []);

  // Scroll sidebar to selected channel once the list has data. Runs only
  // the first time `categoryChannels` becomes non-empty so it doesn't
  // hijack scroll position on later channel switches via the sidebar.
  const didInitialScrollRef = useRef(false);
  useEffect(() => {
    if (didInitialScrollRef.current) return;
    if (categoryChannels.length === 0) return;
    const idx = categoryChannels.findIndex((s) => s.stream_id === selectedId);
    if (idx <= 0) {
      didInitialScrollRef.current = true;
      return;
    }
    didInitialScrollRef.current = true;
    // Two scrolls: first jump-without-animation so distant items get
    // measured, then a tiny smooth re-align. requestAnimationFrame +
    // small timeout gives Metro time to lay out the FlatList.
    const t = setTimeout(() => {
      try {
        listRef.current?.scrollToIndex({ index: idx, animated: false, viewPosition: 0.3 });
      } catch {}
      setTimeout(() => {
        try {
          listRef.current?.scrollToIndex({ index: idx, animated: true, viewPosition: 0.3 });
        } catch {}
      }, 80);
    }, 50);
    return () => clearTimeout(t);
  }, [categoryChannels, selectedId]);

  const showToast = useCallback((msg: string) => {
    setToastMsg(msg);
    setToastVisible(true);
    toastAnim.setValue(0);
    Animated.sequence([
      Animated.timing(toastAnim, { toValue: 1, duration: 200, useNativeDriver: true }),
      Animated.delay(1800),
      Animated.timing(toastAnim, { toValue: 0, duration: 300, useNativeDriver: true }),
    ]).start(() => setToastVisible(false));
  }, [toastAnim]);

  const handleToggleFavourite = useCallback(async () => {
    const wasAdded = !isFavourited;
    await toggleFavourite({
      streamId: selectedId,
      streamType: "live",
      streamName: selectedName,
      streamIcon: selectedIcon ?? null,
    });
    showToast(wasAdded ? "Added to Favourites" : "Removed from Favourites");
  }, [isFavourited, toggleFavourite, selectedId, selectedName, selectedIcon, showToast]);

  // Hold OK on a channel in the list to favourite it, same as on the content
  // grids. A remote cannot produce a long PRESS, so the native bridge reports a
  // held OK and whichever row has focus handles it.
  useTvLongPress();
  const toggleFavouriteFor = useCallback(async (channel: LiveStream) => {
    const wasAdded = !isFavourite(channel.stream_id, "live");
    await toggleFavourite({
      streamId: channel.stream_id,
      streamType: "live",
      streamName: channel.name,
      streamIcon: channel.stream_icon ?? null,
    });
    showToast(wasAdded ? "Added to Favourites" : "Removed from Favourites");
  }, [isFavourite, toggleFavourite, showToast]);
  const toggleFavouriteForRef = useRef(toggleFavouriteFor);
  useEffect(() => { toggleFavouriteForRef.current = toggleFavouriteFor; }, [toggleFavouriteFor]);

  // (PlayStatus / retry state declared above useFocusEffect.)
  useEffect(() => {
    armLoadingTimeout();
    return () => {
      clearLoadingTimeout();
      clearRetryTimer();
      clearStallTimer();
    };
  }, [armLoadingTimeout, clearLoadingTimeout, clearRetryTimer, clearStallTimer]);

  const switchToChannel = useCallback((s: LiveStream) => {
    const newUrl = xtreamApi.getLiveStreamUrl(s.stream_id);
    currentStreamUrlRef.current = newUrl;
    savedChannelRef.current = null; // re-log new channel on next readyToPlay
    setSelectedId(s.stream_id);
    setSelectedName(s.name);
    setSelectedIcon(s.stream_icon ?? undefined);
    setPlayStatus("loading");
    resetRetryState();
    clearStallTimer();
    lastTimeRef.current = 0;
    lastTimeAtRef.current = Date.now();
    armLoadingTimeout();
    reloadStream();
  }, [reloadStream, armLoadingTimeout, resetRetryState, clearStallTimer]);

  const handleChannelPress = switchToChannel;

  // ── TV remote: D-pad up/down in fullscreen → quick channel change ─────────
  // Wraps around the current category. Stays in fullscreen and re-shows the
  // overlay briefly so the viewer sees the new channel name.
  const stepChannelInFullscreen = useCallback((dir: -1 | 1) => {
    if (categoryChannels.length === 0) return;
    const idx = categoryChannels.findIndex((c) => c.stream_id === selectedId);
    if (idx === -1) return;
    const nextIdx = idx + dir;
    // Clamp at the edges — no wrap-around. Up on the first channel and down
    // on the last channel are intentional no-ops (no channel above / below).
    if (nextIdx < 0 || nextIdx >= categoryChannels.length) return;
    const next = categoryChannels[nextIdx];
    if (next.stream_id === selectedId) return;
    switchToChannel(next);
    setShowFsOverlay(true);
    resetFsHideTimer();
  }, [categoryChannels, selectedId, switchToChannel, resetFsHideTimer]);

  // Boundary state for the fullscreen up/down arrow buttons — drives the
  // disabled/dimmed look and the no-op behaviour at the first/last channel.
  const channelIdx = React.useMemo(
    () => categoryChannels.findIndex((c) => c.stream_id === selectedId),
    [categoryChannels, selectedId],
  );
  const hasChannelList = categoryChannels.length > 0 && channelIdx !== -1;
  const atFirstChannel = !hasChannelList || channelIdx <= 0;
  const atLastChannel = !hasChannelList || channelIdx >= categoryChannels.length - 1;

  // What is on the channel that is actually PLAYING. Separate from epgListings,
  // which follows previewedId as the user moves through the channel list — so
  // the panel beside the picture used to change while hovering, describing a
  // channel that was not on screen.
  const epgVersion = useEpgCacheVersion();
  useEffect(() => { requestEpg(selectedId); }, [selectedId]);
  void epgVersion;
  const playingNow = getNowPlaying(selectedId);
  const playingProgress = getProgress(selectedId);

  // NOW / NEXT for the fullscreen info bar, from the previewed channel's EPG
  // (in fullscreen the preview is pinned to the playing channel, so they agree).
  const nowProg = React.useMemo<EpgListing | null>(() => {
    if (epgListings.length === 0) return null;
    const i = epgListings.findIndex((l) => l.now_playing === 1);
    return epgListings[i === -1 ? 0 : i] ?? null;
  }, [epgListings]);
  const nextProg = React.useMemo<EpgListing | null>(() => {
    if (epgListings.length === 0) return null;
    const i = epgListings.findIndex((l) => l.now_playing === 1);
    return epgListings[(i === -1 ? 0 : i) + 1] ?? null;
  }, [epgListings]);

  // Keep a ref to the latest channel-step closure so the Android onKeyDown
  // handler (attached once to a Pressable) and the web keydown listener
  // never read stale state.
  const stepRef = useRef<(dir: -1 | 1) => void>(() => {});
  const fsStateRef = useRef({ isFullscreen: false, showReport: false, showFsOverlay: false });
  useEffect(() => {
    stepRef.current = stepChannelInFullscreen;
    fsStateRef.current = { isFullscreen, showReport, showFsOverlay };
  }, [stepChannelInFullscreen, isFullscreen, showReport, showFsOverlay]);

  // Web: listen for ArrowUp / ArrowDown while in fullscreen.
  useEffect(() => {
    if (Platform.OS !== "web") return;
    const onKey = (e: KeyboardEvent) => {
      const { isFullscreen: fs, showReport: rep } = fsStateRef.current;
      if (!fs || rep) return;
      if (e.key === "ArrowUp") { e.preventDefault(); stepRef.current(-1); }
      else if (e.key === "ArrowDown") { e.preventDefault(); stepRef.current(1); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  // Android TV / Fire TV: handler attached to the focused fullscreen
  // Pressable. Returns nothing — React Native swallows the event when we
  // call stepRef which performs the navigation.
  const handleFsKeyDown = useCallback(({ nativeEvent }: any) => {
    const { isFullscreen: fs, showReport: rep } = fsStateRef.current;
    if (!fs || rep) return;
    const { keyCode } = nativeEvent;
    // 19 = DPAD_UP, 20 = DPAD_DOWN, 166 = CHANNEL_UP, 167 = CHANNEL_DOWN
    if (keyCode === 19 || keyCode === 166) stepRef.current(-1);
    else if (keyCode === 20 || keyCode === 167) stepRef.current(1);
  }, []);

  // ── Fire TV remote media keys ─────────────────────────────────────────────
  // This screen had no media-key handling at all, so play/pause and the skip
  // buttons were dead here even once the native key bridge existed.
  //
  // Live TV has no timeline, so rewind/fast-forward are meaningless — the skip
  // buttons map to channel up/down instead, which is what they mean on live
  // television and matches the up/down behaviour already wired above.
  const mediaPlayerRef = useRef(player);
  useEffect(() => { mediaPlayerRef.current = player; }, [player]);

  useEffect(() => {
    if (Platform.OS !== "android") return;
    const handler = new TVEventHandler();
    handler.enable(null, (_component, evt) => {
      // Fullscreen only. This same screen doubles as the small preview inside
      // the channel list, and hijacking the remote's media keys while someone
      // is just browsing channels would be surprising.
      if (!fsStateRef.current.isFullscreen) return;
      const p = mediaPlayerRef.current;
      try {
        switch (evt.eventType) {
          case "playPause":
            if (p.playing) p.pause();
            else p.play();
            break;
          case "play":
            p.play();
            break;
          case "pause":
          case "stop":
            p.pause();
            break;
          case "next":
          case "channelDown":
            stepRef.current(1);
            break;
          case "previous":
          case "channelUp":
            stepRef.current(-1);
            break;
          case "up":
          case "down":
            // Up/down change channel ONLY while nothing is on screen — the way
            // a TV behaves when you are just watching. As soon as the controls
            // or the Guide are up, these have to move focus instead, or the
            // overlay becomes impossible to navigate.
            if (!fsStateRef.current.showFsOverlay && !panelOpenRef.current) {
              stepRef.current(evt.eventType === "down" ? 1 : -1);
            }
            break;
        }
      } catch {
        // player released mid-press — nothing useful to do
      }
    });
    return () => handler.disable();
  }, []); // empty deps — player reached through a stable ref

  // Live had no on-screen play/pause at all — only the hardware media key.
  // How far through the current programme we are. Recomputed each minute —
  // any faster is wasted on a bar this size.
  const [progressTick, setProgressTick] = useState(0);
  useEffect(() => {
    if (!isFullscreen) return;
    const id = setInterval(() => setProgressTick((n) => n + 1), 60000);
    return () => clearInterval(id);
  }, [isFullscreen]);

  // Which listing is actually on now, so exactly one row can be "up next".
  const nowIndex = useMemo(() => {
    const flagged = epgListings.findIndex((l) => l.now_playing === 1);
    return flagged >= 0 ? flagged : 0;
  }, [epgListings]);

  const progressPct = useMemo(() => {
    void progressTick;
    const start = Number(nowProg?.start_timestamp) || 0;
    const stop = Number(nowProg?.stop_timestamp) || 0;
    if (!start || !stop || stop <= start) return 0;
    const now = Date.now() / 1000;
    return Math.max(0, Math.min(100, ((now - start) / (stop - start)) * 100));
  }, [nowProg, progressTick]);

  const togglePlayPause = useCallback(() => {
    try {
      if (player.playing) {
        player.pause();
        setPaused(true);
      } else {
        player.play();
        setPaused(false);
      }
    } catch {
      // player released mid-press
    }
  }, [player]);

  const handleRetry = useCallback(() => {
    resetRetryState();
    setPlayStatus("loading");
    armLoadingTimeout();
    reloadStream();
  }, [reloadStream, armLoadingTimeout, resetRetryState]);

  // ── Status listener: drives overlay + log to recently_watched ─────────────
  useEffect(() => {
    const sub = player.addListener("statusChange", (e) => {
      if (e.status === "readyToPlay") {
        setPlayStatus("playing");
        setPaused(false);
        resetRetryState();
        clearLoadingTimeout();
        // Reset stall tracker — playback is healthy.
        lastTimeRef.current = 0;
        lastTimeAtRef.current = Date.now();
        if (!activeProfile) return;
        if (savedChannelRef.current === selectedId) return;
        savedChannelRef.current = selectedId;
        saveRecentlyWatched({
          profileId: activeProfile.id,
          contentType: "live",
          streamId: String(selectedId),
          name: selectedName,
          thumbnailUrl: selectedIcon,
          streamUrl: currentStreamUrlRef.current,
        }).then((entry) => { if (entry) upsertLocal(entry); });
      } else if (e.status === "error") {
        // Player error — kick off auto-retry loop instead of dead-ending.
        clearLoadingTimeout();
        scheduleAutoRetry();
      } else if (e.status === "loading") {
        setPlayStatus((cur) => (cur === "playing" || cur === "reconnecting" ? cur : "loading"));
      }
    });
    return () => sub.remove();
  }, [player, activeProfile, selectedId, selectedName, selectedIcon, upsertLocal, scheduleAutoRetry, resetRetryState, clearLoadingTimeout]);

  // A live channel never legitimately ends. A playToEnd here means the
  // provider dropped the connection (e.g. the ~3h Xtream session cap) as a
  // clean stop rather than an error — run the same auto-retry loop.
  useEffect(() => {
    const sub = player.addListener("playToEnd", () => {
      clearLoadingTimeout();
      scheduleAutoRetry();
    });
    return () => sub.remove();
  }, [player, scheduleAutoRetry, clearLoadingTimeout]);

  // ── Stall detector: while we believe we're playing, poll currentTime.
  // If it hasn't advanced for ~15s the stream has frozen and we need to reload.
  //
  // Two gates prevent false reconnects on streams where currentTime is
  // unreliable under react-native-video Media3 (some raw MPEG-TS /
  // unbounded live HLS streams report currentTime=0 or a fixed value even
  // while playing perfectly):
  //   1. Only count when the player reports isPlaying=true.
  //   2. Only count once we've ever observed a positive currentTime.
  useEffect(() => {
    clearStallTimer();
    if (playStatus !== "playing") return;
    lastTimeRef.current = -1; // sentinel: capture first value on next tick
    lastTimeAtRef.current = Date.now();
    stallTimerRef.current = setInterval(() => {
      const now = Date.now();
      // On the expo engine "!playing" covers paused + normal buffering, so
      // we reset. On VLC a provider-side connection drop (e.g. the ~3h
      // Xtream session cap) leaves the player reporting not-playing while it
      // sits frozen mid-stream, so we only reset on an explicit user pause
      // and otherwise fall through to the currentTime-advance check below.
      const vlcEngine = playerEngineRef.current === "vlc";
      const intentionallyPaused = vlcEngine ? !!player._paused : !player.playing;
      if (intentionallyPaused) {
        lastTimeAtRef.current = now;
        return;
      }
      let t = 0;
      try { t = player.currentTime ?? 0; } catch { t = 0; }
      if (t <= 0) {
        lastTimeAtRef.current = now;
        return;
      }
      if (lastTimeRef.current === -1) {
        lastTimeRef.current = t;
        lastTimeAtRef.current = now;
        return;
      }
      if (t > lastTimeRef.current + 0.05) {
        // Time advanced — healthy.
        lastTimeRef.current = t;
        lastTimeAtRef.current = now;
        return;
      }
      if (now - lastTimeAtRef.current >= 15000) {
        // Frozen for 15s+ — auto-reconnect.
        clearStallTimer();
        scheduleAutoRetry();
      }
    }, 3000);
    return clearStallTimer;
  }, [playStatus, player, scheduleAutoRetry, clearStallTimer]);

  // Panels keep the overlay up. Hiding the controls out from under an open
  // Guide (or any future panel) made it impossible to read.
  const panelOpenRef = useRef(false);
  useEffect(() => { panelOpenRef.current = showGuide; }, [showGuide]);

  const resetFsHideTimer = useCallback(() => {
    if (fsHideTimerRef.current) clearTimeout(fsHideTimerRef.current);
    if (panelOpenRef.current) return;
    fsHideTimerRef.current = setTimeout(() => setShowFsOverlay(false), 4000);
  }, []);

  const handleFullScreen = useCallback(() => {
    // Pin the EPG preview to the *playing* channel so the fullscreen NOW/NEXT
    // bar always matches selectedName (the user may have hovered a different
    // channel in the sidebar before pressing Watch Full Screen).
    setPreviewedId(selectedId);
    setPreviewedName(selectedName);
    setIsFullscreen(true);
    setShowFsOverlay(true);
    resetFsHideTimer();
  }, [resetFsHideTimer, selectedId, selectedName]);

  // Initial TV focus target — the channel we entered with. Captured once so
  // it never re-fires on subsequent channel switches (otherwise focus would
  // keep jumping back to the original row).
  const initialFocusStreamRef = useRef<number>(streamId);

  // Channel row press: first press = switch + preview; pressing the same row
  // again (while it's already the active preview) opens fullscreen directly,
  // so the user never has to walk over to the "Watch Full Screen" button.
  const handleChannelRowPress = useCallback((s: LiveStream) => {
    if (s.stream_id === selectedId) {
      handleFullScreen();
      return;
    }
    switchToChannel(s);
  }, [selectedId, switchToChannel, handleFullScreen]);

  const exitFullscreen = useCallback(() => {
    if (cameInFullscreenRef.current) {
      // Came in directly fullscreen → leave the screen entirely
      navigation.goBack();
      return;
    }
    setIsFullscreen(false);
    if (fsHideTimerRef.current) clearTimeout(fsHideTimerRef.current);
  }, [navigation]);

  // Hardware back: exit fullscreen first, otherwise let nav handle it
  useEffect(() => {
    if (Platform.OS !== "android") return;
    const sub = BackHandler.addEventListener("hardwareBackPress", () => {
      // Close an open panel first, the way both VOD players do. Without this,
      // Back with the Guide open skipped straight past it and dropped out of
      // fullscreen altogether.
      if (isFullscreen && showGuide) {
        setShowGuide(false);
        panelOpenRef.current = false;
        resetFsHideTimer();
        return true;
      }
      if (isFullscreen && !cameInFullscreenRef.current) {
        setIsFullscreen(false);
        if (fsHideTimerRef.current) clearTimeout(fsHideTimerRef.current);
        return true;
      }
      return false;
    });
    return () => sub.remove();
  }, [isFullscreen, showGuide, resetFsHideTimer]);

  // Reset auto-hide whenever fullscreen turns on / overlay is re-shown
  useEffect(() => {
    if (isFullscreen && showFsOverlay) resetFsHideTimer();
    return () => { if (fsHideTimerRef.current) clearTimeout(fsHideTimerRef.current); };
  }, [isFullscreen, showFsOverlay, resetFsHideTimer]);

  const handlePlayerTap = useCallback(() => {
    if (showFsOverlay) {
      setShowFsOverlay(false);
      if (fsHideTimerRef.current) clearTimeout(fsHideTimerRef.current);
    } else {
      setShowFsOverlay(true);
      resetFsHideTimer();
    }
  }, [showFsOverlay, resetFsHideTimer]);

  const padT = insets.top + Spacing.sm;
  const padB = insets.bottom + Spacing.sm;
  const padL = Math.max(insets.left, Spacing.sm);

  // Portrait detection (small phones held upright). When true, the body
  // restacks: player full-width on top, channel list + EPG share the row
  // below so nothing gets cropped on a narrow screen.
  const winDims = useWindowDimensions();
  const isPortrait = winDims.height > winDims.width;

  return (
    <ThemedView style={styles.container}>
      {/* Hide the OS status bar while in fullscreen so the player truly fills
          the device on Android phones (where the status bar otherwise eats
          the top of the screen). Matches the regular PlayerScreen. */}
      <StatusBar hidden={isFullscreen} />

      {/* Header */}
      {!isFullscreen && (
      <View style={[styles.header, { paddingTop: padT, paddingLeft: padL, paddingRight: Spacing.md }]}>
        <SideMenuButton />
        <Pressable
          style={[styles.headerBtn, backActive && styles.headerBtnActive]}
          onPress={() => navigation.goBack()}
          onFocus={() => setBackFocused(true)}
          onBlur={() => setBackFocused(false)}
          onPressIn={() => setBackPressed(true)}
          onPressOut={() => setBackPressed(false)}
        >
          <Feather name="arrow-left" size={20} color={backActive ? Colors.dark.accent : Colors.dark.text} />
        </Pressable>

        <View style={styles.liveBadge}>
          <View style={styles.liveDot} />
          <ThemedText style={styles.liveText}>{PlayerLabels.live}</ThemedText>
        </View>

        <ThemedText style={styles.channelNameHeader} numberOfLines={1}>
          {selectedName}
        </ThemedText>

        <FavBtnHeader isFavourited={isFavourited} onPress={handleToggleFavourite} />
      </View>
      )}

      {!isFullscreen && (
        <View style={[styles.divider, { marginLeft: padL, marginRight: Spacing.md }]} />
      )}

      {/* Body — ALWAYS mounted (so the VideoView/SurfaceView never tears down
          when entering fullscreen). When fullscreen, the body is hidden via
          display:'none' and the playerWrap escapes via absolute positioning.
          This is the only way Android's SurfaceView keeps a clean surface
          across small ↔ fullscreen transitions — unmounting the VideoView
          (or its host tree) leaves the surface in a black state on phones. */}
      {/* Body uses a single, invariant JSX tree across portrait / landscape /
          fullscreen so the <VideoView> stays mounted at the exact same path
          in the tree — that's what prevents the player from re-establishing
          its connection across mode changes (Android SurfaceView restart).
          Portrait is achieved purely via styles:
            • body becomes flexDirection: 'column-reverse', which puts the
              second child (rightPanel = player + EPG) on top, full width,
              and the first child (sidebar = channel list) at the bottom.
            • playerWrap uses width:100% + aspectRatio 16:9 so the preview
              fills the top edge of the device. */}
      <View
        style={[
          styles.body,
          { paddingBottom: padB, paddingLeft: padL },
          isPortrait && !isFullscreen && styles.bodyPortrait,
          isFullscreen && styles.bodyFullscreen,
        ]}
      >
        {/* Sidebar — full-width bottom row in portrait, fixed-width left
            column in landscape. */}
        {!isFullscreen && categoryChannels.length > 0 ? (
          <View style={[styles.sidebar, isPortrait && styles.sidebarPortrait]}>
            <View style={styles.sidebarHeader}>
              <Feather
                name={categoryId === "favourites" ? "star" : categoryId === "recently" ? "clock" : groupForCategory ? "folder" : "tv"}
                size={11}
                color={groupForCategory ? groupForCategory.color : Colors.dark.accent}
              />
              <ThemedText style={[styles.sidebarHeaderText, groupForCategory ? { color: groupForCategory.color } : null]}>
                {sidebarTitle ?? "Channels"}
              </ThemedText>
            </View>
            <FlatList
              ref={listRef}
              data={categoryChannels}
              keyExtractor={(s) => String(s.stream_id)}
              renderItem={({ item }) => (
                <ChannelRow
                  item={item}
                  isSelected={item.stream_id === selectedId}
                  onPress={() => handleChannelRowPress(item)}
                  onFocusItem={handleChannelFocus}
              onLongPress={(ch) => { void toggleFavouriteForRef.current(ch); }}
                  hasTVPreferredFocus={item.stream_id === initialFocusStreamRef.current}
                />
              )}
              showsVerticalScrollIndicator={false}
              getItemLayout={(_, index) => ({
                length: CHANNEL_ROW_H,
                offset: CHANNEL_ROW_H * index,
                index,
              })}
              initialNumToRender={20}
              windowSize={10}
              onScrollToIndexFailed={(info) => {
                const offset = info.averageItemLength * info.index;
                listRef.current?.scrollToOffset({ offset, animated: false });
                setTimeout(() => {
                  try {
                    listRef.current?.scrollToIndex({
                      index: info.index,
                      animated: false,
                      viewPosition: 0.3,
                    });
                  } catch {}
                }, 50);
              }}
            />
          </View>
        ) : null}

        {/* Right panel — player on top, EPG below. Always rendered with the
            same tree path so VideoView never remounts between modes. */}
        <View
          style={[
            styles.rightPanel,
            isPortrait && !isFullscreen && styles.rightPanelPortrait,
            isFullscreen && styles.rightPanelFullscreen,
          ]}
        >
          <View
            style={
              isFullscreen
                ? styles.playerWrapFullscreen
                : isPortrait
                ? styles.playerWrapPortrait
                : styles.playerWrap
            }
          >
            <VideoView
              style={styles.player}
              player={player}
              contentFit="contain"
              nativeControls={false}
              allowsFullscreen={false}
              allowsPictureInPicture={false}
              engine={playerEngineRef.current}
            />
            {!isFullscreen && (
              <>
                <LinearGradient
                  colors={["transparent", "rgba(0,0,0,0.5)"]}
                  style={StyleSheet.absoluteFill}
                  pointerEvents="none"
                />
                {selectedIcon ? (
                  <View style={styles.channelIconWrap}>
                    <Image
                      source={{ uri: selectedIcon }}
                      style={styles.channelIcon}
                      contentFit="contain"
                    />
                  </View>
                ) : null}
              </>
            )}
            {playStatus !== "playing" && (
              <View style={styles.statusOverlay} pointerEvents="box-none">
                {playStatus === "loading" ? (
                  <>
                    <ActivityIndicator size="large" color={Colors.dark.accent} />
                    <ThemedText style={styles.statusOverlayText}>Loading...</ThemedText>
                  </>
                ) : (
                  <>
                    <ActivityIndicator size="large" color={Colors.dark.accent} />
                    <ThemedText style={styles.statusOverlayTitle}>Reconnecting…</ThemedText>
                    <ThemedText style={styles.statusOverlaySubtitle}>
                      {retryAttempt > 0
                        ? `Stream interrupted — retrying (attempt ${retryAttempt})`
                        : "Stream interrupted — reconnecting automatically"}
                    </ThemedText>
                    <Pressable
                      onPress={handleRetry}
                      style={({ pressed, focused }) => [
                        styles.retryBtn,
                        (pressed || focused) && styles.retryBtnActive,
                      ]}
                    >
                      <Feather name="refresh-cw" size={14} color={Colors.dark.text} />
                      <ThemedText style={styles.retryBtnText}>Retry Now</ThemedText>
                    </Pressable>
                  </>
                )}
              </View>
            )}
          </View>

          {!isFullscreen && (
            <>
              <View style={styles.pvMeta}>
                <View style={styles.pvMetaRow}>
                  {selectedIcon ? (
                    <View style={styles.pvLogoWrap}>
                      <Image source={{ uri: selectedIcon }} style={styles.pvLogo} contentFit="contain" />
                    </View>
                  ) : null}
                  <View style={styles.pvIdentity}>
                    <View style={styles.pvTitleRow}>
                      <ThemedText style={styles.pvTitle} numberOfLines={1}>
                        {parseChannelName(selectedName).title}
                      </ThemedText>
                      {parseChannelName(selectedName).badges.map((b) => (
                        <View key={b} style={styles.pvBadge}>
                          <ThemedText style={styles.pvBadgeText}>{b}</ThemedText>
                        </View>
                      ))}
                    </View>
                    <ThemedText style={styles.pvSub} numberOfLines={1}>
                      {playingNow
                        ? `${decodeEpgString(playingNow.title) || "No programme info"}${
                            playingNow.start_timestamp
                              ? `  ·  ${formatEpgTime(playingNow.start_timestamp)} - ${formatEpgTime(playingNow.stop_timestamp)}`
                              : ""
                          }`
                        : "No programme info"}
                    </ThemedText>
                  </View>
                </View>

                <View style={styles.pvProgressTrack}>
                  <View style={[styles.pvProgressFill, { width: `${playingProgress ?? 0}%` }]} />
                </View>

                <View style={styles.pvBtnRow}>
                  <ControlButton
                    icon="maximize-2"
                    label="Full Screen"
                    size="sm"
                    tone="primary"
                    hasTVPreferredFocus
                    onPress={handleFullScreen}
                  />
                  <ControlButton
                    icon="star"
                    size="sm"
                    active={isFavourited}
                    onPress={handleToggleFavourite}
                    accessibilityLabel="Favourite"
                  />
                  <ControlButton
                    icon="flag"
                    size="sm"
                    onPress={() => setShowReport(true)}
                    accessibilityLabel="Report"
                  />
                </View>
              </View>

            {/* Guide — last child of the wrapping row, with width 100%, so it
                breaks onto its own line and spans the full width beneath the
                picture and the channel info. It sits AFTER playerWrap rather than
                around it: changing the VideoView's position in the tree remounts
                the surface and reloads the stream. */}
          {!isFullscreen ? (
            <View style={[styles.guideCol, isPortrait && styles.guideColPortrait]}>
              <View style={styles.epgDivider}>
                <Feather name="calendar" size={11} color={Colors.dark.accent} />
                <ThemedText style={styles.epgHeaderText} numberOfLines={1}>
                  Programme Guide for{" "}
                  <ThemedText style={styles.epgHeaderChannel}>{previewedName}</ThemedText>
                </ThemedText>
              </View>
              <View style={styles.epgPanel}>
                {epgLoading ? (
                  <View style={styles.epgState}>
                    <ActivityIndicator size="small" color={Colors.dark.accent} />
                    <ThemedText style={styles.epgStateText}>Loading guide...</ThemedText>
                  </View>
                ) : epgListings.length === 0 ? (
                  <View style={styles.epgState}>
                    <Feather name="calendar" size={28} color={Colors.dark.border} />
                    <ThemedText style={styles.epgStateText}>No guide available</ThemedText>
                  </View>
                ) : (
                  <ScrollView showsVerticalScrollIndicator={false}>
                    {epgListings.map((listing, idx) => (
                      <EpgRow
                        key={listing.id || String(idx)}
                        listing={listing}
                        isNow={listing.now_playing === 1 || idx === 0}
                        // Only the programme immediately after the current one is
                        // "up next"; everything later is simply a later listing.
                        isNext={idx === nowIndex + 1}
                      />
                    ))}
                  </ScrollView>
                )}
              </View>
            </View>
          ) : null}
            </>
          )}
        </View>

      </View>

      {/* Fullscreen tap target + controls — siblings on top of the
          (now absolute-positioned) playerWrap. The VideoView is rendered
          inside playerWrap above, so it stays alive across the transition. */}
      {isFullscreen && (
        <>
          {/* Tap target: catches all taps to toggle overlay. zIndex above
              the playerWrap (50) but below the controls (70). Transparent,
              so the SurfaceView underneath shows through. Focusable on
              Android TV / Fire TV so D-pad up/down events route to
              onKeyDown for quick channel switching. */}
          <Pressable
            style={[StyleSheet.absoluteFill, { zIndex: 60 }]}
            onPress={handlePlayerTap}
            focusable={Platform.OS === "android"}
            onKeyDown={Platform.OS === "android" ? handleFsKeyDown : undefined}
          />

          {showFsOverlay && (
            <View style={[StyleSheet.absoluteFill, { zIndex: 70 }]} pointerEvents="box-none">
              <LinearGradient
                colors={["rgba(0,0,0,0.85)", "transparent"]}
                style={styles.fsTopGradient}
                pointerEvents="none"
              />
              <View style={[styles.fsTopBar, { paddingTop: padT, paddingLeft: padL + Spacing.sm, paddingRight: Spacing.lg }]}>
                <SideMenuButton transparent />
                <ControlButton
                  icon="arrow-left"
                  onPress={exitFullscreen}
                  onActivity={resetFsHideTimer}
                  accessibilityLabel="Exit full screen"
                />
                <View style={styles.fsTopSpacer} />
                {footballEnabled ? (
                  <ControlButton
                    icon="soccer"
                    iconSet="material"
                    onPress={() => { setShowFootball((v) => !v); resetFsHideTimer(); }}
                    onActivity={resetFsHideTimer}
                    active={showFootball}
                    accessibilityLabel="Football scores"
                  />
                ) : null}
                <ControlButton
                  icon="flag"
                  onPress={() => { setShowReport(true); resetFsHideTimer(); }}
                  onActivity={resetFsHideTimer}
                  accessibilityLabel="Report a problem"
                />
                <ControlButton
                  icon="star"
                  onPress={handleToggleFavourite}
                  onActivity={resetFsHideTimer}
                  active={isFavourited}
                  accessibilityLabel="Favourite"
                />
              </View>

              {/* Bottom info bar — channel + NOW/NEXT programmes + channel up/down */}
              <LinearGradient
                colors={["transparent", "rgba(0,0,0,0.92)"]}
                style={styles.fsBottomGradient}
                pointerEvents="none"
              />
              <View
                pointerEvents="box-none"
                style={[
                  styles.fsBottomBar,
                  { paddingLeft: padL + Spacing.md, paddingRight: padL + Spacing.md, paddingBottom: insets.bottom + Spacing.md },
                ]}
              >
                {showGuide ? (
                  <View style={styles.fsGuideWrap}>
                    <EpgPanel
                      channelName={selectedName}
                      listings={epgListings}
                      loading={epgLoading}
                      onClose={() => { setShowGuide(false); resetFsHideTimer(); }}
                      onActivity={resetFsHideTimer}
                    />
                  </View>
                ) : null}

                {/* One bar: identity, what is on, how far through it is, and
                    the controls — in a single container with one padding, the
                    way the design has it. Previously these were three separate
                    floating pieces (top bar, rounded card, corner buttons). */}
                <View pointerEvents="box-none" style={styles.fsBar}>
                  <View style={styles.fsBarHead}>
                    {selectedIcon ? (
                      <View style={styles.fsBarLogoWrap}>
                        <Image source={{ uri: selectedIcon }} style={styles.fsBarLogo} contentFit="contain" />
                      </View>
                    ) : null}
                    <View style={styles.fsBarIdentity}>
                      <ThemedText style={styles.fsBarTitle} numberOfLines={1}>{selectedName}</ThemedText>
                      <ThemedText style={styles.fsBarSub} numberOfLines={1}>
                        {nowProg
                          ? `${decodeEpgString(nowProg.title) || "No programme info"}${
                              nowProg.start_timestamp
                                ? `  ·  ${formatEpgTime(nowProg.start_timestamp)} - ${formatEpgTime(nowProg.stop_timestamp)}`
                                : ""
                            }`
                          : epgLoading ? "Loading guide…" : "No programme info"}
                      </ThemedText>
                      {nextProg ? (
                        <ThemedText style={styles.fsBarNext} numberOfLines={1}>
                          {`NEXT  ${decodeEpgString(nextProg.title)}${
                            nextProg.start_timestamp ? `  ·  ${formatEpgTime(nextProg.start_timestamp)}` : ""
                          }`}
                        </ThemedText>
                      ) : null}
                    </View>
                    <View style={styles.fsLivePill}>
                      <View style={styles.fsLiveDot} />
                      <ThemedText style={styles.fsLivePillText}>{PlayerLabels.live}</ThemedText>
                    </View>
                  </View>

                  {/* How far through the current programme we are — the live
                      equivalent of the VOD seek bar, and the only honest thing
                      a progress line can show on a live stream. */}
                  <View style={styles.fsProgressTrack}>
                    <View style={[styles.fsProgressFill, { width: `${progressPct}%` }]} />
                  </View>

                  <View style={styles.fsActionRow}>
                    <ControlButton
                      icon={paused ? "play" : "pause"}
                      tone="primary"
                      onPress={togglePlayPause}
                      onActivity={resetFsHideTimer}
                      accessibilityLabel="Play or pause"
                    />
                    {hasChannelList ? (
                      <>
                        <ControlButton
                          icon="chevron-up"
                          label={PlayerLabels.channelUp}
                          disabled={atFirstChannel}
                          onPress={() => { stepChannelInFullscreen(-1); resetFsHideTimer(); }}
                          onActivity={resetFsHideTimer}
                        />
                        <ControlButton
                          icon="chevron-down"
                          label={PlayerLabels.channelDown}
                          disabled={atLastChannel}
                          hasTVPreferredFocus
                          onPress={() => { stepChannelInFullscreen(1); resetFsHideTimer(); }}
                          onActivity={resetFsHideTimer}
                        />
                      </>
                    ) : null}

                    <View style={styles.fsActionSpacer} />

                    <ControlButton
                      icon="calendar"
                      label={PlayerLabels.guide}
                      onPress={() => {
                        setShowGuide((v) => {
                          const next = !v;
                          panelOpenRef.current = next;
                          if (next && fsHideTimerRef.current) clearTimeout(fsHideTimerRef.current);
                          return next;
                        });
                        resetFsHideTimer();
                      }}
                      onActivity={resetFsHideTimer}
                      active={showGuide}
                    />
                  </View>
                </View>
              </View>
            </View>
          )}

          {showFootball && footballEnabled ? (
            <FootballScoreTracker
              topInset={padT + 44}
              bottomInset={insets.bottom + Spacing.md}
              sideInset={padL}
            />
          ) : null}
        </>
      )}

      {/* Toast */}
      {toastVisible ? (
        <Animated.View
          style={[styles.toast, { opacity: toastAnim }]}
          pointerEvents="none"
        >
          <Feather name="star" size={14} color={Colors.dark.accent} />
          <ThemedText style={styles.toastText}>{toastMsg}</ThemedText>
        </Animated.View>
      ) : null}

      {/* Report content modal */}
      <Modal
        visible={showReport}
        transparent
        animationType="fade"
        onRequestClose={() => {
          if (!reportSubmitting) {
            setShowReport(false);
            setReportReason(null);
            setReportOther("");
            setReportDone(false);
          }
        }}
      >
        <View style={styles.reportBackdrop}>
          <View style={styles.reportCard}>
            {reportDone ? (
              <>
                <Feather name="check-circle" size={36} color={Colors.dark.accent} />
                <ThemedText style={styles.reportTitle}>Report Submitted</ThemedText>
                <ThemedText style={styles.reportSubtitle}>
                  Thank you — we will look into this.
                </ThemedText>
              </>
            ) : (
              <>
                <View style={styles.reportHeader}>
                  <Feather name="flag" size={18} color={Colors.dark.error} />
                  <ThemedText style={styles.reportTitle}>Report Content</ThemedText>
                </View>
                <ThemedText style={styles.reportSubtitle} numberOfLines={1}>
                  {selectedName}
                </ThemedText>
                <View style={styles.reportReasons}>
                  {REPORT_REASONS.map((r, i) => (
                    <ReportReasonBtn
                      key={r}
                      label={r}
                      selected={reportReason === r}
                      onPress={() => setReportReason(r)}
                      autoFocus={i === 0}
                    />
                  ))}
                </View>
                {reportReason === "Other" ? (
                  <TextInput
                    style={styles.reportOtherInput}
                    placeholder="Describe the issue..."
                    placeholderTextColor={Colors.dark.border}
                    value={reportOther}
                    onChangeText={setReportOther}
                    multiline
                    numberOfLines={3}
                    maxLength={500}
                    autoFocus
                  />
                ) : null}
                <View style={styles.reportBtnRow}>
                  <ReportCancelBtn
                    onPress={() => {
                      setShowReport(false);
                      setReportReason(null);
                      setReportOther("");
                    }}
                    disabled={reportSubmitting}
                  />
                  <ReportSubmitBtn
                    onPress={handleSubmitReport}
                    submitting={reportSubmitting}
                    disabled={reportSubmitting || !reportReason || (reportReason === "Other" && !reportOther.trim())}
                  />
                </View>
              </>
            )}
          </View>
        </View>
      </Modal>
    </ThemedView>
  );
}

function ReportReasonBtn({
  label,
  selected,
  onPress,
  autoFocus,
}: {
  label: string;
  selected: boolean;
  onPress: () => void;
  autoFocus?: boolean;
}) {
  const [focused, setFocused] = useState(false);
  const [pressed, setPressed] = useState(false);
  const isActive = focused || pressed;
  return (
    <Pressable
      style={[
        styles.reportReasonBtn,
        selected && styles.reportReasonBtnSelected,
        isActive && styles.reportReasonBtnHover,
      ]}
      onPress={onPress}
      onFocus={() => setFocused(true)}
      onBlur={() => setFocused(false)}
      onPressIn={() => setPressed(true)}
      onPressOut={() => setPressed(false)}
      hasTVPreferredFocus={autoFocus}
    >
      <View style={[styles.reportRadio, selected && styles.reportRadioSelected]}>
        {selected ? <View style={styles.reportRadioDot} /> : null}
      </View>
      <ThemedText style={[styles.reportReasonText, selected && styles.reportReasonTextSelected]}>
        {label}
      </ThemedText>
    </Pressable>
  );
}

function ReportCancelBtn({ onPress, disabled }: { onPress: () => void; disabled?: boolean }) {
  const [focused, setFocused] = useState(false);
  const [pressed, setPressed] = useState(false);
  const isActive = focused || pressed;
  return (
    <Pressable
      style={[styles.reportCancelBtn, isActive && styles.reportCancelBtnHover]}
      onPress={onPress}
      onFocus={() => setFocused(true)}
      onBlur={() => setFocused(false)}
      onPressIn={() => setPressed(true)}
      onPressOut={() => setPressed(false)}
      disabled={disabled}
    >
      <ThemedText style={styles.reportCancelText}>Cancel</ThemedText>
    </Pressable>
  );
}

function FsArrowButton({
  direction,
  disabled,
  autoFocus,
  onPress,
  onActivity,
  onKeyDown,
}: {
  direction: "up" | "down";
  disabled?: boolean;
  autoFocus?: boolean;
  onPress: () => void;
  onActivity: () => void;
  onKeyDown?: (e: any) => void;
}) {
  const [focused, setFocused] = useState(false);
  const [hovered, setHovered] = useState(false);
  const [pressed, setPressed] = useState(false);
  const isActive = focused || hovered || pressed;
  return (
    <Pressable
      style={[
        styles.fsArrowBtn,
        isActive && styles.fsArrowBtnActive,
        disabled && styles.fsArrowBtnDisabled,
      ]}
      onPress={onPress}
      onFocus={() => { setFocused(true); onActivity(); }}
      onBlur={() => setFocused(false)}
      onHoverIn={() => { setHovered(true); onActivity(); }}
      onHoverOut={() => setHovered(false)}
      onPressIn={() => setPressed(true)}
      onPressOut={() => setPressed(false)}
      disabled={disabled}
      hasTVPreferredFocus={autoFocus}
      onKeyDown={onKeyDown}
    >
      <Feather
        name={direction === "up" ? "chevron-up" : "chevron-down"}
        size={26}
        color={disabled ? Colors.dark.border : isActive ? Colors.dark.accent : Colors.dark.text}
      />
    </Pressable>
  );
}

function ReportSubmitBtn({
  onPress,
  submitting,
  disabled,
}: {
  onPress: () => void;
  submitting: boolean;
  disabled?: boolean;
}) {
  const [focused, setFocused] = useState(false);
  const [pressed, setPressed] = useState(false);
  const isActive = focused || pressed;
  return (
    <Pressable
      style={[
        styles.reportSubmitBtn,
        disabled && styles.reportSubmitBtnDisabled,
        isActive && !disabled && styles.reportSubmitBtnHover,
      ]}
      onPress={onPress}
      onFocus={() => setFocused(true)}
      onBlur={() => setFocused(false)}
      onPressIn={() => setPressed(true)}
      onPressOut={() => setPressed(false)}
      disabled={disabled}
    >
      {submitting
        ? <ActivityIndicator size="small" color="#fff" />
        : <ThemedText style={styles.reportSubmitText}>Submit Report</ThemedText>}
    </Pressable>
  );
}

function FavBtnHeader({ isFavourited, onPress }: { isFavourited: boolean; onPress: () => void }) {
  const [focused, setFocused] = useState(false);
  return (
    <Pressable
      style={[styles.headerBtn, (focused || isFavourited) && styles.headerBtnActive]}
      onPress={onPress}
      onFocus={() => setFocused(true)}
      onBlur={() => setFocused(false)}
    >
      <Feather
        name="star"
        size={18}
        color={isFavourited ? Colors.dark.accent : Colors.dark.textSecondary}
      />
    </Pressable>
  );
}

function FullScreenButton({ onPress, autoFocus }: { onPress: () => void; autoFocus?: boolean }) {
  const [focused, setFocused] = useState(false);
  const [pressed, setPressed] = useState(false);
  const isActive = focused || pressed;
  return (
    <Pressable
      style={[styles.fullScreenBtn, isActive && styles.fullScreenBtnActive]}
      onPress={onPress}
      onFocus={() => setFocused(true)}
      onBlur={() => setFocused(false)}
      onPressIn={() => setPressed(true)}
      onPressOut={() => setPressed(false)}
      hasTVPreferredFocus={autoFocus && Platform.OS !== "web"}
    >
      {isActive ? (
        <LinearGradient
          colors={["#FF8800", "#FF5500"]}
          style={StyleSheet.absoluteFill}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
        />
      ) : null}
      <Feather name="maximize-2" size={18} color="#fff" />
      <ThemedText style={styles.fullScreenBtnText}>Watch Full Screen</ThemedText>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.dark.backgroundRoot },

  header: {
    flexDirection: "row",
    alignItems: "center",
    paddingBottom: Spacing.sm,
    paddingRight: Spacing.md,
    gap: Spacing.sm,
  },
  headerBtn: {
    width: 40,
    height: 40,
    borderRadius: BorderRadius.full,
    backgroundColor: Colors.dark.backgroundDefault,
    borderWidth: 1,
    borderColor: Colors.dark.border,
    justifyContent: "center",
    alignItems: "center",
    flexShrink: 0,
  },
  headerBtnActive: {
    borderColor: Colors.dark.accent,
    backgroundColor: Colors.dark.accentDim,
  },
  liveBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    backgroundColor: "rgba(220,30,30,0.2)",
    borderWidth: 1,
    borderColor: "rgba(220,30,30,0.5)",
    borderRadius: BorderRadius.full,
    paddingHorizontal: 8,
    paddingVertical: 4,
    flexShrink: 0,
  },
  liveDot: { width: 5, height: 5, borderRadius: 2.5, backgroundColor: "#DC1E1E" },
  liveText: { color: "#FF5555", fontSize: 10, fontFamily: PlayerUI.font.uiBold, letterSpacing: 1 },
  channelNameHeader: {
    flex: 1,
    fontSize: 17,
    fontWeight: "700",
    color: Colors.dark.text,
  },

  divider: { height: 1, backgroundColor: Colors.dark.border, marginBottom: Spacing.sm },

  body: {
    flex: 1,
    flexDirection: "row",
    gap: Spacing.md,
  },

  // ── Sidebar ────────────────────────────────────────────────────────────────
  sidebar: {
    width: SIDEBAR_W,
    borderRightWidth: 1,
    borderRightColor: Colors.dark.border,
    paddingRight: Spacing.xs,
  },
  sidebarHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.xs,
    paddingBottom: Spacing.xs,
    marginBottom: Spacing.xs,
    borderBottomWidth: 1,
    borderBottomColor: Colors.dark.border,
  },
  sidebarHeaderText: {
    fontSize: 10,
    fontWeight: "700",
    color: Colors.dark.accent,
    letterSpacing: 0.8,
    textTransform: "uppercase",
  },

  channelRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
    paddingVertical: 7,
    paddingHorizontal: Spacing.xs,
    borderRadius: BorderRadius.sm,
    marginBottom: 2,
    overflow: "hidden",
  },
  channelRowActive: {
    backgroundColor: Colors.dark.accentDim,
  },
  channelRowBar: {
    position: "absolute",
    left: 0,
    top: 4,
    bottom: 4,
    width: 3,
    borderRadius: 2,
    backgroundColor: Colors.dark.accent,
  },
  channelRowIcon: {
    width: 32,
    height: 32,
    borderRadius: 4,
    flexShrink: 0,
  },
  channelRowIconPlaceholder: {
    backgroundColor: Colors.dark.backgroundDefault,
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
  channelRowName: {
    flex: 1,
    fontSize: 12,
    color: Colors.dark.textSecondary,
    lineHeight: 16,
  },
  channelRowNameActive: {
    color: Colors.dark.text,
    fontWeight: "600",
  },

  // ── Right panel ───────────────────────────────────────────────────────────
  rightPanel: {
    flex: 1,
    // Deliberately a WRAPPING ROW, not a column. The picture and the channel
    // info sit side by side; the guide is given width 100% so it wraps onto the
    // next line and spans the full width underneath.
    //
    // It is done this way because the VideoView must keep its exact position in
    // the tree — wrapping it in a row container to lay it out would tear down
    // the SurfaceView and reload the stream. Siblings and styles only.
    flexDirection: "row",
    flexWrap: "wrap",
    alignItems: "flex-start",
    // Pack the two lines to the top. "stretch" shared the leftover height
    // between them, which opened a band of empty space under the picture before
    // the guide started.
    alignContent: "flex-start",
    gap: Spacing.md,
    paddingRight: Spacing.md,
  },

  playerWrap: {
    width: "58%",
    aspectRatio: 16 / 9,
    alignSelf: "flex-start",
    borderRadius: BorderRadius.md,
    overflow: "hidden",
    backgroundColor: "#000",
    borderWidth: 1,
    borderColor: Colors.dark.border,
    flexShrink: 0,
  },
  bodyFullscreen: {
    paddingBottom: 0,
    paddingLeft: 0,
    paddingRight: 0,
    gap: 0,
  },
  // Portrait body uses column-reverse so the second child (rightPanel =
  // player + EPG) appears on top and the first child (sidebar) appears at
  // the bottom. The JSX order stays identical to landscape, which keeps
  // the VideoView at the exact same tree path across all modes — that's
  // how we avoid Android SurfaceView reconnects on portrait ↔ fullscreen.
  bodyPortrait: {
    flexDirection: "column-reverse",
    paddingRight: Spacing.sm,
    gap: Spacing.sm,
  },
  // Sidebar in portrait: full-width row sitting at the bottom of the body.
  // Caps height so it leaves room for the player + EPG above it.
  sidebarPortrait: {
    width: "100%",
    maxHeight: "32%",
    borderRightWidth: 0,
    borderTopWidth: 1,
    borderTopColor: Colors.dark.border,
    paddingRight: 0,
    paddingTop: Spacing.xs,
  },
  // Right panel in portrait: full width (overrides the landscape flex:1
  // which is sized against the sidebar). flex:1 here lets it take the
  // remaining vertical space above the sidebar.
  rightPanelPortrait: {
    flex: 1,
    width: "100%",
    paddingRight: 0,
  },
  // Player in portrait: full width, fixed 16:9 aspect so it sits cleanly
  // across the top edge of the device. No maxHeight constraint.
  playerWrapPortrait: {
    width: "100%",
    aspectRatio: 16 / 9,
    borderRadius: BorderRadius.md,
    overflow: "hidden",
    backgroundColor: "#000",
    borderWidth: 1,
    borderColor: Colors.dark.border,
    flexShrink: 0,
  },
  rightPanelFullscreen: {
    flex: 1,
    paddingRight: 0,
    gap: 0,
  },
  playerWrapFullscreen: {
    flex: 1,
    width: "100%",
    height: "100%",
    backgroundColor: "#000",
    overflow: "hidden",
    borderRadius: 0,
    borderWidth: 0,
  },
  player: { width: "100%", height: "100%" },
  channelIconWrap: {
    position: "absolute",
    bottom: Spacing.sm,
    right: Spacing.sm,
    width: 40,
    height: 40,
    backgroundColor: "rgba(0,0,0,0.55)",
    borderRadius: BorderRadius.sm,
    padding: 4,
  },
  channelIcon: { width: "100%", height: "100%" },
  statusOverlay: {
    ...StyleSheet.absoluteFillObject,
    // Opaque so the previous channel's last decoded frame is fully hidden
    // while loading/reconnecting and the status text stays readable. (Was
    // `Colors.dark.background`, which doesn't exist on the theme → resolved
    // to undefined/transparent, letting the stale frame show through.)
    backgroundColor: Colors.dark.backgroundRoot,
    alignItems: "center",
    justifyContent: "center",
    gap: Spacing.sm,
    paddingHorizontal: Spacing.lg,
  },
  statusOverlayText: {
    color: Colors.dark.textSecondary,
    fontSize: 13,
    marginTop: Spacing.xs,
  },
  statusOverlayTitle: {
    color: Colors.dark.text,
    fontSize: 16,
    fontWeight: "700",
    marginTop: Spacing.xs,
  },
  statusOverlaySubtitle: {
    color: Colors.dark.textSecondary,
    fontSize: 12,
    textAlign: "center",
  },
  retryBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: Spacing.md,
    paddingVertical: 8,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: Colors.dark.border,
    backgroundColor: Colors.dark.backgroundSecondary,
    marginTop: Spacing.xs,
  },
  retryBtnActive: {
    borderColor: Colors.dark.accent,
    backgroundColor: Colors.dark.accent + "22",
  },
  retryBtnText: {
    color: Colors.dark.text,
    fontSize: 12,
    fontWeight: "600",
  },

  fullScreenBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: Spacing.sm,
    borderRadius: BorderRadius.md,
    backgroundColor: Colors.dark.backgroundDefault,
    borderWidth: 1.5,
    borderColor: Colors.dark.accent,
    paddingVertical: Spacing.sm,
    overflow: "hidden",
    shadowColor: "#FF6600",
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.35,
    shadowRadius: 8,
    elevation: 6,
    flexShrink: 0,
  },
  fullScreenBtnActive: {
    borderColor: "#FF8800",
    shadowOpacity: 0.8,
    shadowRadius: 14,
  },
  fullScreenBtnText: {
    color: "#fff",
    fontSize: 13,
    fontWeight: "700",
    letterSpacing: 0.3,
  },

  epgDivider: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.xs,
    paddingBottom: Spacing.xs,
    borderBottomWidth: 1,
    borderBottomColor: Colors.dark.border,
    flexShrink: 0,
  },
  epgHeaderText: {
    flex: 1,
    fontSize: 10,
    fontWeight: "700",
    color: Colors.dark.accent,
    letterSpacing: 0.8,
    textTransform: "uppercase",
  },
  epgHeaderChannel: {
    color: Colors.dark.text,
    fontWeight: "700",
  },

  epgPanel: { flex: 1 },

  epgRow: {
    flexDirection: "row",
    gap: Spacing.sm,
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.xs,
    borderRadius: BorderRadius.sm,
    marginBottom: 2,
    overflow: "hidden",
    borderWidth: 1,
    borderColor: "transparent",
  },
  epgRowNow: { borderColor: "rgba(255,102,0,0.3)" },

  epgDotCol: { width: 18, alignItems: "center", paddingTop: 2 },
  epgDotLive: {
    width: 13, height: 13, borderRadius: 6.5,
    backgroundColor: "rgba(255,102,0,0.25)",
    borderWidth: 1, borderColor: Colors.dark.accent,
    justifyContent: "center", alignItems: "center",
  },
  epgDotLiveInner: { width: 5, height: 5, borderRadius: 2.5, backgroundColor: Colors.dark.accent },
  epgConnector: { width: 1, flex: 1, backgroundColor: "rgba(255,102,0,0.25)", marginTop: 3 },
  epgDotNext: { width: 7, height: 7, borderRadius: 3.5, backgroundColor: Colors.dark.border, marginTop: 3 },

  epgInfo: { flex: 1, gap: 2 },
  epgMeta: { flexDirection: "row", alignItems: "center", gap: Spacing.sm },
  nowBadge: {
    backgroundColor: Colors.dark.accent, borderRadius: 3,
    paddingHorizontal: 5, paddingVertical: 1,
  },
  nowBadgeText: { color: "#fff", fontSize: 8, fontWeight: "800", letterSpacing: 0.5 },
  upNextLabel: {
    fontSize: 9, fontWeight: "600", color: Colors.dark.textSecondary,
    letterSpacing: 0.4, textTransform: "uppercase",
  },
  epgTime: { fontSize: 11, color: Colors.dark.textSecondary, fontWeight: "500" },
  epgTitle: { fontSize: 12, fontWeight: "600", color: Colors.dark.textSecondary, lineHeight: 17 },
  epgTitleNow: { color: Colors.dark.text, fontSize: 13, fontWeight: "700" },
  epgDesc: { fontSize: 10, color: Colors.dark.textSecondary, lineHeight: 15, marginTop: 1 },

  epgState: { flex: 1, justifyContent: "center", alignItems: "center", gap: Spacing.sm },
  epgStateText: { color: Colors.dark.textSecondary, fontSize: 12 },

  toast: {
    position: "absolute",
    bottom: 60,
    alignSelf: "center",
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
    backgroundColor: "rgba(8,8,8,0.92)",
    borderRadius: BorderRadius.full,
    paddingHorizontal: Spacing.xl,
    paddingVertical: Spacing.sm,
    borderWidth: 1,
    borderColor: Colors.dark.accent,
    shadowColor: "#FF6600",
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.6,
    shadowRadius: 12,
  },
  toastText: { color: "#fff", fontSize: 14, fontWeight: "600" },

  // ── Fullscreen overlay ─────────────────────────────────────────────────────
  fsRoot: {
    position: "absolute",
    top: 0, bottom: 0, left: 0, right: 0,
    backgroundColor: "#000",
  },
  fsTopGradient: {
    position: "absolute",
    top: 0, left: 0, right: 0,
    height: 120,
  },
  fsTopBar: {
    position: "absolute",
    top: 0, left: 0, right: 0,
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
    paddingBottom: Spacing.sm,
  },
  fsTitle: {
    flex: 1,
    fontSize: 20,
    fontFamily: PlayerUI.font.display,
    letterSpacing: -0.2,
    color: "#fff",
  },

  // ── Fullscreen bottom info bar (channel + NOW/NEXT + up/down) ───────────────
  fsBottomGradient: {
    position: "absolute",
    bottom: 0, left: 0, right: 0,
    height: 160,
  },
  fsBottomBar: {
    position: "absolute",
    bottom: 0, left: 0, right: 0,
  },
  pvMeta: { flex: 1, minWidth: 0, gap: Spacing.md, alignSelf: "stretch", justifyContent: "center" },
  // Logo above the name, both centred in the column beside the picture — the
  // block then reads as one unit and fills the width it has.
  pvMetaRow: { flexDirection: "column", alignItems: "center", gap: Spacing.md },
  pvLogoWrap: {
    width: 88, height: 88, borderRadius: BorderRadius.md,
    backgroundColor: "rgba(255,255,255,0.06)", alignItems: "center", justifyContent: "center", overflow: "hidden",
  },
  pvLogo: { width: "100%", height: "100%" },
  pvIdentity: { alignSelf: "stretch", minWidth: 0, gap: 4, alignItems: "center" },
  pvTitleRow: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: Spacing.sm, maxWidth: "100%" },
  // Single line, always. A long channel name that wrapped pushed the whole
  // column — programme, progress, buttons — down the screen.
  pvTitle: { fontSize: 18, fontFamily: PlayerUI.font.display, letterSpacing: -0.2, color: "#fff", flexShrink: 1, textAlign: "center" },
  pvBadge: {
    paddingHorizontal: 6, paddingVertical: 2, borderRadius: 4,
    backgroundColor: "rgba(255,255,255,0.12)",
  },
  pvBadgeText: { fontSize: 10, fontFamily: PlayerUI.font.uiBold, color: "rgba(255,255,255,0.7)", letterSpacing: 0.4 },
  pvSub: { fontSize: 12, fontFamily: PlayerUI.font.uiRegular, color: "rgba(255,255,255,0.72)", textAlign: "center" },
  pvProgressTrack: { height: 4, borderRadius: 2, backgroundColor: "rgba(255,255,255,0.18)", overflow: "hidden" },
  pvProgressFill: { height: "100%", borderRadius: 2, backgroundColor: Colors.dark.accent },
  // No wrap: if it does not fit it should compress, not stack. Stacking pushed
  // everything below it down the screen.
  pvBtnRow: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: Spacing.xs, flexWrap: "nowrap" },
  pvBtnSpacer: { flex: 1, minWidth: Spacing.sm },
  guideCol: {
    // flexBasis — NOT flex/width — is what decides line placement in a wrapping
    // row. `flex: 1` sets basis 0%, which told the layout "I fit on the current
    // line", so the guide sat to the RIGHT of the picture instead of wrapping
    // underneath it. A 100% basis cannot share a line with anything, so it
    // always breaks onto its own full-width row.
    flexBasis: "100%",
    flexGrow: 1,
    flexShrink: 0,
    alignSelf: "stretch",
    minHeight: 240,
    gap: Spacing.sm,
  },
  guideColPortrait: { paddingLeft: 0, paddingTop: Spacing.md },
  fsTopSpacer: { flex: 1 },
  fsBar: {
    backgroundColor: "rgba(10,10,14,0.92)",
    borderRadius: PlayerUI.panel.radius,
    borderWidth: 1,
    borderColor: PlayerUI.panel.border,
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.lg,
    gap: Spacing.md,
  },
  fsBarHead: { flexDirection: "row", alignItems: "center", gap: Spacing.md },
  fsBarLogoWrap: {
    width: 48,
    height: 48,
    borderRadius: BorderRadius.xs,
    backgroundColor: "rgba(255,255,255,0.06)",
    alignItems: "center",
    justifyContent: "center",
    overflow: "hidden",
  },
  fsBarLogo: { width: "100%", height: "100%" },
  fsBarIdentity: { flex: 1, minWidth: 0, gap: 2 },
  fsBarTitle: { fontSize: 22, fontFamily: PlayerUI.font.display, letterSpacing: -0.3, color: "#fff" },
  fsBarSub: { fontSize: 13, fontFamily: PlayerUI.font.uiRegular, color: "rgba(255,255,255,0.72)" },
  fsBarNext: { fontSize: 12, fontFamily: PlayerUI.font.uiRegular, color: "rgba(255,255,255,0.42)" },
  fsLivePill: {
    flexDirection: "row",
    alignItems: "center",
    gap: 7,
    backgroundColor: "#D92B2B",
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: BorderRadius.full,
  },
  fsLiveDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: "#fff" },
  fsLivePillText: { color: "#fff", fontSize: 11, fontFamily: PlayerUI.font.uiBold, letterSpacing: 1 },
  fsProgressTrack: {
    height: 4,
    borderRadius: 2,
    backgroundColor: "rgba(255,255,255,0.18)",
    overflow: "hidden",
  },
  fsProgressFill: { height: "100%", borderRadius: 2, backgroundColor: Colors.dark.accent },
  fsBottomCard: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.md,
    backgroundColor: PlayerUI.panel.bg,
    borderRadius: PlayerUI.panel.radius,
    borderWidth: 1,
    borderColor: PlayerUI.panel.border,
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.md,
  },
  fsBottomLogoWrap: {
    width: 56,
    height: 56,
    borderRadius: BorderRadius.sm,
    backgroundColor: "rgba(255,255,255,0.06)",
    borderWidth: 1,
    borderColor: Colors.dark.border,
    justifyContent: "center",
    alignItems: "center",
    padding: 4,
    flexShrink: 0,
  },
  fsBottomLogo: { width: "100%", height: "100%" },
  fsBottomInfo: { flex: 1, gap: 4 },
  fsBottomChannel: { fontSize: 18, fontFamily: PlayerUI.font.display, letterSpacing: -0.2, color: "#fff" },
  fsBottomEpgRow: {
    flexDirection: "column",
    alignItems: "flex-start",
    gap: 4,
  },
  fsBottomNow: { flexDirection: "row", alignItems: "center", gap: Spacing.sm, flexShrink: 1 },
  fsBottomNowTitle: { fontSize: 14, fontFamily: PlayerUI.font.ui, color: Colors.dark.accent, flexShrink: 1 },
  fsBottomNext: { flexDirection: "row", alignItems: "center", gap: 6, flexShrink: 1 },
  fsBottomNextLabel: { fontSize: 10, fontFamily: PlayerUI.font.uiBold, color: Colors.dark.textSecondary, letterSpacing: 1.2 },
  fsBottomNextTitle: { fontSize: 13, fontFamily: PlayerUI.font.uiRegular, color: "rgba(255,255,255,0.88)", flexShrink: 1 },
  fsBottomTime: { fontSize: 12, fontFamily: PlayerUI.font.uiRegular, fontVariant: ["tabular-nums"], color: Colors.dark.textSecondary },
  fsActionRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
    marginTop: Spacing.md,
    flexWrap: "wrap",
  },
  fsActionSpacer: { flex: 1, minWidth: Spacing.md },
  fsGuideWrap: { marginTop: Spacing.md, alignItems: "flex-end" },
  fsArrowCol: { gap: Spacing.sm, flexShrink: 0 },
  fsArrowBtn: {
    width: 48,
    height: 48,
    borderRadius: BorderRadius.full,
    backgroundColor: "rgba(20,20,20,0.85)",
    borderWidth: 1,
    borderColor: Colors.dark.border,
    justifyContent: "center",
    alignItems: "center",
  },
  fsArrowBtnActive: {
    borderColor: Colors.dark.accent,
    backgroundColor: Colors.dark.accentDim,
  },
  fsArrowBtnDisabled: { opacity: 0.35 },

  // ── Report content modal ──────────────────────────────────────────────────
  reportBackdrop: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.78)",
    justifyContent: "center",
    alignItems: "center",
    padding: Spacing.xl,
  },
  reportCard: {
    width: 400,
    maxWidth: "95%",
    backgroundColor: Colors.dark.backgroundDefault,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    borderColor: Colors.dark.border,
    padding: Spacing.xl,
    gap: Spacing.md,
    alignItems: "center",
  },
  reportHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
  },
  reportTitle: {
    fontSize: 17,
    fontWeight: "700",
    color: Colors.dark.text,
  },
  reportSubtitle: {
    fontSize: 12,
    color: Colors.dark.textSecondary,
    textAlign: "center",
    maxWidth: "90%",
  },
  reportReasons: {
    width: "100%",
    gap: Spacing.xs,
  },
  reportReasonBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.md,
    borderRadius: BorderRadius.sm,
    borderWidth: 1,
    borderColor: Colors.dark.border,
    backgroundColor: Colors.dark.backgroundSecondary,
  },
  reportReasonBtnSelected: {
    borderColor: Colors.dark.error,
    backgroundColor: "rgba(255,59,59,0.1)",
  },
  reportReasonBtnHover: {
    borderColor: Colors.dark.accent,
    backgroundColor: Colors.dark.accentDim,
  },
  reportRadio: {
    width: 18,
    height: 18,
    borderRadius: BorderRadius.full,
    borderWidth: 2,
    borderColor: Colors.dark.border,
    justifyContent: "center",
    alignItems: "center",
  },
  reportRadioSelected: {
    borderColor: Colors.dark.error,
  },
  reportRadioDot: {
    width: 9,
    height: 9,
    borderRadius: BorderRadius.full,
    backgroundColor: Colors.dark.error,
  },
  reportReasonText: {
    fontSize: 14,
    color: Colors.dark.textSecondary,
    flex: 1,
  },
  reportReasonTextSelected: {
    color: Colors.dark.text,
    fontWeight: "600",
  },
  reportOtherInput: {
    width: "100%",
    minHeight: 70,
    backgroundColor: Colors.dark.backgroundSecondary,
    borderRadius: BorderRadius.sm,
    borderWidth: 1,
    borderColor: Colors.dark.border,
    color: Colors.dark.text,
    fontSize: 14,
    padding: Spacing.md,
    textAlignVertical: "top",
  },
  reportBtnRow: {
    flexDirection: "row",
    gap: Spacing.sm,
    width: "100%",
    marginTop: Spacing.xs,
  },
  reportCancelBtn: {
    flex: 1,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.sm,
    borderWidth: 1,
    borderColor: Colors.dark.border,
    alignItems: "center",
    justifyContent: "center",
  },
  reportCancelBtnHover: {
    borderColor: Colors.dark.accent,
    backgroundColor: Colors.dark.accentDim,
  },
  reportCancelText: {
    color: Colors.dark.textSecondary,
    fontWeight: "600",
    fontSize: 14,
  },
  reportSubmitBtn: {
    flex: 2,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.sm,
    backgroundColor: Colors.dark.error,
    alignItems: "center",
    justifyContent: "center",
    minHeight: 42,
  },
  reportSubmitBtnDisabled: {
    opacity: 0.4,
  },
  reportSubmitBtnHover: {
    backgroundColor: "#ff5555",
  },
  reportSubmitText: {
    color: "#fff",
    fontWeight: "700",
    fontSize: 14,
  },
});
