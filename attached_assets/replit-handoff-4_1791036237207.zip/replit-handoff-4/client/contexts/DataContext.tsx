import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
  useRef,
  ReactNode,
} from "react";
import { xtreamApi, Category, LiveStream, VodStream, Series } from "@/lib/xtream-api";
import { useAuth } from "@/contexts/AuthContext";
import { getApiUrl } from "@/lib/query-client";
import { toCinemaMovie, type CinemaMovie } from "@/lib/cinema";
import { useIntroDone } from "@/lib/intro-gate";
import { warmSearchIndex } from "@/lib/search";
import { clearEpgCache } from "@/lib/epg-cache";
export interface StreamRating {
  certification: string;
  age_int: number;
}

export type SyncStatus = "idle" | "waiting" | "loading" | "done" | "error";

export interface SyncProgress {
  live: SyncStatus;
  movies: SyncStatus;
  series: SyncStatus;
}

interface DataContextType {
  isSyncing: boolean;
  hasData: boolean;
  syncProgress: SyncProgress;
  liveCategories: Category[];
  liveStreams: LiveStream[];
  vodCategories: Category[];
  vodStreams: VodStream[];
  cinemaMovies: CinemaMovie[];
  cinemaAvailable: boolean;
  cinemaError: string | null;
  seriesCategories: Category[];
  seriesList: Series[];
  // Pre-computed during sync so the "Recently Added" view opens instantly
  // instead of sorting tens of thousands of items on the JS thread every
  // time the screen mounts.
  recentMovies: VodStream[];
  recentSeries: Series[];
  refresh: () => Promise<void>;
  streamRatings: Map<number, StreamRating>;
}

const RECENTLY_ADDED_LIMIT = 30;

function tsOf(s: any, kind: "movies" | "series"): number {
  const raw = (kind === "series" ? s.last_modified : s.added) ?? s.added ?? s.last_modified;
  if (!raw) return 0;
  const n = typeof raw === "number" ? raw : parseInt(String(raw), 10);
  if (!isNaN(n) && n > 0) return n;
  const d = Date.parse(String(raw));
  return isNaN(d) ? 0 : Math.floor(d / 1000);
}

function computeRecent<T>(pool: T[], kind: "movies" | "series"): T[] {
  if (pool.length === 0) return [];
  // Single-pass top-K via insertion into a small sorted array. Avoids
  // sorting the entire pool (which can be 50k+ items) — keeps the work
  // bounded to O(n * K) with K=30, much cheaper than O(n log n).
  const top: { item: T; ts: number }[] = [];
  for (const item of pool) {
    const t = tsOf(item, kind);
    if (top.length < RECENTLY_ADDED_LIMIT) {
      top.push({ item, ts: t });
      if (top.length === RECENTLY_ADDED_LIMIT) {
        top.sort((a, b) => b.ts - a.ts);
      }
      continue;
    }
    if (t <= top[top.length - 1].ts) continue;
    // insert
    let i = top.length - 1;
    top[i] = { item, ts: t };
    while (i > 0 && top[i].ts > top[i - 1].ts) {
      const tmp = top[i - 1];
      top[i - 1] = top[i];
      top[i] = tmp;
      i--;
    }
  }
  if (top.length < RECENTLY_ADDED_LIMIT) {
    top.sort((a, b) => b.ts - a.ts);
  }
  return top.map((x) => x.item);
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export function DataProvider({ children }: { children: ReactNode }) {
  const { isAuthenticated, userInfo } = useAuth();
  const introDone = useIntroDone();
  const [isSyncing, setIsSyncing] = useState(false);
  const [hasData, setHasData] = useState(false);
  const [syncProgress, setSyncProgress] = useState<SyncProgress>({
    live: "idle",
    movies: "idle",
    series: "idle",
  });

  const [liveCategories, setLiveCategories] = useState<Category[]>([]);
  const [liveStreams, setLiveStreams] = useState<LiveStream[]>([]);
  const [vodCategories, setVodCategories] = useState<Category[]>([]);
  const [vodStreams, setVodStreams] = useState<VodStream[]>([]);
  const [cinemaMovies, setCinemaMovies] = useState<CinemaMovie[]>([]);
  const [cinemaAvailable, setCinemaAvailable] = useState(false);
  const [cinemaError, setCinemaError] = useState<string | null>(null);
  const [seriesCategories, setSeriesCategories] = useState<Category[]>([]);
  const [seriesList, setSeriesList] = useState<Series[]>([]);
  const [recentMovies, setRecentMovies] = useState<VodStream[]>([]);
  const [recentSeries, setRecentSeries] = useState<Series[]>([]);

  const syncRunning = useRef(false);
  const [streamRatings, setStreamRatings] = useState<Map<number, StreamRating>>(new Map());
  const cinemaRequest = useRef(0);
  const loadCinema = useCallback(async () => {
    const request = ++cinemaRequest.current;
    setCinemaAvailable(false);
    setCinemaMovies([]);
    setCinemaError(null);
    const credentials = await xtreamApi.loadCredentials();
    if (!credentials || !isAuthenticated || credentials.username !== userInfo?.user_info?.username) return;
    try {
      const response = await fetch(new URL("/api/cinema-releases", getApiUrl()).toString(), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...credentials,
          serverUrl: /^https?:\/\//i.test(credentials.serverUrl)
            ? credentials.serverUrl
            : `http://${credentials.serverUrl}`,
        }),
      });
      if (request !== cinemaRequest.current) return;
      if (response.status === 403) return;
      if (!response.ok) throw new Error(`Cinema Releases unavailable (${response.status})`);
      const releases = await response.json();
      setCinemaMovies(releases.map(toCinemaMovie));
      setCinemaAvailable(true);
    } catch (error) {
      if (request === cinemaRequest.current) setCinemaError(error instanceof Error ? error.message : "Cinema Releases unavailable");
    }
  }, [isAuthenticated, userInfo?.user_info?.username]);

  const sync = useCallback(async () => {
    if (syncRunning.current) return;
    syncRunning.current = true;
    setIsSyncing(true);
    // Listings belong to the previous catalogue; drop them with it.
    clearEpgCache();
    setSyncProgress({ live: "waiting", movies: "waiting", series: "waiting" });

    let _liveStreams: LiveStream[] = [];
    let _vodStreams: VodStream[] = [];
    let _series: Series[] = [];

    try {
      // ── Live TV ──────────────────────────────────────────────────────────
      setSyncProgress((p) => ({ ...p, live: "loading" }));
      try {
        const [cats, streams] = await Promise.all([
          xtreamApi.getLiveCategories(),
          xtreamApi.getLiveStreams(),
        ]);
        setLiveCategories(cats);
        setLiveStreams(streams);
        _liveStreams = streams;
        setSyncProgress((p) => ({ ...p, live: "done" }));
      } catch {
        setSyncProgress((p) => ({ ...p, live: "error" }));
      }

      // ── Movies ───────────────────────────────────────────────────────────
      setSyncProgress((p) => ({ ...p, movies: "loading" }));
      try {
        const [cats, streams] = await Promise.all([
          xtreamApi.getVodCategories(),
          xtreamApi.getVodStreams(),
        ]);
        setVodCategories(cats);
        setVodStreams(streams);
        setRecentMovies(computeRecent(streams, "movies"));
        _vodStreams = streams;
        setSyncProgress((p) => ({ ...p, movies: "done" }));
      } catch {
        setSyncProgress((p) => ({ ...p, movies: "error" }));
      }

      // ── Series ───────────────────────────────────────────────────────────
      setSyncProgress((p) => ({ ...p, series: "loading" }));
      try {
        const [cats, list] = await Promise.all([
          xtreamApi.getSeriesCategories(),
          xtreamApi.getSeries(),
        ]);
        setSeriesCategories(cats);
        setSeriesList(list);
        setRecentSeries(computeRecent(list, "series"));
        _series = list;
        setSyncProgress((p) => ({ ...p, series: "done" }));
      } catch {
        setSyncProgress((p) => ({ ...p, series: "error" }));
      }

      setHasData(true);
      warmSearchIndex([_liveStreams, _vodStreams, _series]);

      // Load any ratings already stored from previous sessions.
      Promise.all([
        fetch(new URL("/api/stream-ratings?content_type=movie", getApiUrl()).toString())
          .then((r) => (r.ok ? r.json() : [])),
        fetch(new URL("/api/stream-ratings?content_type=tv", getApiUrl()).toString())
          .then((r) => (r.ok ? r.json() : [])),
      ])
        .then(([movies, tv]: [any[], any[]]) => {
          const map = new Map<number, StreamRating>();
          for (const r of [...movies, ...tv]) {
            if (r.stream_id && r.certification)
              map.set(r.stream_id, { certification: r.certification, age_int: r.age_int });
          }
          setStreamRatings(map);
        })
        .catch(() => {});

      // Send full library to server for background TMDB enrichment.
      // Server deduplicates so repeated syncs are instant.
      if (_vodStreams.length > 0 || _series.length > 0) {
        fetch(new URL("/api/stream-ratings/enrich", getApiUrl()).toString(), {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            streams: [
              ..._vodStreams.map((s) => ({ stream_id: s.stream_id, name: s.name, type: "movie" })),
              ..._series.map((s) => ({ stream_id: s.series_id, name: s.name, type: "tv" })),
            ],
          }),
        }).catch(() => {});
      }
    } finally {
      setIsSyncing(false);
      syncRunning.current = false;
    }
  }, []);

  useEffect(() => {
    if (isAuthenticated && introDone && !hasData && !syncRunning.current) {
      sync();
    }
    if (!isAuthenticated) {
      setHasData(false);
      setSyncProgress({ live: "idle", movies: "idle", series: "idle" });
      setLiveCategories([]);
      setLiveStreams([]);
      setVodCategories([]);
      setVodStreams([]);
      setSeriesCategories([]);
      setSeriesList([]);
      setRecentMovies([]);
      setRecentSeries([]);
    }
  }, [isAuthenticated, introDone]);

  useEffect(() => {
    if (isAuthenticated && introDone && userInfo?.user_info?.username) void loadCinema();
    return () => {
      cinemaRequest.current++;
      setCinemaAvailable(false);
      setCinemaMovies([]);
    };
  }, [isAuthenticated, introDone, userInfo?.user_info?.username, loadCinema]);

  const refreshAll = useCallback(async () => {
    await Promise.all([sync(), loadCinema()]);
  }, [sync, loadCinema]);

  return (
    <DataContext.Provider
      value={{
        isSyncing,
        hasData,
        syncProgress,
        liveCategories,
        liveStreams,
        vodCategories,
        vodStreams,
        cinemaMovies,
        cinemaAvailable,
        cinemaError,
        seriesCategories,
        seriesList,
        recentMovies,
        recentSeries,
        refresh: refreshAll,
        streamRatings,
      }}
    >
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const ctx = useContext(DataContext);
  if (!ctx) throw new Error("useData must be used within DataProvider");
  return ctx;
}
